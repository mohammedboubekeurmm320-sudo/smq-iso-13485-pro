import { test, expect, type Page } from '@playwright/test';

test.describe('Authentication Flow', () => {
  test('should display login page', async ({ page }) => {
    await page.goto('/');
    
    // Check for login elements
    await expect(page.getByRole('heading', { name: /sign in/i })).toBeVisible();
    await expect(page.getByLabel(/email/i)).toBeVisible();
    await expect(page.getByLabel(/password/i)).toBeVisible();
  });

  test('should show error for invalid credentials', async ({ page }) => {
    await page.goto('/');
    
    await page.getByLabel(/email/i).fill('invalid@test.com');
    await page.getByLabel(/password/i).fill('wrongpassword');
    await page.getByRole('button', { name: /sign in/i }).click();
    
    // Should show error message
    await expect(page.getByText(/invalid credentials/i)).toBeVisible();
  });
});

test.describe('Dashboard', () => {
  test.beforeEach(async ({ page }) => {
    // Login before each test in this describe block
    await page.goto('/');
    await page.getByLabel(/email/i).fill('admin@example.com');
    await page.getByLabel(/password/i).fill('password123');
    await page.getByRole('button', { name: /sign in/i }).click();
    
    // Wait for dashboard to load
    await page.waitForURL('**/dashboard', { timeout: 10000 });
  });

  test('should display dashboard with key metrics', async ({ page }) => {
    await expect(page.getByRole('heading', { name: /dashboard/i })).toBeVisible();
    
    // Check for KPI cards
    await expect(page.getByText(/documents/i)).toBeVisible();
    await expect(page.getByText(/capa/i)).toBeVisible();
    await expect(page.getByText(/audits/i)).toBeVisible();
  });

  test('should navigate to document control', async ({ page }) => {
    await page.getByRole('link', { name: /document control/i }).click();
    
    await expect(page.getByRole('heading', { name: /document control/i })).toBeVisible();
  });
});

test.describe('Document Control', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
    await page.getByLabel(/email/i).fill('admin@example.com');
    await page.getByLabel(/password/i).fill('password123');
    await page.getByRole('button', { name: /sign in/i }).click();
    await page.waitForURL('**/dashboard', { timeout: 10000 });
    
    // Navigate to document control
    await page.getByRole('link', { name: /document control/i }).click();
  });

  test('should display document list', async ({ page }) => {
    await expect(page.getByRole('table')).toBeVisible();
    await expect(page.getByRole('columnheader', { name: /title/i })).toBeVisible();
    await expect(page.getByRole('columnheader', { name: /version/i })).toBeVisible();
  });

  test('should open new document dialog', async ({ page }) => {
    await page.getByRole('button', { name: /new document/i }).click();
    
    await expect(page.getByRole('dialog')).toBeVisible();
    await expect(page.getByLabel(/title/i)).toBeVisible();
    await expect(page.getByLabel(/type/i)).toBeVisible();
  });
});

test.describe('Compliance', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
    await page.getByLabel(/email/i).fill('admin@example.com');
    await page.getByLabel(/password/i).fill('password123');
    await page.getByRole('button', { name: /sign in/i }).click();
    await page.waitForURL('**/dashboard', { timeout: 10000 });
  });

  test('should navigate to compliance page', async ({ page }) => {
    await page.getByRole('link', { name: /compliance/i }).click();
    
    await expect(page.getByRole('heading', { name: /conformité réglementaire/i })).toBeVisible();
  });

  test('should display compliance dashboard', async ({ page }) => {
    await page.getByRole('link', { name: /compliance/i }).click();
    await page.getByRole('tab', { name: /tableau de bord/i }).click();
    
    await expect(page.getByText(/score de conformité/i)).toBeVisible();
  });
});

test.describe('Accessibility', () => {
  test('should have proper heading hierarchy', async ({ page }) => {
    await page.goto('/');
    
    // Check that h1 exists
    const h1 = page.locator('h1');
    await expect(h1).toBeVisible();
  });

  test('should have accessible form labels', async ({ page }) => {
    await page.goto('/');
    
    // Check that form inputs have labels
    const emailInput = page.getByLabel(/email/i);
    await expect(emailInput).toBeVisible();
    
    const passwordInput = page.getByLabel(/password/i);
    await expect(passwordInput).toBeVisible();
  });

  test('should have focusable elements', async ({ page }) => {
    await page.goto('/');
    
    // Tab should move focus to interactive elements
    await page.keyboard.press('Tab');
    const focusedElement = await page.locator(':focus').getAttribute('role');
    expect(focusedElement).not.toBeNull();
  });
});
