# API Documentation

## Base URL
```
https://your-project.supabase.co
```

## Authentication
All API requests require a JWT token in the Authorization header:
```
Authorization: Bearer <your-token>
```

## Endpoints

### Documents

#### List Documents
```http
GET /rest/v1/documents
```

Query Parameters:
- `select` (optional): Columns to select
- `status` (optional): Filter by status
- `type` (optional): Filter by document type

Response:
```json
{
  "id": "uuid",
  "document_number": "DOC-001",
  "title": "Procedure Title",
  "type": "SOP",
  "version": "1.0",
  "status": "Approved"
}
```

#### Create Document
```http
POST /rest/v1/documents
```

Request Body:
```json
{
  "document_number": "DOC-002",
  "title": "New Procedure",
  "type": "SOP",
  "status": "Draft"
}
```

#### Sign Document (Electronic Signature)
```http
POST /rest/v1/signatures
```

Request Body:
```json
{
  "document_id": "uuid",
  "user_id": "uuid",
  "role": "Approver",
  "reason": "Approved for use",
  "hash": "sha256-hash-of-document"
}
```

### CAPA

#### List CAPAs
```http
GET /rest/v1/capas
```

#### Create CAPA
```http
POST /rest/v1/capas
```

### Audit Trail

#### Get Audit Logs
```http
GET /rest/v1/audit_trail
```

Query Parameters:
- `table_name` (optional): Filter by table
- `user_id` (optional): Filter by user

## Error Responses

### 400 Bad Request
```json
{
  "message": "Invalid request parameters",
  "details": []
}
```

### 401 Unauthorized
```json
{
  "message": "Invalid or expired token"
}
```

### 403 Forbidden
```json
{
  "message": "Insufficient permissions"
}
```

### 500 Internal Server Error
```json
{
  "message": "An unexpected error occurred"
}
```

## Rate Limiting

API requests are rate-limited to 10 requests per second per user.
