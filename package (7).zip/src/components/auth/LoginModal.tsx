import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import Modal from '@/components/ui/Modal';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// Demo accounts for testing different roles
const demoAccounts = [
  {
    role: 'admin',
    email: 'admin@example.com',
    password: 'password123',
    label: 'System Administrator',
    description: 'Full system access including user management',
    color: 'bg-red-100 text-red-700 border-red-200',
  },
  {
    role: 'quality_manager',
    email: 'quality@example.com',
    password: 'password123',
    label: 'Quality Manager',
    description: 'Full access to all QMS functions',
    color: 'bg-purple-100 text-purple-700 border-purple-200',
  },
  {
    role: 'auditor',
    email: 'auditor@example.com',
    password: 'password123',
    label: 'Auditor',
    description: 'Create audits and CAPAs',
    color: 'bg-green-100 text-green-700 border-green-200',
  },
  {
    role: 'document_controller',
    email: 'documents@example.com',
    password: 'password123',
    label: 'Document Controller',
    description: 'Manage documents and training',
    color: 'bg-amber-100 text-amber-700 border-amber-200',
  },
  {
    role: 'executive',
    email: 'executive@example.com',
    password: 'password123',
    label: 'Executive',
    description: 'View reports and approve documents',
    color: 'bg-blue-100 text-blue-700 border-blue-200',
  },
  {
    role: 'operator',
    email: 'operator@example.com',
    password: 'password123',
    label: 'Operator',
    description: 'Read-only access',
    color: 'bg-gray-100 text-gray-700 border-gray-200',
  },
];

const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const { signIn } = useAuth();

  const handleDemoLogin = async (demoEmail: string, demoPassword: string) => {
    setError(null);
    setLoading(true);
    
    const { error } = await signIn(demoEmail, demoPassword);
    if (error) {
      setError(error.message);
    } else {
      onClose();
    }
    setLoading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const { error } = await signIn(email, password);
    if (error) {
      setError(error.message);
    } else {
      onClose();
    }
    setLoading(false);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title='Sign In to QMS Pro'
      size="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Logo/Brand */}
        <div className="text-center mb-6">
          <div className="w-16 h-16 bg-blue-600 rounded-xl flex items-center justify-center mx-auto mb-3">
            <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
            </svg>
          </div>
          <p className="text-sm text-gray-500">
            ISO 13485 Quality Management System
          </p>
        </div>

        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700">
            {error}
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-colors"
            placeholder="you@company.com"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-colors"
            placeholder="••••••••"
            required
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {loading ? (
            <>
              <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
              </svg>
              <span>Signing In...</span>
            </>
          ) : (
            <span>Sign In</span>
          )}
        </button>

        <div className="text-center pt-4 border-t border-gray-200">
          <p className="text-sm text-gray-600">
            Use the demo accounts below for testing
          </p>
        </div>
      </form>

      {/* Demo Accounts Section */}
      <div className="mt-6 pt-6 border-t border-gray-200">
        <div className="text-center mb-4">
          <p className="text-sm font-medium text-gray-700">Demo Accounts</p>
          <p className="text-xs text-gray-500">Click to login with test credentials</p>
        </div>
        
        <div className="space-y-2 max-h-64 overflow-y-auto">
          {demoAccounts.map((account) => (
            <button
              key={account.role}
              type="button"
              onClick={() => handleDemoLogin(account.email, account.password)}
              disabled={loading}
              className={`w-full p-3 rounded-lg border-2 transition-all hover:shadow-md text-left ${account.color} disabled:opacity-50`}
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">{account.label}</p>
                  <p className="text-xs opacity-80">{account.description}</p>
                </div>
                <svg className="w-5 h-5 opacity-60" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </button>
          ))}
        </div>
        
        <p className="text-xs text-center text-gray-400 mt-3">
          Default password for all demo accounts: password123
        </p>
      </div>
    </Modal>
  );
};

export default LoginModal;
