/**
 * PDF Configuration Panel
 * Allows users to configure PDF headers, footers, and document settings
 */

import React from 'react';
import { X, FileText, Type, Calendar, Hash, User, Building, Image, ToggleLeft, ToggleRight } from 'lucide-react';
import { PDFConfig, defaultPDFConfig, reportTypeLabels, ReportType, getReportTypePrefix, generateDocumentId } from '../../utils/pdfUtils';

interface PDFConfigurationPanelProps {
  config: PDFConfig;
  onConfigChange: (config: PDFConfig) => void;
  reportType: ReportType;
  onClose: () => void;
  onGeneratePDF: () => void;
  onPrint: () => void;
  isGenerating?: boolean;
}

const PDFConfigurationPanel: React.FC<PDFConfigurationPanelProps> = ({
  config,
  onConfigChange,
  reportType,
  onClose,
  onGeneratePDF,
  onPrint,
  isGenerating = false,
}) => {
  const updateConfig = (updates: Partial<PDFConfig>) => {
    onConfigChange({ ...config, ...updates });
  };

  const generateNewId = () => {
    const prefix = getReportTypePrefix(reportType);
    const newId = generateDocumentId(prefix);
    updateConfig({ documentId: newId });
  };

  return (
    <div className="w-80 bg-white border-l border-gray-200 h-full flex flex-col shadow-lg">
      {/* Header */}
      <div className="p-4 border-b border-gray-200 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-blue-600" />
          <h3 className="font-semibold text-gray-900">Configuration PDF</h3>
        </div>
        <button
          onClick={onClose}
          className="p-1 hover:bg-gray-100 rounded"
        >
          <X className="w-5 h-5 text-gray-500" />
        </button>
      </div>

      {/* Configuration Options */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {/* Document Information */}
        <div className="space-y-4">
          <h4 className="text-sm font-medium text-gray-700 flex items-center gap-2">
            <Hash className="w-4 h-4" />
            Informations du document
          </h4>
          
          <div>
            <label className="block text-xs text-gray-600 mb-1">Titre du document</label>
            <input
              type="text"
              value={config.documentTitle}
              onChange={(e) => updateConfig({ documentTitle: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs text-gray-600 mb-1">ID du document</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={config.documentId}
                onChange={(e) => updateConfig({ documentId: e.target.value })}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
              <button
                onClick={generateNewId}
                className="px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg text-sm"
                title="Générer un nouvel ID"
              >
                <Hash className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-gray-600 mb-1">Révision</label>
              <input
                type="text"
                value={config.revision}
                onChange={(e) => updateConfig({ revision: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-600 mb-1">Auteur</label>
              <input
                type="text"
                value={config.author}
                onChange={(e) => updateConfig({ author: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>
        </div>

        {/* Header Configuration */}
        <div className="space-y-4">
          <h4 className="text-sm font-medium text-gray-700 flex items-center gap-2">
            <Image className="w-4 h-4" />
            En-tête
          </h4>

          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Afficher l'en-tête</span>
            <button
              onClick={() => updateConfig({ showHeader: !config.showHeader })}
              className="text-blue-600"
            >
              {config.showHeader ? (
                <ToggleRight className="w-8 h-5" />
              ) : (
                <ToggleLeft className="w-8 h-5 text-gray-400" />
              )}
            </button>
          </div>

          {config.showHeader && (
            <>
              <div>
                <label className="block text-xs text-gray-600 mb-1">Titre principal</label>
                <input
                  type="text"
                  value={config.headerTitle}
                  onChange={(e) => updateConfig({ headerTitle: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs text-gray-600 mb-1">Sous-titre</label>
                <input
                  type="text"
                  value={config.headerSubtitle}
                  onChange={(e) => updateConfig({ headerSubtitle: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </>
          )}
        </div>

        {/* Footer Configuration */}
        <div className="space-y-4">
          <h4 className="text-sm font-medium text-gray-700 flex items-center gap-2">
            <Building className="w-4 h-4" />
            Pied de page
          </h4>

          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Afficher le pied de page</span>
            <button
              onClick={() => updateConfig({ showFooter: !config.showFooter })}
              className="text-blue-600"
            >
              {config.showFooter ? (
                <ToggleRight className="w-8 h-5" />
              ) : (
                <ToggleLeft className="w-8 h-5 text-gray-400" />
              )}
            </button>
          </div>

          {config.showFooter && (
            <>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Numéro de page</span>
                <button
                  onClick={() => updateConfig({ showPageNumbers: !config.showPageNumbers })}
                  className="text-blue-600"
                >
                  {config.showPageNumbers ? (
                    <ToggleRight className="w-8 h-5" />
                  ) : (
                    <ToggleLeft className="w-8 h-5 text-gray-400" />
                  )}
                </button>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Date d'impression</span>
                <button
                  onClick={() => updateConfig({ showDate: !config.showDate })}
                  className="text-blue-600"
                >
                  {config.showDate ? (
                    <ToggleRight className="w-8 h-5" />
                  ) : (
                    <ToggleLeft className="w-8 h-5 text-gray-400" />
                  )}
                </button>
              </div>

              <div>
                <label className="block text-xs text-gray-600 mb-1">Nom de l'entreprise</label>
                <input
                  type="text"
                  value={config.showCompanyName}
                  onChange={(e) => updateConfig({ showCompanyName: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </>
          )}
        </div>

        {/* Page Settings */}
        <div className="space-y-4">
          <h4 className="text-sm font-medium text-gray-700 flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Paramètres de page
          </h4>

          <div>
            <label className="block text-xs text-gray-600 mb-1">Format de page</label>
            <select
              value={config.pageSize}
              onChange={(e) => updateConfig({ pageSize: e.target.value as 'A4' | 'LETTER' | 'LEGAL' })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="A4">A4 (210 x 297 mm)</option>
              <option value="LETTER">Letter (8.5 x 11 po)</option>
              <option value="LEGAL">Legal (8.5 x 14 po)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs text-gray-600 mb-1">Orientation</label>
            <select
              value={config.orientation}
              onChange={(e) => updateConfig({ orientation: e.target.value as 'portrait' | 'landscape' })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="portrait">Portrait</option>
              <option value="landscape">Paysage</option>
            </select>
          </div>

          <div>
            <label className="block text-xs text-gray-600 mb-1">Marge (mm)</label>
            <input
              type="number"
              value={config.margin}
              onChange={(e) => updateConfig({ margin: parseInt(e.target.value) || 20 })}
              min={10}
              max={50}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>

        {/* Colors */}
        <div className="space-y-4">
          <h4 className="text-sm font-medium text-gray-700 flex items-center gap-2">
            <div className="w-4 h-4 rounded" style={{ backgroundColor: config.primaryColor }} />
            Couleurs
          </h4>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-gray-600 mb-1">Couleur primaire</label>
              <input
                type="color"
                value={config.primaryColor}
                onChange={(e) => updateConfig({ primaryColor: e.target.value })}
                className="w-full h-10 border border-gray-300 rounded-lg cursor-pointer"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-600 mb-1">Couleur d'accent</label>
              <input
                type="color"
                value={config.accentColor}
                onChange={(e) => updateConfig({ accentColor: e.target.value })}
                className="w-full h-10 border border-gray-300 rounded-lg cursor-pointer"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="p-4 border-t border-gray-200 space-y-3">
        <button
          onClick={onGeneratePDF}
          disabled={isGenerating}
          className="w-full px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 font-medium"
        >
          {isGenerating ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Génération...
            </>
          ) : (
            <>
              <FileText className="w-5 h-5" />
              Télécharger PDF
            </>
          )}
        </button>
        
        <button
          onClick={onPrint}
          className="w-full px-4 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 flex items-center justify-center gap-2 font-medium"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
          </svg>
          Imprimer
        </button>
      </div>
    </div>
  );
};

export default PDFConfigurationPanel;
