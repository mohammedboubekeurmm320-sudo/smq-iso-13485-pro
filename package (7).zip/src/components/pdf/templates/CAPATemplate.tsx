/**
 * CAPA (Corrective Action / Preventive Action) PDF Template
 * Professional template for CAPA reports
 */

import React from 'react';
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Font,
} from '@react-pdf/renderer';
import { PDFConfig, formatPDFDate, getStatusColor, hexToRGB } from '../../../utils/pdfUtils';

// Register fonts
Font.register({
  family: 'Helvetica',
  fonts: [
    { src: 'https://fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu4mxP.ttf', fontWeight: 'normal' },
    { src: 'https://fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmWUlfBBc9.ttf', fontWeight: 'bold' },
  ],
});

const styles = StyleSheet.create({
  page: {
    padding: 40,
    fontFamily: 'Helvetica',
    fontSize: 10,
    lineHeight: 1.5,
  },
  header: {
    marginBottom: 20,
    borderBottomWidth: 2,
    borderBottomColor: '#1e40af',
    paddingBottom: 10,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1e40af',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 12,
    color: '#6b7280',
  },
  documentInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
    padding: 10,
    backgroundColor: '#f3f4f6',
    borderRadius: 4,
  },
  documentInfoItem: {
    fontSize: 9,
    color: '#4b5563',
  },
  documentInfoLabel: {
    fontWeight: 'bold',
    color: '#1f2937',
  },
  capaTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#1e40af',
    marginBottom: 15,
    textAlign: 'center',
    textDecoration: 'underline',
  },
  section: {
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#1e40af',
    marginBottom: 8,
    paddingBottom: 4,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
    textTransform: 'uppercase',
  },
  row: {
    flexDirection: 'row',
    marginBottom: 6,
  },
  label: {
    fontWeight: 'bold',
    width: 150,
    color: '#374151',
  },
  value: {
    flex: 1,
    color: '#1f2937',
  },
  description: {
    marginTop: 8,
    padding: 10,
    backgroundColor: '#f9fafb',
    borderRadius: 4,
    borderLeftWidth: 3,
    borderLeftColor: '#1e40af',
  },
  descriptionText: {
    fontSize: 9,
    color: '#374151',
    lineHeight: 1.6,
  },
  statusBox: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
    fontSize: 9,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    alignSelf: 'flex-start',
  },
  table: {
    marginTop: 10,
    marginBottom: 15,
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#1e40af',
    padding: 8,
  },
  tableHeaderCell: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 8,
    textAlign: 'center',
  },
  tableRow: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
    padding: 8,
    backgroundColor: 'white',
  },
  tableRowAlt: {
    backgroundColor: '#f9fafb',
  },
  tableCell: {
    fontSize: 9,
    color: '#374151',
    textAlign: 'center',
    flex: 1,
  },
  tableCellLeft: {
    textAlign: 'left',
    flex: 2,
  },
  footer: {
    position: 'absolute',
    bottom: 30,
    left: 40,
    right: 40,
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
    paddingTop: 8,
  },
  footerText: {
    fontSize: 8,
    color: '#9ca3af',
  },
  pageNumber: {
    fontSize: 8,
    color: '#9ca3af',
  },
  signatureSection: {
    marginTop: 25,
    paddingTop: 15,
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
  },
  signatureTitle: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#1e40af',
    marginBottom: 15,
  },
  signatureRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  signatureBox: {
    width: '30%',
  },
  signatureLine: {
    borderBottomWidth: 1,
    borderBottomColor: '#1f2937',
    marginBottom: 8,
    paddingBottom: 4,
  },
  signatureLabel: {
    fontSize: 8,
    color: '#6b7280',
  },
  signatureDate: {
    fontSize: 8,
    color: '#6b7280',
    marginTop: 4,
  },
  effectivenessBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
    fontSize: 8,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    marginTop: 5,
  },
  timelineItem: {
    flexDirection: 'row',
    marginBottom: 8,
    paddingLeft: 10,
    borderLeftWidth: 2,
    borderLeftColor: '#1e40af',
  },
  timelineDate: {
    width: 80,
    fontSize: 8,
    color: '#6b7280',
  },
  timelineContent: {
    flex: 1,
    fontSize: 9,
    color: '#374151',
  },
});

interface CAPAData {
  id: string;
  title: string;
  description: string;
  status: string;
  type: 'Corrective' | 'Preventive';
  source: string;
  priority: string;
  rootCause: string;
  immediateAction: string;
  correctiveAction: string;
  preventiveAction: string;
  effectiveness: string;
  assignedTo: string;
  dueDate: string;
  completionDate: string;
  createdAt: string;
  updatedAt: string;
  category: string;
  department: string;
  impact: string;
  verifiedBy: string;
  verifiedDate: string;
  notes: string;
}

interface CAPAPDFProps {
  config: PDFConfig;
  capa: CAPAData;
  timeline?: { date: string; action: string; user: string }[];
}

const CAPAPDF: React.FC<CAPAPDFProps> = ({ config, capa, timeline = [] }) => {
  const statusColor = getStatusColor(capa.status);
  const effectivenessColor = capa.effectiveness === 'Effective' 
    ? '#16a34a' 
    : capa.effectiveness === 'Ineffective' 
      ? '#dc2626' 
      : '#d97706';

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        {/* Header */}
        {config.showHeader && (
          <View style={styles.header}>
            <Text style={styles.headerTitle}>{config.headerTitle}</Text>
            <Text style={styles.headerSubtitle}>{config.headerSubtitle}</Text>
          </View>
        )}

        {/* Document Info */}
        <View style={styles.documentInfo}>
          <View>
            <Text style={styles.documentInfoItem}>
              <Text style={styles.documentInfoLabel}>Document ID: </Text>
              {config.documentId}
            </Text>
            <Text style={styles.documentInfoItem}>
              <Text style={styles.documentInfoLabel}>Type: </Text>
              {capa.type === 'Corrective' ? 'Action corrective' : 'Action préventive'}
            </Text>
          </View>
          <View>
            <Text style={styles.documentInfoItem}>
              <Text style={styles.documentInfoLabel}>Date: </Text>
              {formatPDFDate(new Date())}
            </Text>
            <Text style={styles.documentInfoItem}>
              <Text style={styles.documentInfoLabel}>Auteur: </Text>
              {config.author}
            </Text>
          </View>
        </View>

        {/* CAPA Title */}
        <Text style={styles.capaTitle}>
          RAPPORT D'ACTION {capa.type === 'Corrective' ? 'CORRECTIVE' : 'PRÉVENTIVE'}
        </Text>

        {/* CAPA ID and Status */}
        <View style={[styles.row, { marginBottom: 15 }]}>
          <View style={{ flex: 1 }}>
            <Text style={styles.label}>N° CAPA:</Text>
            <Text style={[styles.value, { fontWeight: 'bold', fontSize: 12 }]}>{capa.id}</Text>
          </View>
          <View style={{ flex: 1, alignItems: 'flex-start' }}>
            <Text style={styles.label}>Statut:</Text>
            <View style={[styles.statusBox, { backgroundColor: statusColor }]}>
              <Text style={{ color: 'white' }}>{capa.status}</Text>
            </View>
          </View>
        </View>

        {/* Section 1: Identification */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>1. Identification</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Titre:</Text>
            <Text style={styles.value}>{capa.title}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Département:</Text>
            <Text style={styles.value}>{capa.department}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Catégorie:</Text>
            <Text style={styles.value}>{capa.category}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Source:</Text>
            <Text style={styles.value}>{capa.source}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Priorité:</Text>
            <Text style={styles.value}>{capa.priority}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Assigné à:</Text>
            <Text style={styles.value}>{capa.assignedTo}</Text>
          </View>
        </View>

        {/* Section 2: Description */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>2. Description de la non-conformité</Text>
          <View style={styles.description}>
            <Text style={styles.descriptionText}>{capa.description}</Text>
          </View>
        </View>

        {/* Section 3: Root Cause Analysis */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>3. Analyse des causes racines</Text>
          <View style={styles.description}>
            <Text style={styles.descriptionText}>{capa.rootCause || '-'}</Text>
          </View>
        </View>

        {/* Section 4: Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>4. Actions</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Action immédiate:</Text>
            <Text style={styles.value}>{capa.immediateAction || '-'}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Action corrective:</Text>
            <Text style={styles.value}>{capa.correctiveAction || '-'}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Action préventive:</Text>
            <Text style={styles.value}>{capa.preventiveAction || '-'}</Text>
          </View>
        </View>

        {/* Section 5: Effectiveness */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>5. Éfficacité</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Évaluation de l'efficacité:</Text>
            <View>
              <View style={[styles.effectivenessBadge, { backgroundColor: effectivenessColor }]}>
                <Text style={{ color: 'white' }}>{capa.effectiveness || 'En attente'}</Text>
              </View>
            </View>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Vérifié par:</Text>
            <Text style={styles.value}>{capa.verifiedBy || '-'}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Date de vérification:</Text>
            <Text style={styles.value}>{capa.verifiedDate ? formatPDFDate(capa.verifiedDate) : '-'}</Text>
          </View>
        </View>

        {/* Section 6: Dates */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>6. Échéances</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Date de création:</Text>
            <Text style={styles.value}>{formatPDFDate(capa.createdAt)}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Date d'échéance:</Text>
            <Text style={styles.value}>{capa.dueDate ? formatPDFDate(capa.dueDate) : '-'}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Date de clôture:</Text>
            <Text style={styles.value}>{capa.completionDate ? formatPDFDate(capa.completionDate) : '-'}</Text>
          </View>
        </View>

        {/* Notes */}
        {capa.notes && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Notes supplémentaires</Text>
            <View style={styles.description}>
              <Text style={styles.descriptionText}>{capa.notes}</Text>
            </View>
          </View>
        )}

        {/* Signatures */}
        <View style={styles.signatureSection}>
          <Text style={styles.signatureTitle}>Signatures</Text>
          <View style={styles.signatureRow}>
            <View style={styles.signatureBox}>
              <View style={styles.signatureLine} />
              <Text style={styles.signatureLabel}>Préparé par</Text>
              <Text style={styles.signatureDate}>{capa.assignedTo}</Text>
              <Text style={styles.signatureDate}>{formatPDFDate(capa.createdAt)}</Text>
            </View>
            <View style={styles.signatureBox}>
              <View style={styles.signatureLine} />
              <Text style={styles.signatureLabel}>Approuvé par</Text>
              <Text style={styles.signatureDate}>Qualité</Text>
              <Text style={styles.signatureDate}></Text>
            </View>
            <View style={styles.signatureBox}>
              <View style={styles.signatureLine} />
              <Text style={styles.signatureLabel}>Vérifié par</Text>
              <Text style={styles.signatureLabel}>{capa.verifiedBy || 'En attente'}</Text>
              <Text style={styles.signatureDate}>{capa.verifiedDate ? formatPDFDate(capa.verifiedDate) : ''}</Text>
            </View>
          </View>
        </View>

        {/* Footer */}
        {config.showFooter && (
          <View style={styles.footer} fixed>
            <Text style={styles.footerText}>{config.showCompanyName}</Text>
            {config.showDate && (
              <Text style={styles.footerText}>
                Imprimé le {formatPDFDate(new Date())}
              </Text>
            )}
            <Text style={styles.pageNumber} render={({ pageNumber, totalPages }) =>
              `${pageNumber} / ${totalPages}`
            } />
          </View>
        )}
      </Page>
    </Document>
  );
};

export default CAPAPDF;
