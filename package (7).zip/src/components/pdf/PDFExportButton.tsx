/**
 * PDF Export Button
 * Reusable button to trigger PDF generation from any page
 */

import React, { useState } from 'react';
import { FileDown, FileText, Printer, Settings, ChevronDown, Loader2 } from 'lucide-react';
import { ReportType, generateDocumentId, getReportTypePrefix } from '../../utils/pdfUtils';

interface PDFExportButtonProps {
  reportType: ReportType;
  title: string;
  data: any;
  tableData?: Record<string, any>[];
  tableColumns?: { key: string; label: string; width?: number }[];
  notes?: string;
  signatures?: { name: string; role: string; date: string }[];
  variant?: 'default' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  label?: string;
  disabled?: boolean;
}

const PDFExportButton: React.FC<PDFExportButtonProps> = ({
  reportType,
  title,
  data,
  tableData,
  tableColumns,
  notes,
  signatures = [],
  variant = 'default',
  size = 'md',
  label = 'Exporter PDF',
  disabled = false,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);

  const handlePreview = () => {
    setIsOpen(true);
  };

  // Size classes
  const sizeClasses = {
    sm: 'px-3 py-1.5 text-xs',
    md: 'px-4 py-2 text-sm',
    lg: 'px-6 py-3 text-base',
  };

  // Variant classes
  const variantClasses = {
    default: 'bg-blue-600 text-white hover:bg-blue-700',
    outline: 'border border-gray-300 text-gray-700 hover:bg-gray-50',
    ghost: 'text-gray-600 hover:bg-gray-100',
  };

  return (
    <>
      <button
        onClick={handlePreview}
        disabled={disabled}
        className={`
          inline-flex items-center gap-2 rounded-lg font-medium transition-colors
          disabled:opacity-50 disabled:cursor-not-allowed
          ${sizeClasses[size]}
          ${variantClasses[variant]}
        `}
      >
        {isGenerating ? (
          <Loader2 className="w-4 h-4 animate-spin" />
        ) : (
          <FileDown className="w-4 h-4" />
        )}
        {label}
      </button>

      {/* The PDF Preview Modal would be rendered at a higher level */}
      {/* This component emits an event or can be connected to a context */}
    </>
  );
};

export default PDFExportButton;

/**
 * Simple PDF Button Component
 * A standalone button that shows a dropdown with PDF options
 */

interface SimplePDFButtonProps {
  onClick: () => void;
  label?: string;
  variant?: 'default' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
}

export const SimplePDFButton: React.FC<SimplePDFButtonProps> = ({
  onClick,
  label = 'PDF',
  variant = 'default',
  size = 'md',
}) => {
  const sizeClasses = {
    sm: 'px-2 py-1 text-xs',
    md: 'px-3 py-2 text-sm',
    lg: 'px-4 py-3 text-base',
  };

  const variantClasses = {
    default: 'bg-blue-600 text-white hover:bg-blue-700',
    outline: 'border border-gray-300 text-gray-700 hover:bg-gray-50',
    ghost: 'text-gray-600 hover:bg-gray-100',
  };

  return (
    <button
      onClick={onClick}
      className={`
        inline-flex items-center gap-2 rounded-lg font-medium transition-colors
        ${sizeClasses[size]}
        ${variantClasses[variant]}
      `}
    >
      <FileText className="w-4 h-4" />
      {label}
    </button>
  );
};

/**
 * Print Button Component
 * Triggers the browser's print dialog
 */

interface PrintButtonProps {
  onClick?: () => void;
  label?: string;
  variant?: 'default' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
}

export const PrintButton: React.FC<PrintButtonProps> = ({
  onClick,
  label = 'Imprimer',
  variant = 'outline',
  size = 'md',
}) => {
  const sizeClasses = {
    sm: 'px-2 py-1 text-xs',
    md: 'px-3 py-2 text-sm',
    lg: 'px-4 py-3 text-base',
  };

  const variantClasses = {
    default: 'bg-gray-600 text-white hover:bg-gray-700',
    outline: 'border border-gray-300 text-gray-700 hover:bg-gray-50',
    ghost: 'text-gray-600 hover:bg-gray-100',
  };

  const handleClick = () => {
    if (onClick) {
      onClick();
    }
    window.print();
  };

  return (
    <button
      onClick={handleClick}
      className={`
        inline-flex items-center gap-2 rounded-lg font-medium transition-colors
        ${sizeClasses[size]}
        ${variantClasses[variant]}
      `}
    >
      <Printer className="w-4 h-4" />
      {label}
    </button>
  );
};
