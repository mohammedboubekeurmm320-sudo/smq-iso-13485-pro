import React, { useState } from 'react';
import Modal from '@/components/ui/Modal';
import { useCreateCAPA } from '@/modules/capas/hooks/useCAPAs';
import { useOrganization } from '@/contexts/OrganizationContext';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { Audit } from '@/types/qms';

interface CreateCAPAModalProps {
  isOpen: boolean;
  onClose: () => void;
  sourceAudit?: Audit;
  sourceNCRId?: string;
  sourceNCRNumber?: string;
  onSuccess?: () => void;
}

const CreateCAPAModal: React.FC<CreateCAPAModalProps> = ({
  isOpen,
  onClose,
  sourceAudit,
  sourceNCRId,
  sourceNCRNumber,
  onSuccess,
}) => {
  const { currentOrganization } = useOrganization();
  const { user } = useAuth();
  const createCAPAMutation = useCreateCAPA();
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Determine source type and pre-fill accordingly
  const getSourceInfo = () => {
    if (sourceNCRId) {
      return {
        source: 'Non-Conformance' as const,
        sourceReferenceId: sourceNCRId,
        sourceDescription: `From NCR ${sourceNCRNumber || sourceNCRId}`,
      };
    }
    if (sourceAudit) {
      return {
        source: 'Internal Audit' as const,
        sourceReferenceId: sourceAudit.id,
        sourceDescription: `From Audit ${sourceAudit.auditNumber} - ${sourceAudit.title}`,
      };
    }
    return {
      source: 'Internal Audit' as const,
      sourceReferenceId: '',
      sourceDescription: '',
    };
  };

  const sourceInfo = getSourceInfo();

  const [formData, setFormData] = useState({
    title: sourceAudit 
      ? `CAPA from Audit ${sourceAudit.auditNumber}` 
      : sourceNCRNumber 
        ? `CAPA from NCR ${sourceNCRNumber}`
        : '',
    type: 'Corrective' as 'Corrective' | 'Preventive',
    source: sourceInfo.source,
    sourceReferenceId: sourceInfo.sourceReferenceId,
    sourceDescription: sourceInfo.sourceDescription,
    description: sourceAudit
      ? `Corrective/Preventive action required based on ${sourceAudit.type} Audit: ${sourceAudit.title}\n\nAudit Department: ${sourceAudit.department}\nLead Auditor: ${sourceAudit.leadAuditor}`
      : sourceNCRNumber
        ? `Corrective/Preventive action required for NCR ${sourceNCRNumber}.`
        : '',
    problemStatement: '',
    priority: 'Medium' as string,
    assignedTo: '',
    dueDate: '',
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentOrganization || !user) {
      toast.error('Organization or user not found');
      return;
    }

    if (!formData.title.trim()) {
      toast.error('CAPA title is required');
      return;
    }

    setIsSubmitting(true);
    try {
      const capa = await createCAPAMutation.mutateAsync({
        input: {
          title: formData.title,
          type: formData.type,
          source: formData.source,
          sourceReferenceId: formData.sourceReferenceId || undefined,
          sourceDescription: formData.sourceDescription || undefined,
          description: formData.description || undefined,
          problemStatement: formData.problemStatement || undefined,
          priority: formData.priority || undefined,
          assignedTo: formData.assignedTo || undefined,
          dueDate: formData.dueDate || undefined,
          linkedNCRId: sourceNCRId,
          linkedAuditId: sourceAudit?.id,
        },
        userId: user.id,
      });

      // Provide appropriate success message based on source
      if (sourceAudit) {
        toast.success('CAPA created successfully and linked to audit!', {
          description: `CAPA ${capa.capaNumber} has been created from Audit ${sourceAudit.auditNumber}.`,
        });
      } else if (sourceNCRId) {
        toast.success('CAPA created successfully and linked to NCR!', {
          description: `CAPA ${capa.capaNumber} has been created from NCR ${sourceNCRNumber}.`,
        });
      } else {
        toast.success('CAPA created successfully!', {
          description: `CAPA ${capa.capaNumber} has been created.`,
        });
      }

      // Reset form
      setFormData({
        title: '',
        type: 'Corrective',
        source: 'Internal Audit',
        sourceReferenceId: '',
        sourceDescription: '',
        description: '',
        problemStatement: '',
        priority: 'Medium',
        assignedTo: '',
        dueDate: '',
      });

      onSuccess?.();
      onClose();
    } catch (err: any) {
      toast.error(err.message || 'Failed to create CAPA');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Determine badge color based on source
  const getSourceBadgeColor = () => {
    if (sourceNCRId) return 'bg-orange';
    if (sourceAudit) return 'bg-amber';
    return 'bg-gray';
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Create CAPA (Corrective/Preventive Action)"
      size="xl"
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Source Information */}
        {(sourceAudit || sourceNCRId) && (
          <div className="bg-amber-50 rounded-lg p-4 border border-amber-200">
            <h4 className="text-sm font-semibold text-amber-800 mb-2 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
              </svg>
              Source Information
            </h4>
            {sourceAudit && (
              <p className="text-sm text-amber-700">
                <strong>Source Audit:</strong> {sourceAudit.auditNumber} - {sourceAudit.title}
              </p>
            )}
            {sourceNCRId && (
              <p className="text-sm text-amber-700">
                <strong>Source NCR:</strong> {sourceNCRNumber || sourceNCRId}
              </p>
            )}
            <p className="text-xs text-amber-600 mt-1">
              This CAPA will be automatically linked to the source for full traceability.
            </p>
          </div>
        )}

        {/* Basic Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Title <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
              placeholder="Enter CAPA title"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Type <span className="text-red-500">*</span>
            </label>
            <select
              name="type"
              value={formData.type}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
            >
              <option value="Corrective">Corrective Action</option>
              <option value="Preventive">Preventive Action</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Source
            </label>
            <select
              name="source"
              value={formData.source}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
            >
              <option value="Internal Audit">Internal Audit</option>
              <option value="Non-Conformance">Non-Conformance</option>
              <option value="Customer Complaint">Customer Complaint</option>
              <option value="Process Monitoring">Process Monitoring</option>
              <option value="Management Review">Management Review</option>
              <option value="Supplier">Supplier</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Priority
            </label>
            <select
              name="priority"
              value={formData.priority}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
            >
              <option value="Critical">Critical</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Assigned To
            </label>
            <input
              type="text"
              name="assignedTo"
              value={formData.assignedTo}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
              placeholder="Responsible person"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Due Date
            </label>
            <input
              type="date"
              name="dueDate"
              value={formData.dueDate}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
            />
          </div>
        </div>

        {/* Description and Problem Statement */}
        <div className="border-t pt-4">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleChange}
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                placeholder="Detailed description of the CAPA context and background..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Problem Statement
              </label>
              <textarea
                name="problemStatement"
                value={formData.problemStatement}
                onChange={handleChange}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                placeholder="Specific problem that needs to be addressed..."
              />
            </div>
          </div>
        </div>

        {/* Form Actions */}
        <div className="flex gap-3 pt-4 border-t">
          <button
            type="submit"
            disabled={isSubmitting}
            className="flex-1 px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? 'Creating CAPA...' : 'Create CAPA'}
          </button>
          <button
            type="button"
            onClick={onClose}
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
        </div>
      </form>
    </Modal>
  );
};

export default CreateCAPAModal;
