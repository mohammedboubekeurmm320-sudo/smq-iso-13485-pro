import React, { useEffect } from 'react';
import * as Sentry from '@sentry/react';

interface SentryProviderProps {
  children: React.ReactNode;
}

export function SentryProvider({ children }: SentryProviderProps) {
  const sentryDsn = import.meta.env.VITE_SENTRY_DSN;

  useEffect(() => {
    if (sentryDsn) {
      Sentry.init({
        dsn: sentryDsn,
        integrations: [
          Sentry.browserTracingIntegration(),
          Sentry.replayIntegration({
            maskAllText: true,
            blockAllMedia: true,
          }),
        ],
        // Performance monitoring
        tracesSampleRate: 1.0,
        // Session replay
        replaysSessionSampleRate: 0.1,
        replaysOnErrorSampleRate: 1.0,
        // Environment
        environment: import.meta.env.VITE_ENVIRONMENT || 'development',
        // Release tracking
        release: `qms-app@${import.meta.env.VITE_APP_VERSION || '1.0.0'}`,
        // Filter events
        beforeSend(event, hint) {
          // Filter out common non-critical errors
          const error = hint.originalException;
          if (error instanceof Error) {
            // Ignore network errors that are handled by the app
            if (error.message.includes('Failed to fetch')) {
              return null;
            }
            // Ignore aborted requests
            if (error.name === 'AbortError') {
              return null;
            }
          }
          return event;
        },
      });
    }
  }, [sentryDsn]);

  return <>{children}</>;
}

// Higher-order component for error boundary
export const withErrorBoundary = (Component: React.ComponentType<any>) => {
  return Sentry.withErrorBoundary(Component, {
    fallback: ({ error }) => (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="text-center p-8 bg-white rounded-lg shadow-lg">
          <h1 className="text-2xl font-bold text-red-600 mb-4">
            Une erreur s'est produite
          </h1>
          <p className="text-gray-600 mb-4">
            Nous nous excusons pour la gêne occasionnée. Veuillez rafraîchir la page.
          </p>
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Rafraîchir la page
          </button>
          {import.meta.env.DEV && (
            <details className="mt-4 text-left">
              <summary className="cursor-pointer text-sm text-gray-500">
                Détails de l'erreur
              </summary>
              <pre className="mt-2 p-2 bg-gray-100 rounded text-xs overflow-auto">
                {error?.toString()}
              </pre>
            </details>
          )}
        </div>
      </div>
    ),
  });
};

// Hook for programmatic error reporting
export function useErrorTracking() {
  const captureException = (error: Error, context?: Record<string, any>) => {
    if (import.meta.env.VITE_SENTRY_DSN) {
      Sentry.captureException(error, {
        extra: context,
      });
    } else {
      console.error('Error captured:', error, context);
    }
  };

  const captureMessage = (message: string, level: Sentry.SeverityLevel = 'info') => {
    if (import.meta.env.VITE_SENTRY_DSN) {
      Sentry.captureMessage(message, level);
    } else {
      console.log(`[${level}]`, message);
    }
  };

  const setUser = (user: { id: string; email: string } | null) => {
    if (import.meta.env.VITE_SENTRY_DSN) {
      Sentry.setUser(user);
    }
  };

  const addBreadcrumb = (breadcrumb: Sentry.Breadcrumb) => {
    if (import.meta.env.VITE_SENTRY_DSN) {
      Sentry.addBreadcrumb(breadcrumb);
    }
  };

  return {
    captureException,
    captureMessage,
    setUser,
    addBreadcrumb,
  };
}

export default SentryProvider;
