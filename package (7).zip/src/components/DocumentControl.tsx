import React, { useState, useMemo } from 'react';
import DataTable from './ui/DataTable';
import StatusBadge from './ui/StatusBadge';
import Modal from './ui/Modal';
import { useDocuments, useSignDocument, useCreateDocument, useUpdateDocument } from '../modules/documents/hooks/useDocuments';
import { Document } from '../types/qms';
import { useAuth } from '../contexts/AuthContext';
import { useOrganization } from '../contexts/OrganizationContext';
import { toast } from 'sonner';
import CreateTrainingModal from './CreateTrainingModal';
import EditDocumentForm from './EditDocumentForm';

const DocumentControl: React.FC = () => {
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const [showNewDocModal, setShowNewDocModal] = useState(false);
  const [showSignModal, setShowSignModal] = useState(false);
  const [showCreateTrainingModal, setShowCreateTrainingModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [signingDoc, setSigningDoc] = useState<Document | null>(null);
  const [signPassword, setSignPassword] = useState('');
  const [signReason, setSignReason] = useState('Approver');

  const [filterType, setFilterType] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // New document form state
  const [newDocData, setNewDocData] = useState({
    documentNumber: '',
    title: '',
    type: 'SOP' as string,
    description: '',
    owner: '',
    department: '',
    version: '1.0',
    classification: 'Internal' as string,
    retentionPeriod: '7 years' as string,
    effectiveDate: '',
    nextReviewDate: '',
    scope: '',
    references: '',
    attachments: [] as string[],
    // Type-specific fields
    purpose: '',
    definitions: '',
    responsibilities: '',
    procedure: '',
    linkedSOP: '',
    equipmentList: '',
    safetyWarnings: '',
    formFields: '',
    dataRetention: '',
    policyStatement: '',
    regulatoryReference: '',
    materialNumber: '',
    dimensions: '',
    technicalSummary: '',
    applicableStandards: '',
    riskManagementRef: '',
    hazardMatrix: [] as { hazard: string; severity: number; probability: number; detection: number; mitigation: string; rpn: number }[],
    iqChecklist: '',
    oqSteps: '',
    pqCriteria: '',
    sampleSize: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { hasPermission, user } = useAuth();
  const { currentOrganization } = useOrganization();

  // Use React Query hooks for data fetching
  const { data: documents = [], isLoading, error, refetch } = useDocuments({
    type: filterType !== 'all' ? filterType : undefined,
    status: filterStatus !== 'all' ? filterStatus : undefined,
  });

  // Use mutations
  const signDocumentMutation = useSignDocument();
  const createDocumentMutation = useCreateDocument();
  const updateDocumentMutation = useUpdateDocument();

  // Handle document type change with warning
  const handleTypeChange = (newType: string) => {
    if (newDocData.type !== newType && (newDocData.title || newDocData.description || newDocData.scope)) {
      const confirmChange = window.confirm(
        'Changing the document type may lose specific data entered for the previous type. Common fields (title, description, scope) will be preserved. Do you want to continue?'
      );
      if (!confirmChange) return;
      
      // Clear type-specific fields when changing type
      setNewDocData({
        ...newDocData,
        type: newType,
        purpose: '',
        definitions: '',
        responsibilities: '',
        procedure: '',
        linkedSOP: '',
        equipmentList: '',
        safetyWarnings: '',
        formFields: '',
        dataRetention: '',
        policyStatement: '',
        regulatoryReference: '',
        materialNumber: '',
        dimensions: '',
        technicalSummary: '',
        applicableStandards: '',
        riskManagementRef: '',
        hazardMatrix: [],
        iqChecklist: '',
        oqSteps: '',
        pqCriteria: '',
        sampleSize: '',
      });
    } else {
      setNewDocData({...newDocData, type: newType});
    }
  };

  const handleSign = async () => {
    if (!signingDoc || !user || !currentOrganization) return;

    try {
      await signDocumentMutation.mutateAsync({
        documentId: signingDoc.id,
        userId: currentOrganization.id,
        userEmail: user.email || '',
        password: signPassword,
        reason: signReason,
      });
      toast.success('Document signed successfully!');
      setShowSignModal(false);
      setSignPassword('');
      setSigningDoc(null);
    } catch (err: any) {
      toast.error(err.message || 'Failed to sign document');
    }
  };

  // Handle new document creation
  const handleCreateDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentOrganization || !user) {
      toast.error('Authentication required');
      return;
    }

    // Basic validation
    if (!newDocData.documentNumber.trim()) {
      toast.error('Document number is required');
      return;
    }
    if (!newDocData.title.trim()) {
      toast.error('Document title is required');
      return;
    }
    if (!newDocData.department) {
      toast.error('Department is required');
      return;
    }

    // Type-specific validation
    if (newDocData.type === 'SOP' && !newDocData.purpose.trim()) {
      toast.error('SOP requires a Purpose field');
      return;
    }
    if (newDocData.type === 'SOP' && !newDocData.responsibilities.trim()) {
      toast.error('SOP requires Responsibilities field');
      return;
    }
    if (newDocData.type === 'WI' && !newDocData.linkedSOP) {
      toast.error('ISO 13485 requires Work Instructions to be linked to a parent SOP');
      return;
    }
    if (newDocData.type === 'Form' && !newDocData.formFields.trim()) {
      toast.error('Form requires field definitions');
      return;
    }
    if (newDocData.type === 'Form' && !newDocData.dataRetention) {
      toast.error('Form requires data retention period');
      return;
    }
    if (newDocData.type === 'Policy' && !newDocData.policyStatement.trim()) {
      toast.error('Policy requires a policy statement');
      return;
    }
    if (newDocData.type === 'Policy' && !newDocData.regulatoryReference) {
      toast.error('Policy requires regulatory reference');
      return;
    }
    if (newDocData.type === 'Specification' && !newDocData.materialNumber.trim()) {
      toast.error('Specification requires material/part number');
      return;
    }
    if (newDocData.type === 'Technical' && !newDocData.technicalSummary.trim()) {
      toast.error('Technical specification requires technical summary');
      return;
    }
    if (newDocData.type === 'Risk Analysis' && !newDocData.riskManagementRef.trim()) {
      toast.error('Risk Analysis requires Risk Management Plan reference');
      return;
    }
    if (newDocData.type === 'Risk Analysis' && newDocData.hazardMatrix.length === 0) {
      toast.error('Risk Analysis requires at least one hazard in the matrix');
      return;
    }

    setIsSubmitting(true);
    try {
      await createDocumentMutation.mutateAsync({
        input: {
          documentNumber: newDocData.documentNumber,
          title: newDocData.title,
          type: newDocData.type,
          description: newDocData.description,
          department: newDocData.department,
          owner: newDocData.owner || user.email || 'Unknown',
          version: newDocData.version,
          classification: newDocData.classification as 'Internal' | 'External' | 'Regulatory' | 'Confidential',
          retentionPeriod: newDocData.retentionPeriod,
          effectiveDate: newDocData.effectiveDate,
          nextReviewDate: newDocData.nextReviewDate,
          scope: newDocData.scope,
          references: newDocData.references,
        },
        userId: currentOrganization.id,
      });
      
      toast.success('Document created successfully!', {
        description: `Document ${newDocData.documentNumber} has been created and is ready for review.`,
      });
      
      // Reset form and close modal
      setNewDocData({
        documentNumber: '',
        title: '',
        type: 'SOP',
        description: '',
        owner: '',
        department: '',
        version: '1.0',
        classification: 'Internal',
        retentionPeriod: '7 years',
        effectiveDate: '',
        nextReviewDate: '',
        scope: '',
        references: '',
        attachments: [],
        // Type-specific fields reset
        purpose: '',
        definitions: '',
        responsibilities: '',
        procedure: '',
        linkedSOP: '',
        equipmentList: '',
        safetyWarnings: '',
        formFields: '',
        dataRetention: '',
        policyStatement: '',
        regulatoryReference: '',
        materialNumber: '',
        dimensions: '',
        technicalSummary: '',
        applicableStandards: '',
        riskManagementRef: '',
        hazardMatrix: [],
        iqChecklist: '',
        oqSteps: '',
        pqCriteria: '',
        sampleSize: '',
      });
      setShowNewDocModal(false);
      
      // Refresh the document list
      refetch();
    } catch (err: any) {
      toast.error(err.message || 'Failed to create document');
    } finally {
      setIsSubmitting(false);
    }
  };

  const canCreate = hasPermission('canCreateDocuments');
  const canEdit = hasPermission('canEditDocuments');
  const canApprove = hasPermission('canApproveDocuments');
  const canExport = hasPermission('canExportData');
  
  // Document visibility permissions (ISO 13485 compliance)
  const canViewDraft = hasPermission('canViewDraftDocuments');
  const canViewInReview = hasPermission('canViewInReviewDocuments');
  const canViewApproved = hasPermission('canViewApprovedDocuments');
  const canViewObsolete = hasPermission('canViewObsoleteDocuments');

  const filteredDocuments = useMemo(() => {
    return documents.filter(doc => {
      // Filter by type
      if (filterType !== 'all' && doc.type !== filterType) return false;
      
      // Filter by status based on user permissions
      if (filterStatus !== 'all' && doc.status !== filterStatus) return false;
      
      // Apply role-based visibility restrictions
      if (doc.status === 'Draft' && !canViewDraft) return false;
      if (doc.status === 'In Review' && !canViewInReview) return false;
      if (doc.status === 'Approved' && !canViewApproved) return false;
      if (doc.status === 'Obsolete' && !canViewObsolete) return false;
      
      return true;
    });
  }, [documents, filterType, filterStatus, canViewDraft, canViewInReview, canViewApproved, canViewObsolete]);

  const columns = [
    { key: 'documentNumber', header: 'Document #', sortable: true },
    { key: 'title', header: 'Title', sortable: true },
    { 
      key: 'type', 
      header: 'Type',
      render: (doc: Document) => (
        <span className={`px-2 py-1 rounded text-xs font-medium ${
          doc.type === 'SOP' ? 'bg-blue-100 text-blue-700' :
          doc.type === 'WI' ? 'bg-purple-100 text-purple-700' :
          doc.type === 'Form' ? 'bg-green-100 text-green-700' :
          doc.type === 'Policy' ? 'bg-red-100 text-red-700' :
          'bg-gray-100 text-gray-700'
        }`}>
          {doc.type}
        </span>
      )
    },
    { key: 'version', header: 'Version', sortable: true },
    { 
      key: 'status', 
      header: 'Status',
      render: (doc: Document) => <StatusBadge status={doc.status} />
    },
    { key: 'owner', header: 'Owner', sortable: true },
    { key: 'effectiveDate', header: 'Effective Date', sortable: true },
    { key: 'nextReview', header: 'Next Review', sortable: true },
  ];

  const stats = {
    total: documents.length,
    approved: documents.filter(d => d.status === 'Approved').length,
    inReview: documents.filter(d => d.status === 'In Review').length,
    draft: documents.filter(d => d.status === 'Draft').length,
  };

  return (
    <div className="p-6 space-y-6">
      {/* Loading State */}
      {isLoading && (
        <div className="flex items-center justify-center py-12">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-4 text-gray-500">Loading documents...</p>
          </div>
        </div>
      )}

      {/* Error State */}
      {error && !isLoading && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
          <div className="flex items-center gap-3">
            <svg className="w-5 h-5 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            <div>
              <p className="text-red-700 font-medium">Error loading documents</p>
              <p className="text-red-600 text-sm">{error.message}</p>
            </div>
            <button 
              onClick={() => refetch()}
              className="ml-auto px-3 py-1 bg-red-100 text-red-700 rounded hover:bg-red-200"
            >
              Retry
            </button>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Document Control</h2>
          <p className="text-gray-500 mt-1">Manage controlled documents per ISO 13485 Section 4.2.4</p>
        </div>
        <button
          onClick={() => setShowNewDocModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
          New Document
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
              <p className="text-sm text-gray-500">Total Documents</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <div>
              <p className="text-2xl font-bold text-green-600">{stats.approved}</p>
              <p className="text-sm text-gray-500">Approved</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
            </div>
            <div>
              <p className="text-2xl font-bold text-blue-600">{stats.inReview}</p>
              <p className="text-sm text-gray-500">In Review</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
              </svg>
            </div>
            <div>
              <p className="text-2xl font-bold text-yellow-600">{stats.draft}</p>
              <p className="text-sm text-gray-500">Draft</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Document Type</label>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          >
            <option value="all">All Types</option>
            <option value="SOP">SOP</option>
            <option value="WI">Work Instruction</option>
            <option value="Form">Form</option>
            <option value="Policy">Policy</option>
            <option value="Specification">Specification</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          >
            <option value="all">All Statuses</option>
            {canViewApproved && <option value="Approved">Approved</option>}
            {canViewInReview && <option value="In Review">In Review</option>}
            {canViewDraft && <option value="Draft">Draft</option>}
            {canViewObsolete && <option value="Obsolete">Obsolete</option>}
          </select>
        </div>
        <div className="ml-auto flex items-center gap-2">
          {canExport && (
            <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
              </svg>
              Export
            </button>
          )}
        </div>
      </div>

      {/* Data Table */}
      <DataTable
        data={filteredDocuments}
        columns={columns}
        onRowClick={(doc) => setSelectedDocument(doc)}
        searchPlaceholder="Search documents..."
        searchKeys={['documentNumber', 'title', 'owner', 'department']}
      />

      {/* Document Detail Modal */}
      <Modal
        isOpen={!!selectedDocument}
        onClose={() => setSelectedDocument(null)}
        title="Document Details"
        size="lg"
      >
        {selectedDocument && (
          <div className="space-y-6">
            <div className="flex items-start justify-between">
              <div>
                <h4 className="text-lg font-semibold text-gray-900">{selectedDocument.title}</h4>
                <p className="text-sm text-blue-600 font-medium">{selectedDocument.documentNumber}</p>
              </div>
              <StatusBadge status={selectedDocument.status} />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Type</p>
                <p className="font-medium text-gray-900">{selectedDocument.type}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Version</p>
                <p className="font-medium text-gray-900">{selectedDocument.version}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Owner</p>
                <p className="font-medium text-gray-900">{selectedDocument.owner}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Department</p>
                <p className="font-medium text-gray-900">{selectedDocument.department}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Effective Date</p>
                <p className="font-medium text-gray-900">{selectedDocument.effectiveDate}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Next Review</p>
                <p className="font-medium text-gray-900">{selectedDocument.nextReview}</p>
              </div>
            </div>

            <div>
              <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Description</p>
              <p className="text-gray-700">{selectedDocument.description}</p>
            </div>

            <div className="flex items-center gap-3 pt-4 border-t">
              <button 
                onClick={() => setShowViewModal(true)}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                View Document
              </button>
              {canEdit && selectedDocument.status === 'Draft' && (
                <button 
                  onClick={() => setShowEditModal(true)}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Edit
                </button>
              )}
              {canApprove && selectedDocument.status === 'In Review' && (
                <button 
                  onClick={() => {
                    setSigningDoc(selectedDocument);
                    setShowSignModal(true);
                  }}
                  className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                >
                  Sign & Approve
                </button>
              )}
              <button className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                Version History
              </button>
            </div>

            {/* Require Training Action */}
            {selectedDocument.status === 'Approved' && (
              <div className="mt-4 p-4 bg-green-50 rounded-lg border border-green-200">
                <h4 className="text-sm font-semibold text-green-800 mb-3 flex items-center gap-2">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                  </svg>
                  Document Training
                </h4>
                <button 
                  onClick={() => setShowCreateTrainingModal(true)}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                  </svg>
                  Require Training on This Document
                </button>
                <p className="text-xs text-green-700 mt-2">
                  Create training assignment for employees to review and acknowledge this document.
                </p>
              </div>
            )}
          </div>
        )}
      </Modal>

      {/* New Document Modal */}
      <Modal
        isOpen={showNewDocModal}
        onClose={() => setShowNewDocModal(false)}
        title="Create New Document"
        size="lg"
      >
        <form className="space-y-6" onSubmit={handleCreateDocument}>
          {/* ISO 13485 Section 4.2.4 - Document Information */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="font-medium text-blue-900 mb-2">ISO 13485:2016 Section 4.2.4 Compliant</h4>
            <p className="text-sm text-blue-700">All controlled documents must include identification, version control, and approval signatures.</p>
          </div>

          {/* Document Identification */}
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-3 pb-2 border-b">Document Identification</h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Document Number <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={newDocData.documentNumber}
                  onChange={(e) => setNewDocData({...newDocData, documentNumber: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="e.g., SOP-QMS-001"
                  required
                />
                <p className="text-xs text-gray-500 mt-1">Unique identifier following your document numbering system</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Version <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={newDocData.version}
                  onChange={(e) => setNewDocData({...newDocData, version: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="e.g., 1.0"
                  required
                />
              </div>
            </div>
          </div>

          {/* Document Type & Classification */}
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-3 pb-2 border-b">Classification</h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Document Type <span className="text-red-500">*</span>
                </label>
                <select
                  value={newDocData.type}
                  onChange={(e) => handleTypeChange(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  required
                >
                  <option value="SOP">SOP - Standard Operating Procedure</option>
                  <option value="WI">WI - Work Instruction</option>
                  <option value="Form">Form</option>
                  <option value="Policy">Policy</option>
                  <option value="Specification">Specification</option>
                  <option value="Technical">Technical Specification</option>
                  <option value="Risk Analysis">Risk Analysis</option>
                  <option value="Validation Protocol">Validation Protocol</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Classification</label>
                <select
                  value={newDocData.classification}
                  onChange={(e) => setNewDocData({...newDocData, classification: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                >
                  <option value="Internal">Internal</option>
                  <option value="External">External (Customer/Supplier)</option>
                  <option value="Regulatory">Regulatory (FDA/CE)</option>
                  <option value="Confidential">Confidential</option>
                </select>
              </div>
            </div>
          </div>

          {/* Title & Description */}
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-3 pb-2 border-b">Content</h4>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Title <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={newDocData.title}
                  onChange={(e) => setNewDocData({...newDocData, title: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="Enter document title"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description / Purpose</label>
                <textarea
                  rows={3}
                  value={newDocData.description}
                  onChange={(e) => setNewDocData({...newDocData, description: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="Describe the purpose and scope of this document"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Scope</label>
                <textarea
                  rows={2}
                  value={newDocData.scope}
                  onChange={(e) => setNewDocData({...newDocData, scope: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="Define where and how this document applies"
                />
              </div>
            </div>
          </div>

          {/* Dynamic Fields based on Document Type */}
          {newDocData.type === 'SOP' && (
            <div>
              <h4 className="text-sm font-semibold text-gray-900 mb-3 pb-2 border-b">SOP Specific Fields (ISO 13485:7.5)</h4>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Purpose <span className="text-red-500">*</span></label>
                  <textarea
                    rows={2}
                    value={newDocData.purpose}
                    onChange={(e) => setNewDocData({...newDocData, purpose: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="Explain the objective of this procedure"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Definitions</label>
                  <textarea
                    rows={2}
                    value={newDocData.definitions}
                    onChange={(e) => setNewDocData({...newDocData, definitions: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="Key terms and abbreviations used in this procedure"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Responsibilities <span className="text-red-500">*</span></label>
                  <textarea
                    rows={3}
                    value={newDocData.responsibilities}
                    onChange={(e) => setNewDocData({...newDocData, responsibilities: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="Define roles and responsibilities (e.g., QA: Approve, Production: Execute)"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Procedure Details <span className="text-red-500">*</span></label>
                  <textarea
                    rows={6}
                    value={newDocData.procedure}
                    onChange={(e) => setNewDocData({...newDocData, procedure: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="Step-by-step procedure instructions"
                    required
                  />
                </div>
              </div>
            </div>
          )}

          {newDocData.type === 'WI' && (
            <div>
              <h4 className="text-sm font-semibold text-gray-900 mb-3 pb-2 border-b">Work Instruction Specific Fields</h4>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Linked SOP <span className="text-red-500">*</span></label>
                  <select
                    value={newDocData.linkedSOP}
                    onChange={(e) => setNewDocData({...newDocData, linkedSOP: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    required
                  >
                    <option value="">Select Parent SOP</option>
                    <option value="SOP-QMS-001">SOP-QMS-001 - Document Control</option>
                    <option value="SOP-QMS-002">SOP-QMS-002 - Change Control</option>
                    <option value="SOP-QMS-003">SOP-QMS-003 - CAPA Management</option>
                    <option value="SOP-QMS-004">SOP-QMS-004 - Internal Audit</option>
                    <option value="SOP-QMS-005">SOP-QMS-005 - Supplier Evaluation</option>
                  </select>
                  <p className="text-xs text-gray-500 mt-1">ISO 13485 requires traceability to parent procedure</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Equipment / Tools Required</label>
                  <textarea
                    rows={2}
                    value={newDocData.equipmentList}
                    onChange={(e) => setNewDocData({...newDocData, equipmentList: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="List equipment, tools, or materials needed"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Safety Warnings</label>
                  <textarea
                    rows={2}
                    value={newDocData.safetyWarnings}
                    onChange={(e) => setNewDocData({...newDocData, safetyWarnings: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none"
                    placeholder="Critical safety warnings and precautions"
                  />
                </div>
              </div>
            </div>
          )}

          {newDocData.type === 'Form' && (
            <div>
              <h4 className="text-sm font-semibold text-gray-900 mb-3 pb-2 border-b">Form Specific Fields</h4>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Form Fields Definition <span className="text-red-500">*</span></label>
                  <textarea
                    rows={4}
                    value={newDocData.formFields}
                    onChange={(e) => setNewDocData({...newDocData, formFields: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="Define all fields in the form: Field Name | Type | Required | Validation"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Data Retention Period <span className="text-red-500">*</span></label>
                  <select
                    value={newDocData.dataRetention}
                    onChange={(e) => setNewDocData({...newDocData, dataRetention: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    required
                  >
                    <option value="">Select Retention Period</option>
                    <option value="1 year">1 year</option>
                    <option value="3 years">3 years</option>
                    <option value="5 years">5 years</option>
                    <option value="7 years">7 years (ISO 13485 minimum)</option>
                    <option value="10 years">10 years</option>
                    <option value="Lifetime">Lifetime (Device lifecycle)</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {newDocData.type === 'Policy' && (
            <div>
              <h4 className="text-sm font-semibold text-gray-900 mb-3 pb-2 border-b">Policy Specific Fields</h4>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Policy Statement <span className="text-red-500">*</span></label>
                  <textarea
                    rows={4}
                    value={newDocData.policyStatement}
                    onChange={(e) => setNewDocData({...newDocData, policyStatement: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="Official policy statement and commitments"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Regulatory Reference <span className="text-red-500">*</span></label>
                  <select
                    value={newDocData.regulatoryReference}
                    onChange={(e) => setNewDocData({...newDocData, regulatoryReference: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    required
                  >
                    <option value="">Select Regulatory Reference</option>
                    <option value="ISO 13485:2016">ISO 13485:2016</option>
                    <option value="FDA 21 CFR Part 820">FDA 21 CFR Part 820</option>
                    <option value="EU MDR 2017/745">EU MDR 2017/745</option>
                    <option value="ISO 9001:2015">ISO 9001:2015</option>
                    <option value="Internal">Internal Policy</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {newDocData.type === 'Specification' && (
            <div>
              <h4 className="text-sm font-semibold text-gray-900 mb-3 pb-2 border-b">Specification Specific Fields</h4>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Material / Part Number <span className="text-red-500">*</span></label>
                  <input
                    type="text"
                    value={newDocData.materialNumber}
                    onChange={(e) => setNewDocData({...newDocData, materialNumber: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="e.g., MAT-ABC-001"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Dimensions & Tolerances</label>
                  <textarea
                    rows={3}
                    value={newDocData.dimensions}
                    onChange={(e) => setNewDocData({...newDocData, dimensions: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="Specify dimensions, tolerances, and acceptance criteria"
                  />
                </div>
              </div>
            </div>
          )}

          {newDocData.type === 'Technical' && (
            <div>
              <h4 className="text-sm font-semibold text-gray-900 mb-3 pb-2 border-b">Technical Specification Specific Fields</h4>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Technical Summary <span className="text-red-500">*</span></label>
                  <textarea
                    rows={4}
                    value={newDocData.technicalSummary}
                    onChange={(e) => setNewDocData({...newDocData, technicalSummary: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="Technical overview and specifications"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Applicable Standards</label>
                  <textarea
                    rows={2}
                    value={newDocData.applicableStandards}
                    onChange={(e) => setNewDocData({...newDocData, applicableStandards: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="List applicable standards (e.g., IEC 60601, ISO 14971)"
                  />
                </div>
              </div>
            </div>
          )}

          {newDocData.type === 'Risk Analysis' && (
            <div>
              <h4 className="text-sm font-semibold text-gray-900 mb-3 pb-2 border-b">Risk Analysis Specific Fields (ISO 14971)</h4>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Risk Management Plan Reference <span className="text-red-500">*</span></label>
                  <input
                    type="text"
                    value={newDocData.riskManagementRef}
                    onChange={(e) => setNewDocData({...newDocData, riskManagementRef: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none"
                    placeholder="e.g., RMP-2024-001"
                    required
                  />
                </div>
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <label className="block text-sm font-medium text-red-800">Hazard Matrix</label>
                    <button
                      type="button"
                      onClick={() => {
                        const newMatrix = [...newDocData.hazardMatrix, { hazard: '', severity: 1, probability: 1, detection: 1, mitigation: '', rpn: 1 }];
                        setNewDocData({...newDocData, hazardMatrix: newMatrix});
                      }}
                      className="text-xs px-2 py-1 bg-red-600 text-white rounded hover:bg-red-700"
                    >
                      + Add Hazard
                    </button>
                  </div>
                  {newDocData.hazardMatrix.length === 0 ? (
                    <p className="text-sm text-red-600 text-center py-4">No hazards added. Click "Add Hazard" to start risk analysis.</p>
                  ) : (
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {newDocData.hazardMatrix.map((hazard, index) => (
                        <div key={index} className="bg-white border border-red-200 rounded p-3">
                          <div className="grid grid-cols-4 gap-2 mb-2">
                            <input
                              type="text"
                              placeholder="Hazard description"
                              value={hazard.hazard}
                              onChange={(e) => {
                                const newMatrix = [...newDocData.hazardMatrix];
                                newMatrix[index].hazard = e.target.value;
                                newMatrix[index].rpn = newMatrix[index].severity * newMatrix[index].probability * newMatrix[index].detection;
                                setNewDocData({...newDocData, hazardMatrix: newMatrix});
                              }}
                              className="col-span-4 px-2 py-1 border border-gray-300 rounded text-sm"
                            />
                            <select
                              value={hazard.severity}
                              onChange={(e) => {
                                const newMatrix = [...newDocData.hazardMatrix];
                                newMatrix[index].severity = Number(e.target.value);
                                newMatrix[index].rpn = newMatrix[index].severity * newMatrix[index].probability * newMatrix[index].detection;
                                setNewDocData({...newDocData, hazardMatrix: newMatrix});
                              }}
                              className="px-2 py-1 border border-gray-300 rounded text-sm"
                            >
                              <option value={1}>S:1</option>
                              <option value={2}>S:2</option>
                              <option value={3}>S:3</option>
                              <option value={4}>S:4</option>
                              <option value={5}>S:5</option>
                            </select>
                            <select
                              value={hazard.probability}
                              onChange={(e) => {
                                const newMatrix = [...newDocData.hazardMatrix];
                                newMatrix[index].probability = Number(e.target.value);
                                newMatrix[index].rpn = newMatrix[index].severity * newMatrix[index].probability * newMatrix[index].detection;
                                setNewDocData({...newDocData, hazardMatrix: newMatrix});
                              }}
                              className="px-2 py-1 border border-gray-300 rounded text-sm"
                            >
                              <option value={1}>P:1</option>
                              <option value={2}>P:2</option>
                              <option value={3}>P:3</option>
                              <option value={4}>P:4</option>
                              <option value={5}>P:5</option>
                            </select>
                            <select
                              value={hazard.detection}
                              onChange={(e) => {
                                const newMatrix = [...newDocData.hazardMatrix];
                                newMatrix[index].detection = Number(e.target.value);
                                newMatrix[index].rpn = newMatrix[index].severity * newMatrix[index].probability * newMatrix[index].detection;
                                setNewDocData({...newDocData, hazardMatrix: newMatrix});
                              }}
                              className="px-2 py-1 border border-gray-300 rounded text-sm"
                            >
                              <option value={1}>D:1</option>
                              <option value={2}>D:2</option>
                              <option value={3}>D:3</option>
                              <option value={4}>D:4</option>
                              <option value={5}>D:5</option>
                            </select>
                            <div className={`px-2 py-1 rounded text-center text-sm font-bold ${
                              hazard.rpn >= 80 ? 'bg-red-600 text-white' :
                              hazard.rpn >= 40 ? 'bg-orange-500 text-white' :
                              'bg-green-500 text-white'
                            }`}>
                              RPN: {hazard.rpn}
                            </div>
                          </div>
                          <textarea
                            placeholder="Mitigation measures"
                            value={hazard.mitigation}
                            onChange={(e) => {
                              const newMatrix = [...newDocData.hazardMatrix];
                              newMatrix[index].mitigation = e.target.value;
                              setNewDocData({...newDocData, hazardMatrix: newMatrix});
                            }}
                            className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
                            rows={2}
                          />
                        </div>
                      ))}
                    </div>
                  )}
                  <p className="text-xs text-red-600 mt-2">RPN = Severity × Probability × Detection (Range: 1-125)</p>
                </div>
              </div>
            </div>
          )}

          {newDocData.type === 'Validation Protocol' && (
            <div>
              <h4 className="text-sm font-semibold text-gray-900 mb-3 pb-2 border-b">Validation Protocol Specific Fields (ISO 13485:7.3)</h4>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Installation Qualification (IQ) Checklist</label>
                  <textarea
                    rows={3}
                    value={newDocData.iqChecklist}
                    onChange={(e) => setNewDocData({...newDocData, iqChecklist: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="IQ requirements and verification items"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Operational Qualification (OQ) Steps</label>
                  <textarea
                    rows={3}
                    value={newDocData.oqSteps}
                    onChange={(e) => setNewDocData({...newDocData, oqSteps: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="OQ test procedures and parameters"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Performance Qualification (PQ) Criteria</label>
                  <textarea
                    rows={3}
                    value={newDocData.pqCriteria}
                    onChange={(e) => setNewDocData({...newDocData, pqCriteria: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="PQ acceptance criteria and test results"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Sample Size Justification</label>
                  <input
                    type="text"
                    value={newDocData.sampleSize}
                    onChange={(e) => setNewDocData({...newDocData, sampleSize: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="Statistical justification for sample size"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Ownership & Department */}
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-3 pb-2 border-b">Ownership (ISO 13485:5.5.2)</h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Department <span className="text-red-500">*</span>
                </label>
                <select
                  value={newDocData.department}
                  onChange={(e) => setNewDocData({...newDocData, department: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  required
                >
                  <option value="">Select Department</option>
                  <option value="Quality Assurance">Quality Assurance</option>
                  <option value="Production">Production</option>
                  <option value="R&D">Research & Development</option>
                  <option value="Supply Chain">Supply Chain</option>
                  <option value="Human Resources">Human Resources</option>
                  <option value="Regulatory Affairs">Regulatory Affairs</option>
                  <option value="Engineering">Engineering</option>
                  <option value="Quality Control">Quality Control</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Document Owner</label>
                <input
                  type="text"
                  value={newDocData.owner}
                  onChange={(e) => setNewDocData({...newDocData, owner: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="Person responsible for this document"
                />
              </div>
            </div>
          </div>

          {/* Dates & Review */}
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-3 pb-2 border-b">Control Information</h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Effective Date</label>
                <input
                  type="date"
                  value={newDocData.effectiveDate}
                  onChange={(e) => setNewDocData({...newDocData, effectiveDate: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Next Review Date</label>
                <input
                  type="date"
                  value={newDocData.nextReviewDate}
                  onChange={(e) => setNewDocData({...newDocData, nextReviewDate: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
                <p className="text-xs text-gray-500 mt-1">ISO 13485 requires periodic review</p>
              </div>
            </div>
          </div>

          {/* Retention & References */}
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-3 pb-2 border-b">Records Management</h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Retention Period</label>
                <select
                  value={newDocData.retentionPeriod}
                  onChange={(e) => setNewDocData({...newDocData, retentionPeriod: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                >
                  <option value="1 year">1 year</option>
                  <option value="3 years">3 years</option>
                  <option value="5 years">5 years</option>
                  <option value="7 years">7 years</option>
                  <option value="10 years">10 years</option>
                  <option value="Lifetime">Lifetime (Device lifecycle)</option>
                  <option value="Permanent">Permanent</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Related Documents</label>
                <input
                  type="text"
                  value={newDocData.references}
                  onChange={(e) => setNewDocData({...newDocData, references: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="Related SOPs, forms, specifications"
                />
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex items-center gap-3 pt-4 border-t">
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Creating...
                </>
              ) : (
                <>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                  </svg>
                  Create Document
                </>
              )}
            </button>
            <button
              type="button"
              onClick={() => setShowNewDocModal(false)}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </Modal>

      {/* Electronic Signature Modal */}
      <Modal
        isOpen={showSignModal}
        onClose={() => setShowSignModal(false)}
        title="Electronic Signature"
      >
        <div className="space-y-4">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <svg className="w-5 h-5 text-blue-600 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <div>
                <p className="text-sm text-blue-700 font-medium">ISO 13485 Compliance</p>
                <p className="text-xs text-blue-600">Electronic signatures must comply with FDA 21 CFR Part 11 requirements.</p>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Document</label>
            <p className="text-gray-900 font-medium">{signingDoc?.title}</p>
            <p className="text-sm text-gray-500">{signingDoc?.documentNumber} v{signingDoc?.version}</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Signature Reason</label>
            <select
              value={signReason}
              onChange={(e) => setSignReason(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
            >
              <option value="Author">Author - Document Creation</option>
              <option value="Reviewer">Reviewer - Technical Review</option>
              <option value="Approver">Approver - Final Approval</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Password Verification</label>
            <input
              type="password"
              value={signPassword}
              onChange={(e) => setSignPassword(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              placeholder="Enter your password to sign"
            />
            <p className="text-xs text-gray-500 mt-1">Required by FDA 21 CFR Part 11 for electronic signatures</p>
          </div>

          <div className="bg-gray-50 border border-gray-200 rounded-lg p-3">
            <p className="text-xs text-gray-600">
              By signing this document, I confirm that the information is accurate and complete to the best of my knowledge. 
              This electronic signature has the same legal effect as a handwritten signature.
            </p>
          </div>

          <div className="flex items-center gap-3 pt-4 border-t">
            <button
              onClick={handleSign}
              disabled={signDocumentMutation.isPending || !signPassword}
              className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {signDocumentMutation.isPending ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Signing...
                </>
              ) : (
                <>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Sign & Approve
                </>
              )}
            </button>
            <button
              type="button"
              onClick={() => {
                setShowSignModal(false);
                setSignPassword('');
              }}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      </Modal>

      {/* Create Training Modal - Linked to Document */}
      <CreateTrainingModal
        isOpen={showCreateTrainingModal}
        onClose={() => setShowCreateTrainingModal(false)}
        sourceDocument={selectedDocument || undefined}
      />

      {/* View Document Modal */}
      <Modal
        isOpen={showViewModal}
        onClose={() => setShowViewModal(false)}
        title="Document Content"
        size="xl"
      >
        {selectedDocument && (
          <div className="space-y-6">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-blue-900">{selectedDocument.title}</h3>
                  <p className="text-sm text-blue-700">{selectedDocument.documentNumber} | Version {selectedDocument.version}</p>
                </div>
                <StatusBadge status={selectedDocument.status} />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Type</p>
                <p className="font-medium text-gray-900">{selectedDocument.type}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Classification</p>
                <p className="font-medium text-gray-900">{selectedDocument.classification || 'Internal'}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Department</p>
                <p className="font-medium text-gray-900">{selectedDocument.department}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Owner</p>
                <p className="font-medium text-gray-900">{selectedDocument.owner}</p>
              </div>
            </div>

            <div>
              <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Description</p>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-gray-700 whitespace-pre-wrap">{selectedDocument.description}</p>
              </div>
            </div>

            {selectedDocument.scope && (
              <div>
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Scope</p>
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-gray-700 whitespace-pre-wrap">{selectedDocument.scope}</p>
                </div>
              </div>
            )}

            {selectedDocument.references && (
              <div>
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">References</p>
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-gray-700">{selectedDocument.references}</p>
                </div>
              </div>
            )}

            <div className="flex justify-end pt-4 border-t">
              <button
                onClick={() => setShowViewModal(false)}
                className="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* Edit Document Modal */}
      <Modal
        isOpen={showEditModal}
        onClose={() => setShowEditModal(false)}
        title="Edit Document"
        size="lg"
      >
        {selectedDocument && (
          <EditDocumentForm
            document={selectedDocument}
            onSave={async (updates) => {
              if (!currentOrganization) {
                toast.error('Authentication required');
                return;
              }
              
              try {
                await updateDocumentMutation.mutateAsync({
                  id: selectedDocument.id,
                  input: updates,
                  userId: currentOrganization.id,
                });
                
                toast.success('Document updated successfully!');
                setShowEditModal(false);
                refetch();
              } catch (err: any) {
                toast.error(err.message || 'Failed to update document');
              }
            }}
            onCancel={() => setShowEditModal(false)}
            isLoading={updateDocumentMutation.isPending}
          />
        )}
      </Modal>
    </div>
  );
};

export default DocumentControl;
