import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useCompliance } from '@/contexts/ComplianceContext';
import { AlertTriangle, Loader2 } from 'lucide-react';

interface LegalDocumentAcceptanceProps {
  onAccept?: () => void;
}

export default function LegalDocumentAcceptance({ onAccept }: LegalDocumentAcceptanceProps) {
  const { pendingDocuments, acceptDocument, isLoading, legalDocuments } = useCompliance();
  const [selectedDoc, setSelectedDoc] = useState<string | null>(null);
  const [hasScrolledToEnd, setHasScrolledToEnd] = useState(false);
  const [isAccepting, setIsAccepting] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const currentDoc = pendingDocuments.length > 0 ? pendingDocuments[0] : null;

  useEffect(() => {
    if (currentDoc && !selectedDoc) {
      setSelectedDoc(currentDoc.id);
    }
  }, [currentDoc, selectedDoc]);

  const handleScroll = () => {
    if (scrollRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = scrollRef.current;
      if (scrollTop + clientHeight >= scrollHeight - 50) {
        setHasScrolledToEnd(true);
      }
    }
  };

  const handleAccept = async () => {
    if (!currentDoc || !agreed) return;

    setIsAccepting(true);
    const success = await acceptDocument(currentDoc.id, currentDoc.version);
    setIsAccepting(false);

    if (success && onAccept) {
      onAccept();
    }
  };

  const getDocumentTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      'terms_of_service': 'Conditions Générales d\'Utilisation',
      'privacy_policy': 'Politique de Confidentialité',
      'DPA': 'Accord de Traitement des Données',
      'cookie_policy': 'Politique des Cookies',
    };
    return labels[type] || type;
  };

  const getDocumentContent = (type: string) => {
    const defaultContent: Record<string, string> = {
      'terms_of_service': `# Conditions Générales d'Utilisation

## 1. Objet
Les présentes Conditions Générales d'Utilisation (CGU) ont pour objet de définir les modalités d'accès et d'utilisation de la plateforme Quality Management System (QMS).

## 2. Acceptation
L'utilisation de cette plateforme implique l'acceptation pleine et entière des présentes CGU. Si vous n'acceptez pas ces conditions, veuillez ne pas utiliser la plateforme.

## 3. Description du Service
Nous fournissons une solution de gestion de la qualité conforme aux normes ISO 13485 et aux réglementations applicables aux dispositifs médicaux.

## 4. Obligations de l'Utilisateur
L'utilisateur s'engage à fournir des informations véridiques et à respecter les procedures qualité définies par son organisation.

## 5. Propriété Intellectuelle
Tous les droits de propriété intellectuelle relatifs à la plateforme sont réservés.

## 6. Limitation de Responsabilité
La plateforme est fournie « en l'état ». Nous ne garantissons pas l'exactitude des données saisies par les utilisateurs.

## 7. Modification des CGU
Nous nous réservons le droit de modifier ces CGU à tout moment. Les utilisateurs seront informés de tout changement substantiel.

## 8. Droit Applicable
Les présentes CGU sont régies par le droit français.`,
      'privacy_policy': `# Politique de Confidentialité

## 1. Introduction
Cette Politique de Confidentialité décrit comment nous collectons, utilisons et protégeons vos données personnelles.

## 2. Données Collectées
Nous collectons les données nécessaires au fonctionnement du service, incluant les informations d'authentification et les données de l'organisation.

## 3. Utilisation des Données
Vos données sont utilisées pour :
- Fournir et maintenir nos services
- Améliorer notre plateforme
- Communiquer avec vous
- Respecter nos obligations légales

## 4. Protection des Données
Nous mettons en œuvre des mesures de sécurité appropriées pour protéger vos données contre tout accès non autorisé.

## 5. Vos Droits
Conformément au RGPD, vous disposez des droits d'accès, de rectification, d'effacement et de portabilité de vos données.

## 6. Conservation des Données
Nous conservons vos données aussi longtemps que nécessaire pour fournir nos services et respecter nos obligations légales.

## 7. Transfert des Données
Vos données peuvent être transférées vers des pays tiers avec des garanties appropriées.`,
    };
    return defaultContent[type] || 'Contenu non disponible';
  };

  if (isLoading || pendingDocuments.length === 0) {
    return null;
  }

  return (
    <Dialog open={pendingDocuments.length > 0} dismissible={false}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-500" />
            Action Requise
          </DialogTitle>
          <DialogDescription>
            Veuillez lire et accepter les documents suivants pour continuer à utiliser la plateforme.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-amber-50 dark:bg-amber-950 rounded-lg border border-amber-200 dark:border-amber-800">
            <div>
              <h4 className="font-medium text-amber-900 dark:text-amber-100">
                {currentDoc?.title || getDocumentTypeLabel(currentDoc?.type || '')}
              </h4>
              <p className="text-sm text-amber-700 dark:text-amber-300">
                Version {currentDoc?.version || '1.0'}
              </p>
            </div>
            <div className="text-sm text-amber-600 dark:text-amber-400">
              Nouveau document
            </div>
          </div>

          <ScrollArea 
            className="h-[300px] w-full rounded-md border p-4" 
            ref={scrollRef}
            onScroll={handleScroll}
          >
            <div className="prose prose-sm max-w-none dark:prose-invert">
              {currentDoc?.content?.split('\n').map((line, index) => {
                if (line.startsWith('# ')) {
                  return <h1 key={index} className="text-2xl font-bold mt-6 mb-4">{line.substring(2)}</h1>;
                }
                if (line.startsWith('## ')) {
                  return <h2 key={index} className="text-xl font-semibold mt-5 mb-3">{line.substring(3)}</h2>;
                }
                if (line.startsWith('### ')) {
                  return <h3 key={index} className="text-lg font-medium mt-4 mb-2">{line.substring(4)}</h3>;
                }
                if (line.startsWith('- ')) {
                  return <li key={index} className="ml-4">{line.substring(2)}</li>;
                }
                if (line.trim() === '') {
                  return <br key={index} />;
                }
                return <p key={index} className="mb-2">{line}</p>;
              })}
              {!currentDoc?.content && (
                <div className="text-muted-foreground">
                  {getDocumentContent(currentDoc?.type || '').split('\n').map((line, index) => {
                    if (line.startsWith('# ')) {
                      return <h1 key={index} className="text-2xl font-bold mt-6 mb-4">{line.substring(2)}</h1>;
                    }
                    if (line.startsWith('## ')) {
                      return <h2 key={index} className="text-xl font-semibold mt-5 mb-3">{line.substring(3)}</h2>;
                    }
                    if (line.startsWith('### ')) {
                      return <h3 key={index} className="text-lg font-medium mt-4 mb-2">{line.substring(4)}</h3>;
                    }
                    if (line.startsWith('- ')) {
                      return <li key={index} className="ml-4">{line.substring(2)}</li>;
                    }
                    if (line.trim() === '') {
                      return <br key={index} />;
                    }
                    return <p key={index} className="mb-2">{line}</p>;
                  })}
                </div>
              )}
            </div>
          </ScrollArea>

          {!hasScrolledToEnd && (
            <p className="text-sm text-muted-foreground text-center">
              Veuillez faire défiler jusqu'au bout du document pour activer la case à cocher.
            </p>
          )}

          <div className="flex items-center space-x-2">
            <Checkbox
              id="agree"
              checked={agreed}
              onCheckedChange={(checked) => setAgreed(checked as boolean)}
              disabled={!hasScrolledToEnd}
            />
            <label
              htmlFor="agree"
              className={`text-sm ${!hasScrolledToEnd ? 'text-muted-foreground' : ''}`}
            >
              J'ai lu et j'accepte les{' '}
              <span className="font-medium">
                {currentDoc?.title || getDocumentTypeLabel(currentDoc?.type || '')}
              </span>{' '}
              (version {currentDoc?.version || '1.0'})
            </label>
          </div>
        </div>

        <DialogFooter>
          <Button
            onClick={handleAccept}
            disabled={!agreed || isAccepting}
            className="w-full"
          >
            {isAccepting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Traitement en cours...
              </>
            ) : (
              'Confirmer et Continuer'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
