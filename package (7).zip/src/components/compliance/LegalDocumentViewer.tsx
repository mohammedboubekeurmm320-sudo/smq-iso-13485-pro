import { useState, useMemo } from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useLegalDocuments } from '@/modules/legal-documents/hooks/useLegalDocuments';

interface LegalDocument {
  id: string;
  type: string;
  version: string;
  title: string;
  content: string;
  is_active: boolean;
  effective_date: string;
  created_at: string;
}

interface LegalDocumentViewerProps {
  documentType: string;
  initialVersion?: string;
}

export default function LegalDocumentViewer({ documentType, initialVersion }: LegalDocumentViewerProps) {
  const [selectedVersion, setSelectedVersion] = useState<string>(initialVersion || '');

  // Use React Query hooks for data fetching
  const { data: documents = [], isLoading, error } = useLegalDocuments(documentType);

  // Memoize the selected document
  const selectedDocument = useMemo(() => {
    if (!documents.length) return null;
    if (selectedVersion) {
      return documents.find(d => d.version === selectedVersion) || null;
    }
    return documents.find(d => d.is_active) || documents[0] || null;
  }, [documents, selectedVersion]);

  const getDocumentTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      'terms_of_service': 'Conditions Générales d\'Utilisation',
      'privacy_policy': 'Politique de Confidentialité',
      'DPA': 'Accord de Traitement des Données',
      'cookie_policy': 'Politique des Cookies',
    };
    return labels[type] || type;
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-center h-64">
            <div className="text-muted-foreground">Chargement du document...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (documents.length === 0) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-center h-64">
            <div className="text-muted-foreground">Aucun document trouvé</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between space-y-0">
        <CardTitle className="text-lg font-semibold">
          {selectedDocument?.title || getDocumentTypeLabel(documentType)}
        </CardTitle>
        <div className="flex items-center gap-2">
          <Select value={selectedVersion} onValueChange={setSelectedVersion}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Version" />
            </SelectTrigger>
            <SelectContent>
              {documents.map((doc) => (
                <SelectItem key={doc.id} value={doc.version}>
                  <div className="flex items-center gap-2">
                    <span>v{doc.version}</span>
                    {doc.is_active && (
                      <Badge variant="secondary" className="text-xs">Actuelle</Badge>
                    )}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {selectedDoc?.is_active && (
            <Badge variant="default">Active</Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[500px] w-full rounded-md border p-4">
          <div className="prose prose-sm max-w-none dark:prose-invert">
            {selectedDoc?.content.split('\n').map((line, index) => {
              if (line.startsWith('# ')) {
                return <h1 key={index} className="text-2xl font-bold mt-6 mb-4">{line.substring(2)}</h1>;
              }
              if (line.startsWith('## ')) {
                return <h2 key={index} className="text-xl font-semibold mt-5 mb-3">{line.substring(3)}</h2>;
              }
              if (line.startsWith('### ')) {
                return <h3 key={index} className="text-lg font-medium mt-4 mb-2">{line.substring(4)}</h3>;
              }
              if (line.startsWith('- ')) {
                return <li key={index} className="ml-4">{line.substring(2)}</li>;
              }
              if (line.trim() === '') {
                return <br key={index} />;
              }
              return <p key={index} className="mb-2">{line}</p>;
            })}
          </div>
        </ScrollArea>
        {selectedDoc?.effective_date && (
          <div className="mt-4 text-sm text-muted-foreground">
            Date d'entrée en vigueur : {new Date(selectedDoc.effective_date).toLocaleDateString('fr-FR')}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
