import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  ShieldCheck, 
  AlertTriangle, 
  FileCheck, 
  Clock, 
  Users,
  BarChart3,
  Download,
  RefreshCw
} from 'lucide-react';
import { useCompliance } from '@/contexts/ComplianceContext';
import { useOrganization } from '@/contexts/OrganizationContext';
import { supabase } from '@/lib/supabase';

interface DashboardStats {
  totalDocuments: number;
  pendingSignatures: number;
  openCAPAs: number;
  complianceScore: number;
  recentAuditLogs: number;
  usersAccepted: number;
  totalUsers: number;
}

export default function ComplianceDashboard() {
  const { complianceStatus, pendingDocuments } = useCompliance();
  const { currentOrganization } = useOrganization();
  const [stats, setStats] = useState<DashboardStats>({
    totalDocuments: 0,
    pendingSignatures: 0,
    openCAPAs: 0,
    complianceScore: 100,
    recentAuditLogs: 0,
    usersAccepted: 0,
    totalUsers: 0,
  });
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    if (currentOrganization?.id) {
      fetchDashboardStats();
    } else {
      // In demo mode without organization, set default stats
      setIsLoading(false);
    }
  }, [currentOrganization?.id]);

  const fetchDashboardStats = async () => {
    try {
      setIsLoading(true);
      
      // Fetch documents count
      const { count: docCount, error: docError } = await supabase
        .from('documents')
        .select('*', { count: 'exact', head: true })
        .eq('organization_id', currentOrganization?.id);

      // Fetch pending signatures
      const { count: sigCount, error: sigError } = await supabase
        .from('electronic_signatures')
        .select('*', { count: 'exact', head: true })
        .eq('organization_id', currentOrganization?.id)
        .eq('is_valid', true);

      // Fetch open CAPAs
      const { count: capaCount, error: capaError } = await supabase
        .from('capas')
        .select('*', { count: 'exact', head: true })
        .eq('organization_id', currentOrganization?.id)
        .neq('status', 'closed');

      // Fetch recent audit logs (last 7 days)
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
      
      const { count: auditCount, error: auditError } = await supabase
        .from('audit_trail')
        .select('*', { count: 'exact', head: true })
        .eq('organization_id', currentOrganization?.id)
        .gte('created_at', sevenDaysAgo.toISOString());

      // Fetch organization members
      const { data: members, error: membersError } = await supabase
        .from('organization_members')
        .select('user_id')
        .eq('organization_id', currentOrganization?.id);

      const totalUsers = members?.length || 0;

      // If any table doesn't exist, use demo data
      if (docError || sigError || capaError || auditError || membersError) {
        console.log('Using demo data for compliance dashboard');
        setStats({
          totalDocuments: 24,
          pendingSignatures: 3,
          openCAPAs: 5,
          complianceScore: 85,
          recentAuditLogs: 42,
          usersAccepted: 8,
          totalUsers: 10,
        });
        setIsLoading(false);
        return;
      }

      // Fetch user consents for latest docs
      const { data: latestDocs } = await supabase
        .from('legal_documents')
        .select('id, type, version')
        .eq('is_active', true);

      let usersAccepted = 0;
      if (latestDocs && latestDocs.length > 0) {
        const latestByType = new Map<string, { id: string; version: string }>();
        latestDocs.forEach(doc => {
          const existing = latestByType.get(doc.type);
          if (!existing) {
            latestByType.set(doc.type, doc);
          }
        });

        const { data: consents } = await supabase
          .from('user_consents')
          .select('user_id')
          .eq('consent_given', true);

        const acceptedUsers = new Set<string>();
        latestByType.forEach((doc) => {
          consents?.forEach(consent => {
            if (consent.user_id && latestByType.has(consent.user_id)) {
              acceptedUsers.add(consent.user_id);
            }
          });
        });
        usersAccepted = acceptedUsers.size;
      }

      // Calculate compliance score
      const complianceScore = totalUsers > 0 
        ? Math.round((usersAccepted / totalUsers) * 100)
        : 100;

      setStats({
        totalDocuments: docCount || 0,
        pendingSignatures: sigCount || 0,
        openCAPAs: capaCount || 0,
        complianceScore,
        recentAuditLogs: auditCount || 0,
        usersAccepted,
        totalUsers,
      });
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'compliant':
        return 'bg-green-500';
      case 'warning':
        return 'bg-amber-500';
      case 'critical':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'compliant':
        return 'Conforme';
      case 'warning':
        return 'Attention';
      case 'critical':
        return 'Non conforme';
      default:
        return 'Inconnu';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Tableau de Bord Conformité</h1>
          <p className="text-muted-foreground">
            Vue d'ensemble de la conformité aux normes ISO 13485 et 21 CFR Part 11
          </p>
        </div>
        <Button variant="outline" onClick={fetchDashboardStats} disabled={isLoading}>
          <RefreshCw className={`mr-2 h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
          Actualiser
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Score de Conformité
            </CardTitle>
            <ShieldCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <div className={`h-3 w-3 rounded-full ${getStatusColor(complianceStatus)}`} />
              <span className="text-2xl font-bold">{stats.complianceScore}%</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {getStatusLabel(complianceStatus)}
            </p>
            <Progress value={stats.complianceScore} className="mt-2 h-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Documents
            </CardTitle>
            <FileCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalDocuments}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Documents qualité actifs
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Signatures en Attente
            </CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.pendingSignatures}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Signatures électroniques en attente
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              CAPA Ouvertes
            </CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.openCAPAs}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Actions correctives en cours
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Aperçu de la Conformité</CardTitle>
            <CardDescription>
              Statut global de la conformité de votre organisation
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium">Documents Juridiques</span>
                  <span className="text-muted-foreground">
                    {pendingDocuments.length === 0 ? 'À jour' : `${pendingDocuments.length} en attente`}
                  </span>
                </div>
                <Progress 
                  value={pendingDocuments.length === 0 ? 100 : 0} 
                  className="h-2"
                  variant={pendingDocuments.length === 0 ? 'default' : 'error'}
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium">Audit Trail</span>
                  <span className="text-muted-foreground">
                    {stats.recentAuditLogs} événements (7 derniers jours)
                  </span>
                </div>
                <Progress value={100} className="h-2" />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium">Utilisateurs Conformes</span>
                  <span className="text-muted-foreground">
                    {stats.usersAccepted} sur {stats.totalUsers}
                  </span>
                </div>
                <Progress 
                  value={stats.totalUsers > 0 ? (stats.usersAccepted / stats.totalUsers) * 100 : 100} 
                  className="h-2"
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium">Signatures Électroniques</span>
                  <span className="text-muted-foreground">
                    21 CFR Part 11
                  </span>
                </div>
                <Progress value={100} className="h-2" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Actions Requises</CardTitle>
            <CardDescription>
              Éléments nécessitant votre attention
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {pendingDocuments.length > 0 && (
                <div className="flex items-start gap-3 p-3 bg-amber-50 dark:bg-amber-950 rounded-lg border border-amber-200 dark:border-amber-800">
                  <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5" />
                  <div>
                    <p className="font-medium text-sm">Documents Juridiques</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {pendingDocuments.length} document(s) nécessitent votre acceptation
                    </p>
                    <Button variant="link" size="sm" className="p-0 h-auto text-amber-600">
                      Voir les documents
                    </Button>
                  </div>
                </div>
              )}

              {stats.openCAPAs > 0 && (
                <div className="flex items-start gap-3 p-3 bg-blue-50 dark:bg-blue-950 rounded-lg border border-blue-200 dark:border-blue-800">
                  <AlertTriangle className="h-5 w-5 text-blue-500 mt-0.5" />
                  <div>
                    <p className="font-medium text-sm">Actions Correctives</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {stats.openCAPAs} CAPA(s) ouverte(s) nécessitent votre attention
                    </p>
                    <Button variant="link" size="sm" className="p-0 h-auto text-blue-600">
                      Voir les CAPA
                    </Button>
                  </div>
                </div>
              )}

              {pendingDocuments.length === 0 && stats.openCAPAs === 0 && (
                <div className="flex items-start gap-3 p-3 bg-green-50 dark:bg-green-950 rounded-lg border border-green-200 dark:border-green-800">
                  <ShieldCheck className="h-5 w-5 text-green-500 mt-0.5" />
                  <div>
                    <p className="font-medium text-sm">Tout est en ordre</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Votre organisation est conforme aux exigences
                    </p>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Rapports de Conformité</CardTitle>
              <CardDescription>
                Générez des rapports pour les audits externes
              </CardDescription>
            </div>
            <Button>
              <Download className="mr-2 h-4 w-4" />
              Nouveau Rapport
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="overview">Résumé</TabsTrigger>
              <TabsTrigger value="audit">Audit Trail</TabsTrigger>
              <TabsTrigger value="signatures">Signatures</TabsTrigger>
              <TabsTrigger value="documents">Documents</TabsTrigger>
            </TabsList>
            <TabsContent value="overview" className="space-y-4">
              <div className="grid gap-4 md:grid-cols-3">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm">Rapport ISO 13485</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-xs text-muted-foreground mb-3">
                      Synthèse de la conformité au système de management de la qualité
                    </p>
                    <Button variant="outline" size="sm" className="w-full">
                      <Download className="mr-2 h-3 w-3" />
                      Générer
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm">Rapport 21 CFR Part 11</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-xs text-muted-foreground mb-3">
                      Conformité aux signatures électroniques
                    </p>
                    <Button variant="outline" size="sm" className="w-full">
                      <Download className="mr-2 h-3 w-3" />
                      Générer
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm">Rapport d'Activité</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-xs text-muted-foreground mb-3">
                      Activité globale du système
                    </p>
                    <Button variant="outline" size="sm" className="w-full">
                      <Download className="mr-2 h-3 w-3" />
                      Générer
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            <TabsContent value="audit">
              <div className="text-center py-8 text-muted-foreground">
                Accédez au module d'audit trail pour une analyse détaillée
              </div>
            </TabsContent>
            <TabsContent value="signatures">
              <div className="text-center py-8 text-muted-foreground">
                Accédez au module de signatures électroniques
              </div>
            </TabsContent>
            <TabsContent value="documents">
              <div className="text-center py-8 text-muted-foreground">
                Accédez au contrôle documentaire
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
