import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Checkbox } from '@/components/ui/checkbox';
import { CalendarIcon, Download, FileText, Loader2, Printer } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { useCompliance } from '@/contexts/ComplianceContext';
import { useOrganization } from '@/contexts/OrganizationContext';
import { supabase } from '@/lib/supabase';

interface ReportConfig {
  type: string;
  title: string;
  periodStart: Date;
  periodEnd: Date;
  includeAuditTrail: boolean;
  includeSignatures: boolean;
  includeDocuments: boolean;
  includeCAPAs: boolean;
}

export default function ComplianceReportGenerator() {
  const { generateReport } = useCompliance();
  const { currentOrganization } = useOrganization();
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedReport, setGeneratedReport] = useState<string | null>(null);
  
  const [config, setConfig] = useState<ReportConfig>({
    type: 'iso13485_summary',
    title: 'Rapport de Conformité ISO 13485',
    periodStart: new Date(new Date().setMonth(new Date().getMonth() - 1)),
    periodEnd: new Date(),
    includeAuditTrail: true,
    includeSignatures: true,
    includeDocuments: true,
    includeCAPAs: true,
  });

  const reportTypes = [
    { id: 'iso13485_summary', name: 'Résumé ISO 13485', description: 'Synthèse de la conformité au système de management de la qualité' },
    { id: 'cfr21_part11', name: '21 CFR Part 11', description: 'Conformité aux signatures électroniques et audit trail' },
    { id: 'audit_activity', name: 'Activité d\'Audit', description: 'Journal complet des actions utilisateur' },
    { id: 'document_control', name: 'Contrôle Documentaire', description: 'État des documents qualité' },
    { id: 'capa_summary', name: 'Résumé des CAPA', description: 'Statut des actions correctives et préventives' },
    { id: 'user_activity', name: 'Activité Utilisateurs', description: 'Historique des connexions et actions par utilisateur' },
  ];

  const handleGenerate = async () => {
    try {
      setIsGenerating(true);
      setGeneratedReport(null);

      // Fetch data based on config
      const reportData = await fetchReportData(config);

      // Generate CSV content
      const csvContent = generateCSV(reportData, config);

      // Create blob and download
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${config.title.replace(/\s+/g, '_')}_${format(new Date(), 'yyyy-MM-dd')}.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      setGeneratedReport(csvContent);

      // Log report generation
      if (currentOrganization) {
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          await supabase.rpc('create_audit_log', {
            p_organization_id: currentOrganization.id,
            p_user_id: user.id,
            p_user_email: user.email,
            p_action: 'EXPORT',
            p_entity_type: 'compliance_report',
            p_entity_name: config.title,
            p_new_value: JSON.stringify(config),
            p_description: `Generated compliance report: ${config.title}`,
          });
        }
      }
    } catch (error) {
      console.error('Error generating report:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const fetchReportData = async (cfg: ReportConfig) => {
    const data: Record<string, unknown> = {};

    if (cfg.includeAuditTrail && currentOrganization) {
      const { data: auditLogs } = await supabase
        .from('audit_trail')
        .select('*')
        .eq('organization_id', currentOrganization.id)
        .gte('created_at', cfg.periodStart.toISOString())
        .lte('created_at', cfg.periodEnd.toISOString())
        .order('created_at', { ascending: false })
        .limit(1000);
      data.auditLogs = auditLogs || [];
    }

    if (cfg.includeSignatures && currentOrganization) {
      const { data: signatures } = await supabase
        .from('electronic_signatures')
        .select('*')
        .eq('organization_id', currentOrganization.id)
        .gte('created_at', cfg.periodStart.toISOString())
        .lte('created_at', cfg.periodEnd.toISOString())
        .order('created_at', { ascending: false });
      data.signatures = signatures || [];
    }

    if (cfg.includeDocuments && currentOrganization) {
      const { data: documents } = await supabase
        .from('documents')
        .select('*')
        .eq('organization_id', currentOrganization.id)
        .order('created_at', { ascending: false });
      data.documents = documents || [];
    }

    if (cfg.includeCAPAs && currentOrganization) {
      const { data: capas } = await supabase
        .from('capas')
        .select('*')
        .eq('organization_id', currentOrganization.id)
        .order('created_at', { ascending: false });
      data.capas = capas || [];
    }

    return data;
  };

  const generateCSV = (data: Record<string, unknown>, cfg: ReportConfig): string => {
    const lines: string[] = [];

    // Header
    lines.push(`Rapport de Conformité - ${cfg.title}`);
    lines.push(`Période: ${format(cfg.periodStart, 'dd/MM/yyyy', { locale: fr })} - ${format(cfg.periodEnd, 'dd/MM/yyyy', { locale: fr })}`);
    lines.push(`Généré le: ${format(new Date(), 'dd/MM/yyyy HH:mm', { locale: fr })}`);
    lines.push('');

    // Audit Trail
    if (cfg.includeAuditTrail && data.auditLogs && (data.auditLogs as unknown[]).length > 0) {
      lines.push('--- JOURNAL D\'AUDIT ---');
      lines.push('Date,Utilisateur,Action,Entité,Nom,Description,Adresse IP');
      (data.auditLogs as Array<{created_at: string; user_email: string; action: string; entity_type: string; entity_name: string; description: string; ip_address: string}>).forEach(log => {
        lines.push([
          format(new Date(log.created_at), 'dd/MM/yyyy HH:mm'),
          log.user_email || 'Système',
          log.action,
          log.entity_type,
          log.entity_name || '',
          (log.description || '').replace(/,/g, ';'),
          log.ip_address || ''
        ].join(','));
      });
      lines.push('');
    }

    // Signatures Électroniques
    if (cfg.includeSignatures && data.signatures && (data.signatures as unknown[]).length > 0) {
      lines.push('--- SIGNATURES ÉLECTRONIQUES ---');
      lines.push('Date,Utilisateur,Type Document,ID Document,Raison,Adresse IP,Valide');
      (data.signatures as Array<{created_at: string; user_id: string; document_type: string; document_id: string; reason: string; ip_address: string; is_valid: boolean}>).forEach(sig => {
        lines.push([
          format(new Date(sig.created_at), 'dd/MM/yyyy HH:mm'),
          sig.user_id.substring(0, 8) + '...',
          sig.document_type,
          sig.document_id.substring(0, 8) + '...',
          (sig.reason || '').replace(/,/g, ';'),
          sig.ip_address || '',
          sig.is_valid ? 'Oui' : 'Non'
        ].join(','));
      });
      lines.push('');
    }

    // Documents
    if (cfg.includeDocuments && data.documents && (data.documents as unknown[]).length > 0) {
      lines.push('--- DOCUMENTS ---');
      lines.push('Titre,Version,Statut,Date Création');
      (data.documents as Array<{title: string; version: string; status: string; created_at: string}>).forEach(doc => {
        lines.push([
          (doc.title || '').replace(/,/g, ';'),
          doc.version || '',
          doc.status || '',
          format(new Date(doc.created_at), 'dd/MM/yyyy')
        ].join(','));
      });
      lines.push('');
    }

    // CAPAs
    if (cfg.includeCAPAs && data.capas && (data.capas as unknown[]).length > 0) {
      lines.push('--- ACTIONS CORRECTIVES (CAPA) ---');
      lines.push('Titre,Statut,Sévérité,Date Création,Date Clôture');
      (data.capas as Array<{title: string; status: string; severity: string; created_at: string; closed_at: string | null}>).forEach(capa => {
        lines.push([
          (capa.title || '').replace(/,/g, ';'),
          capa.status || '',
          capa.severity || '',
          format(new Date(capa.created_at), 'dd/MM/yyyy'),
          capa.closed_at ? format(new Date(capa.closed_at), 'dd/MM/yyyy') : 'En cours'
        ].join(','));
      });
      lines.push('');
    }

    // Summary
    lines.push('--- RÉSUMÉ ---');
    lines.push(`Total entrées audit: ${cfg.includeAuditTrail ? (data.auditLogs as unknown[] || []).length : 0}`);
    lines.push(`Total signatures: ${cfg.includeSignatures ? (data.signatures as unknown[] || []).length : 0}`);
    lines.push(`Total documents: ${cfg.includeDocuments ? (data.documents as unknown[] || []).length : 0}`);
    lines.push(`Total CAPAs: ${cfg.includeCAPAs ? (data.capas as unknown[] || []).length : 0}`);

    return lines.join('\n');
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Générateur de Rapports</h2>
        <p className="text-muted-foreground">
          Créez des rapports de conformité personnalisés pour les audits externes
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Configuration du Rapport
            </CardTitle>
            <CardDescription>
              Définissez les paramètres du rapport à générer
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="report-type">Type de Rapport</Label>
              <Select 
                value={config.type} 
                onValueChange={(value) => setConfig({ ...config, type: value })}
              >
                <SelectTrigger id="report-type">
                  <SelectValue placeholder="Sélectionner un type" />
                </SelectTrigger>
                <SelectContent>
                  {reportTypes.map((type) => (
                    <SelectItem key={type.id} value={type.id}>
                      <div>
                        <div className="font-medium">{type.name}</div>
                        <div className="text-xs text-muted-foreground">{type.description}</div>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="title">Titre du Rapport</Label>
              <Input
                id="title"
                value={config.title}
                onChange={(e) => setConfig({ ...config, title: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Date de Début</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {config.periodStart ? format(config.periodStart, 'dd MMM yyyy', { locale: fr }) : 'Sélectionner'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={config.periodStart}
                      onSelect={(date) => date && setConfig({ ...config, periodStart: date })}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <Label>Date de Fin</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {config.periodEnd ? format(config.periodEnd, 'dd MMM yyyy', { locale: fr }) : 'Sélectionner'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={config.periodEnd}
                      onSelect={(date) => date && setConfig({ ...config, periodEnd: date })}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Printer className="h-5 w-5" />
              Contenu du Rapport
            </CardTitle>
            <CardDescription>
              Sélectionnez les sections à inclure
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="include-audit"
                  checked={config.includeAuditTrail}
                  onCheckedChange={(checked) => setConfig({ ...config, includeAuditTrail: checked as boolean })}
                />
                <Label htmlFor="include-audit" className="font-normal">
                  Journal d'audit trail
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="include-signatures"
                  checked={config.includeSignatures}
                  onCheckedChange={(checked) => setConfig({ ...config, includeSignatures: checked as boolean })}
                />
                <Label htmlFor="include-signatures" className="font-normal">
                  Signatures électroniques (21 CFR Part 11)
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="include-documents"
                  checked={config.includeDocuments}
                  onCheckedChange={(checked) => setConfig({ ...config, includeDocuments: checked as boolean })}
                />
                <Label htmlFor="include-documents" className="font-normal">
                  Documents qualité
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="include-capas"
                  checked={config.includeCAPAs}
                  onCheckedChange={(checked) => setConfig({ ...config, includeCAPAs: checked as boolean })}
                />
                <Label htmlFor="include-capas" className="font-normal">
                  Actions correctives (CAPA)
                </Label>
              </div>
            </div>

            <div className="pt-4">
              <Button 
                onClick={handleGenerate} 
                disabled={isGenerating}
                className="w-full"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Génération en cours...
                  </>
                ) : (
                  <>
                    <Download className="mr-2 h-4 w-4" />
                    Générer le Rapport
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {generatedReport && (
        <Card>
          <CardHeader>
            <CardTitle>Aperçu du Rapport</CardTitle>
            <CardDescription>
              Aperçu des premières lignes du fichier généré
            </CardDescription>
          </CardHeader>
          <CardContent>
            <pre className="bg-muted p-4 rounded-lg overflow-x-auto text-xs max-h-96">
              {generatedReport.split('\n').slice(0, 30).join('\n')}
              {(generatedReport.split('\n').length > 30) && '\n...'}
            </pre>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
