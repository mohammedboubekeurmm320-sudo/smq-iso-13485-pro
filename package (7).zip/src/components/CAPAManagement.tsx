import React, { useState, useMemo } from 'react';
import DataTable from './ui/DataTable';
import StatusBadge from './ui/StatusBadge';
import Modal from './ui/Modal';
import { useCAPAs, useCreateCAPA } from '../modules/capas/hooks/useCAPAs';
import { CAPA } from '../types/qms';
import { useAuth } from '../contexts/AuthContext';
import { useOrganization } from '@/contexts/OrganizationContext';
import { toast } from 'sonner';
import CreateTrainingModal from './CreateTrainingModal';

const CAPAManagement: React.FC = () => {
  const { currentOrganization } = useOrganization();
  const [selectedCAPA, setSelectedCAPA] = useState<CAPA | null>(null);
  const [showNewCAPAModal, setShowNewCAPAModal] = useState(false);
  const [showAssignTrainingModal, setShowAssignTrainingModal] = useState(false);
  const [filterType, setFilterType] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterPriority, setFilterPriority] = useState<string>('all');
  
  // New CAPA form state - ISO 13485:8.5.2 compliant
  const [newCAPAData, setNewCAPAData] = useState({
    // Basic Information
    title: '',
    type: 'Corrective' as string,
    priority: 'Medium' as string,
    status: 'Open' as string,
    
    // ISO 13485:8.5.2 - Source and Reference
    source: 'Non-Conformance' as string,
    sourceReferenceId: '',
    sourceDescription: '',
    
    // ISO 13485:8.5.2 - Problem Statement
    description: '',
    problemStatement: '',
    
    // ISO 13485:8.5.2 - Investigation
    investigationDetails: '',
    rootCauseAnalysis: '',
    rootCauseCategory: '' as string,
    
    // ISO 13485:8.5.2 - Immediate Correction
    immediateCorrection: '',
    correctionImplementationDate: '',
    
    // ISO 13485:8.5.2 - Corrective Action
    correctiveAction: '',
    correctiveActionPlan: '',
    actionImplementationDate: '',
    
    // ISO 13485:8.5.3 - Effectiveness Verification
    effectivenessVerificationMethod: '' as string,
    effectivenessCriteria: '',
    effectivenessReviewDate: '',
    
    // Assignment
    assignedTo: '',
    assignedDate: '',
    dueDate: '',
    
    // Links to other modules
    linkedNCRId: '',
    linkedAuditId: '',
    linkedDeviationId: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { hasPermission, user } = useAuth();

  // Use React Query hooks for data fetching
  const { data: capas = [], isLoading, error, refetch } = useCAPAs({
    type: filterType !== 'all' ? filterType : undefined,
    status: filterStatus !== 'all' ? filterStatus : undefined,
    priority: filterPriority !== 'all' ? filterPriority : undefined,
  });
  
  // Use mutations
  const createCAPAMutation = useCreateCAPA();

  // Handle new CAPA creation
  const handleCreateCAPA = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentOrganization || !user) {
      toast.error('Authentication required');
      return;
    }

    // Validation
    if (!newCAPAData.title.trim()) {
      toast.error('CAPA title is required');
      return;
    }
    if (!newCAPAData.description.trim()) {
      toast.error('Description is required');
      return;
    }

    setIsSubmitting(true);
    try {
      await createCAPAMutation.mutateAsync({
        input: {
          // Basic Information
          title: newCAPAData.title,
          type: newCAPAData.type as 'Corrective' | 'Preventive',
          priority: newCAPAData.priority,
          status: newCAPAData.status as 'Open' | 'Investigation' | 'Implementation' | 'Effectiveness Check' | 'Closed',
          
          // Source and Reference
          source: newCAPAData.source,
          sourceReferenceId: newCAPAData.sourceReferenceId,
          sourceDescription: newCAPAData.sourceDescription,
          
          // Problem Statement
          description: newCAPAData.description,
          problemStatement: newCAPAData.problemStatement,
          
          // Investigation
          investigationDetails: newCAPAData.investigationDetails,
          rootCauseAnalysis: newCAPAData.rootCauseAnalysis,
          rootCauseCategory: newCAPAData.rootCauseCategory as 'Man' | 'Machine' | 'Method' | 'Material' | 'Measurement' | 'Environment' | 'Management' | undefined,
          
          // Immediate Correction
          immediateCorrection: newCAPAData.immediateCorrection,
          correctionImplementationDate: newCAPAData.correctionImplementationDate,
          
          // Corrective Action
          correctiveAction: newCAPAData.correctiveAction,
          correctiveActionPlan: newCAPAData.correctiveActionPlan,
          actionImplementationDate: newCAPAData.actionImplementationDate,
          
          // Effectiveness Verification
          effectivenessVerificationMethod: newCAPAData.effectivenessVerificationMethod,
          effectivenessCriteria: newCAPAData.effectivenessCriteria,
          effectivenessReviewDate: newCAPAData.effectivenessReviewDate,
          
          // Assignment
          assignedTo: newCAPAData.assignedTo,
          assignedDate: newCAPAData.assignedDate,
          dueDate: newCAPAData.dueDate,
          
          // Links
          linkedNCRId: newCAPAData.linkedNCRId,
          linkedAuditId: newCAPAData.linkedAuditId,
          linkedDeviationId: newCAPAData.linkedDeviationId,
        },
        userId: currentOrganization.id,
      });
      
      toast.success('CAPA created successfully!', {
        description: `CAPA has been created and is ready for investigation.`,
      });
      
      // Reset form and close modal
      setNewCAPAData({
        title: '',
        type: 'Corrective',
        priority: 'Medium',
        status: 'Open',
        source: 'Non-Conformance',
        sourceReferenceId: '',
        sourceDescription: '',
        description: '',
        problemStatement: '',
        investigationDetails: '',
        rootCauseAnalysis: '',
        rootCauseCategory: '',
        immediateCorrection: '',
        correctionImplementationDate: '',
        correctiveAction: '',
        correctiveActionPlan: '',
        actionImplementationDate: '',
        effectivenessVerificationMethod: '',
        effectivenessCriteria: '',
        effectivenessReviewDate: '',
        assignedTo: '',
        assignedDate: '',
        dueDate: '',
        linkedNCRId: '',
        linkedAuditId: '',
        linkedDeviationId: '',
      });
      setShowNewCAPAModal(false);
      
      // Refresh the CAPA list
      refetch();
    } catch (err: any) {
      toast.error(err.message || 'Failed to create CAPA');
    } finally {
      setIsSubmitting(false);
    }
  };

  const canCreate = hasPermission('canCreateCAPAs');
  const canEdit = hasPermission('canEditCAPAs');
  const canClose = hasPermission('canCloseCAPAs');
  const canExport = hasPermission('canExportData');

  const filteredCAPAs = useMemo(() => {
    return capas.filter(capa => {
      if (filterType !== 'all' && capa.type !== filterType) return false;
      if (filterStatus !== 'all' && capa.status !== filterStatus) return false;
      if (filterPriority !== 'all' && capa.priority !== filterPriority) return false;
      return true;
    });
  }, [capas, filterType, filterStatus, filterPriority]);

  const columns = [
    { key: 'capaNumber', header: 'CAPA #', sortable: true },
    { 
      key: 'title', 
      header: 'Title',
      render: (capa: CAPA) => (
        <span className="line-clamp-1 max-w-xs">{capa.title}</span>
      )
    },
    { 
      key: 'type', 
      header: 'Type',
      render: (capa: CAPA) => (
        <span className={`px-2 py-1 rounded text-xs font-medium ${
          capa.type === 'Corrective' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'
        }`}>
          {capa.type}
        </span>
      )
    },
    { 
      key: 'priority', 
      header: 'Priority',
      render: (capa: CAPA) => <StatusBadge status={capa.priority} variant="priority" />
    },
    { 
      key: 'status', 
      header: 'Status',
      render: (capa: CAPA) => <StatusBadge status={capa.status} />
    },
    { key: 'assignedTo', header: 'Assigned To', sortable: true },
    { key: 'dueDate', header: 'Due Date', sortable: true },
    { key: 'source', header: 'Source', sortable: true },
  ];

  const stats = {
    total: capas.length,
    open: capas.filter(c => c.status === 'Open').length,
    inProgress: capas.filter(c => ['Investigation', 'Implementation', 'Verification'].includes(c.status)).length,
    closed: capas.filter(c => c.status === 'Closed').length,
    overdue: capas.filter(c => c.status !== 'Closed' && new Date(c.dueDate) < new Date()).length,
  };

  const getStatusSteps = (status: string) => {
    const steps = ['Open', 'Investigation', 'Implementation', 'Verification', 'Closed'];
    const currentIndex = steps.indexOf(status);
    return steps.map((step, index) => ({
      name: step,
      completed: index < currentIndex,
      current: index === currentIndex,
    }));
  };

  return (
    <div className="p-6 space-y-6">
      {/* Loading State */}
      {isLoading && (
        <div className="flex items-center justify-center py-12">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-4 text-gray-500">Loading CAPAs...</p>
          </div>
        </div>
      )}

      {/* Error State */}
      {error && !isLoading && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
          <div className="flex items-center gap-3">
            <svg className="w-5 h-5 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            <div>
              <p className="text-red-700 font-medium">Error loading CAPAs</p>
              <p className="text-red-600 text-sm">{error.message}</p>
            </div>
            <button 
              onClick={() => refetch()}
              className="ml-auto px-3 py-1 bg-red-100 text-red-700 rounded hover:bg-red-200"
            >
              Retry
            </button>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">CAPA Management</h2>
          <p className="text-gray-500 mt-1">Corrective and Preventive Actions per ISO 13485 Section 8.5</p>
        </div>
        <button
          onClick={() => setShowNewCAPAModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
          New CAPA
        </button>
      </div>


      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <p className="text-sm text-gray-500">Total CAPAs</p>
          <p className="text-2xl font-bold text-gray-900 mt-1">{stats.total}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <p className="text-sm text-gray-500">Open</p>
          <p className="text-2xl font-bold text-yellow-600 mt-1">{stats.open}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <p className="text-sm text-gray-500">In Progress</p>
          <p className="text-2xl font-bold text-blue-600 mt-1">{stats.inProgress}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <p className="text-sm text-gray-500">Closed</p>
          <p className="text-2xl font-bold text-green-600 mt-1">{stats.closed}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <p className="text-sm text-gray-500">Overdue</p>
          <p className="text-2xl font-bold text-red-600 mt-1">{stats.overdue}</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4 flex-wrap">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          >
            <option value="all">All Types</option>
            <option value="Corrective">Corrective</option>
            <option value="Preventive">Preventive</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          >
            <option value="all">All Statuses</option>
            <option value="Open">Open</option>
            <option value="Investigation">Investigation</option>
            <option value="Implementation">Implementation</option>
            <option value="Verification">Verification</option>
            <option value="Closed">Closed</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Priority</label>
          <select
            value={filterPriority}
            onChange={(e) => setFilterPriority(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          >
            <option value="all">All Priorities</option>
            <option value="Critical">Critical</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors flex items-center gap-2">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
            </svg>
            Export
          </button>
        </div>
      </div>

      {/* Data Table */}
      <DataTable
        data={filteredCAPAs}
        columns={columns}
        onRowClick={(capa) => setSelectedCAPA(capa)}
        searchPlaceholder="Search CAPAs..."
        searchKeys={['capaNumber', 'title', 'assignedTo', 'source']}
      />

      {/* CAPA Detail Modal */}
      <Modal
        isOpen={!!selectedCAPA}
        onClose={() => setSelectedCAPA(null)}
        title="CAPA Details"
        size="xl"
      >
        {selectedCAPA && (
          <div className="space-y-6">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-3">
                  <h4 className="text-lg font-semibold text-gray-900">{selectedCAPA.capaNumber}</h4>
                  <StatusBadge status={selectedCAPA.priority} variant="priority" />
                  <StatusBadge status={selectedCAPA.type === 'Corrective' ? 'Corrective' : 'Preventive'} />
                </div>
                <p className="text-gray-700 mt-1">{selectedCAPA.title}</p>
              </div>
              <StatusBadge status={selectedCAPA.status} />
            </div>

            {/* Progress Steps */}
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm font-medium text-gray-700 mb-4">CAPA Progress</p>
              <div className="flex items-center justify-between">
                {getStatusSteps(selectedCAPA.status).map((step, index) => (
                  <div key={step.name} className="flex items-center">
                    <div className="flex flex-col items-center">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          step.completed
                            ? 'bg-green-500 text-white'
                            : step.current
                            ? 'bg-blue-500 text-white'
                            : 'bg-gray-200 text-gray-500'
                        }`}
                      >
                        {step.completed ? (
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        ) : (
                          <span className="text-xs font-medium">{index + 1}</span>
                        )}
                      </div>
                      <span className="text-xs text-gray-600 mt-1">{step.name}</span>
                    </div>
                    {index < 4 && (
                      <div
                        className={`w-16 h-1 mx-2 ${
                          step.completed ? 'bg-green-500' : 'bg-gray-200'
                        }`}
                      />
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Source</p>
                <p className="font-medium text-gray-900">{selectedCAPA.source}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Assigned To</p>
                <p className="font-medium text-gray-900">{selectedCAPA.assignedTo}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Created Date</p>
                <p className="font-medium text-gray-900">{selectedCAPA.createdDate}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Due Date</p>
                <p className="font-medium text-gray-900">{selectedCAPA.dueDate}</p>
              </div>
            </div>

            <div>
              <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Description</p>
              <p className="text-gray-700">{selectedCAPA.description}</p>
            </div>

            {selectedCAPA.rootCause && (
              <div>
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Root Cause Analysis</p>
                <p className="text-gray-700">{selectedCAPA.rootCause}</p>
              </div>
            )}

            {selectedCAPA.proposedAction && (
              <div>
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Proposed Action</p>
                <p className="text-gray-700">{selectedCAPA.proposedAction}</p>
              </div>
            )}

            {selectedCAPA.effectiveness && (
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Effectiveness Verification</p>
                <StatusBadge status={selectedCAPA.effectiveness} />
              </div>
            )}

            <div className="flex items-center gap-3 pt-4 border-t">
              <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                Update CAPA
              </button>
              <button className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                Add Note
              </button>
              <button className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                View History
              </button>
            </div>

            {/* Action Buttons for Training - ISO 13485:8.5.3 Effectiveness */}
            {selectedCAPA.status === 'Implementation' && (
              <div className="bg-green-50 rounded-lg p-4 border border-green-200">
                <h4 className="text-sm font-semibold text-green-900 mb-3 flex items-center gap-2">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                  </svg>
                  Effectiveness Actions (ISO 13485:8.5.3)
                </h4>
                <p className="text-xs text-green-700 mb-3">
                  Assign training to ensure staff are aware of the corrective actions implemented.
                </p>
                <button 
                  onClick={() => setShowAssignTrainingModal(true)}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                  </svg>
                  Assign Training
                </button>
              </div>
            )}

            {/* Traceability Section */}
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="text-sm font-semibold text-gray-900 mb-3 flex items-center gap-2">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                </svg>
                Traceability - Source Information
              </h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">Source:</span>
                  <span className="font-medium">{selectedCAPA.source}</span>
                </div>
                {selectedCAPA.sourceReferenceId && (
                  <div className="flex justify-between">
                    <span className="text-gray-500">Reference ID:</span>
                    <span className="font-medium text-blue-600">{selectedCAPA.sourceReferenceId}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* Assign Training Modal - Linked to CAPA */}
      <CreateTrainingModal
        isOpen={showAssignTrainingModal}
        onClose={() => setShowAssignTrainingModal(false)}
        sourceCAPA={selectedCAPA || undefined}
        onSuccess={() => refetch()}
      />

      {/* New CAPA Modal - ISO 13485:8.5.2 Compliant Form */}
      <Modal
        isOpen={showNewCAPAModal}
        onClose={() => setShowNewCAPAModal(false)}
        title="Create New CAPA"
        size="2xl"
      >
        <form onSubmit={handleCreateCAPA} className="space-y-6">
          {/* Section 1: Basic Information */}
          <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
            <h3 className="text-sm font-semibold text-blue-900 mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              Basic Information
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  CAPA Title <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={newCAPAData.title}
                  onChange={(e) => setNewCAPAData({ ...newCAPAData, title: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="Enter CAPA title"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  CAPA Type <span className="text-red-500">*</span>
                </label>
                <select
                  value={newCAPAData.type}
                  onChange={(e) => setNewCAPAData({ ...newCAPAData, type: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  required
                >
                  <option value="Corrective">Corrective Action</option>
                  <option value="Preventive">Preventive Action</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Priority <span className="text-red-500">*</span>
                </label>
                <select
                  value={newCAPAData.priority}
                  onChange={(e) => setNewCAPAData({ ...newCAPAData, priority: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  required
                >
                  <option value="Critical">Critical</option>
                  <option value="High">High</option>
                  <option value="Medium">Medium</option>
                  <option value="Low">Low</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 2: Source and Reference - ISO 13485:8.5.2 */}
          <div className="bg-green-50 rounded-lg p-4 border border-green-200">
            <h3 className="text-sm font-semibold text-green-900 mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
              </svg>
              Source and Reference (ISO 13485:8.5.2)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Source <span className="text-red-500">*</span>
                </label>
                <select
                  value={newCAPAData.source}
                  onChange={(e) => setNewCAPAData({ ...newCAPAData, source: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none"
                  required
                >
                  <option value="Non-Conformance">Non-Conformance</option>
                  <option value="Audit Finding">Audit Finding</option>
                  <option value="Customer Complaint">Customer Complaint</option>
                  <option value="Regulatory Finding">Regulatory Finding</option>
                  <option value="Process Deviation">Process Deviation</option>
                  <option value="Supplier Issue">Supplier Issue</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Source Reference ID
                </label>
                <input
                  type="text"
                  value={newCAPAData.sourceReferenceId}
                  onChange={(e) => setNewCAPAData({ ...newCAPAData, sourceReferenceId: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none"
                  placeholder="e.g., NCR-2025-001"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Source Description
                </label>
                <textarea
                  value={newCAPAData.sourceDescription}
                  onChange={(e) => setNewCAPAData({ ...newCAPAData, sourceDescription: e.target.value })}
                  rows={2}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none"
                  placeholder="Describe the source of this CAPA"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Problem Statement - ISO 13485:8.5.2 */}
          <div className="bg-yellow-50 rounded-lg p-4 border border-yellow-200">
            <h3 className="text-sm font-semibold text-yellow-900 mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              Problem Statement (ISO 13485:8.5.2)
            </h3>
            <div className="grid grid-cols-1 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={newCAPAData.description}
                  onChange={(e) => setNewCAPAData({ ...newCAPAData, description: e.target.value })}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 outline-none"
                  placeholder="Detailed description of the issue or opportunity"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Problem Statement
                </label>
                <textarea
                  value={newCAPAData.problemStatement}
                  onChange={(e) => setNewCAPAData({ ...newCAPAData, problemStatement: e.target.value })}
                  rows={2}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 outline-none"
                  placeholder="Clear statement of the problem to be addressed"
                />
              </div>
            </div>
          </div>

          {/* Section 4: Investigation - ISO 13485:8.5.2 */}
          <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
            <h3 className="text-sm font-semibold text-purple-900 mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              Investigation (ISO 13485:8.5.2)
            </h3>
            <div className="grid grid-cols-1 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Investigation Details
                </label>
                <textarea
                  value={newCAPAData.investigationDetails}
                  onChange={(e) => setNewCAPAData({ ...newCAPAData, investigationDetails: e.target.value })}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none"
                  placeholder="Describe the investigation process and findings"
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Root Cause Category
                  </label>
                  <select
                    value={newCAPAData.rootCauseCategory}
                    onChange={(e) => setNewCAPAData({ ...newCAPAData, rootCauseCategory: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none"
                  >
                    <option value="">Select Category</option>
                    <option value="Man">Man (Human)</option>
                    <option value="Machine">Machine (Equipment)</option>
                    <option value="Method">Method (Process)</option>
                    <option value="Material">Material</option>
                    <option value="Measurement">Measurement</option>
                    <option value="Environment">Environment</option>
                    <option value="Management">Management</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Root Cause Analysis
                  </label>
                  <input
                    type="text"
                    value={newCAPAData.rootCauseAnalysis}
                    onChange={(e) => setNewCAPAData({ ...newCAPAData, rootCauseAnalysis: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none"
                    placeholder="Identified root cause"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Section 5: Correction and Corrective Action - ISO 13485:8.5.2 */}
          <div className="bg-orange-50 rounded-lg p-4 border border-orange-200">
            <h3 className="text-sm font-semibold text-orange-900 mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
              </svg>
              Correction and Corrective Action (ISO 13485:8.5.2)
            </h3>
            <div className="grid grid-cols-1 gap-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Immediate Correction
                  </label>
                  <textarea
                    value={newCAPAData.immediateCorrection}
                    onChange={(e) => setNewCAPAData({ ...newCAPAData, immediateCorrection: e.target.value })}
                    rows={2}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none"
                    placeholder="Immediate action taken to address the issue"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Correction Implementation Date
                  </label>
                  <input
                    type="date"
                    value={newCAPAData.correctionImplementationDate}
                    onChange={(e) => setNewCAPAData({ ...newCAPAData, correctionImplementationDate: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Corrective Action
                  </label>
                  <textarea
                    value={newCAPAData.correctiveAction}
                    onChange={(e) => setNewCAPAData({ ...newCAPAData, correctiveAction: e.target.value })}
                    rows={2}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none"
                    placeholder="Action to eliminate the cause of the nonconformity"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Action Implementation Date
                  </label>
                  <input
                    type="date"
                    value={newCAPAData.actionImplementationDate}
                    onChange={(e) => setNewCAPAData({ ...newCAPAData, actionImplementationDate: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Corrective Action Plan
                </label>
                <textarea
                  value={newCAPAData.correctiveActionPlan}
                  onChange={(e) => setNewCAPAData({ ...newCAPAData, correctiveActionPlan: e.target.value })}
                  rows={2}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none"
                  placeholder="Detailed plan for implementing corrective action"
                />
              </div>
            </div>
          </div>

          {/* Section 6: Effectiveness Verification - ISO 13485:8.5.3 */}
          <div className="bg-teal-50 rounded-lg p-4 border border-teal-200">
            <h3 className="text-sm font-semibold text-teal-900 mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Effectiveness Verification (ISO 13485:8.5.3)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Verification Method
                </label>
                <select
                  value={newCAPAData.effectivenessVerificationMethod}
                  onChange={(e) => setNewCAPAData({ ...newCAPAData, effectivenessVerificationMethod: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none"
                >
                  <option value="">Select Method</option>
                  <option value="Audit">Audit</option>
                  <option value="Monitoring">Monitoring</option>
                  <option value="Testing">Testing</option>
                  <option value="Data Analysis">Data Analysis</option>
                  <option value="Customer Feedback">Customer Feedback</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Effectiveness Criteria
                </label>
                <input
                  type="text"
                  value={newCAPAData.effectivenessCriteria}
                  onChange={(e) => setNewCAPAData({ ...newCAPAData, effectivenessCriteria: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none"
                  placeholder="Criteria for effectiveness"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Review Date
                </label>
                <input
                  type="date"
                  value={newCAPAData.effectivenessReviewDate}
                  onChange={(e) => setNewCAPAData({ ...newCAPAData, effectivenessReviewDate: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none"
                />
              </div>
            </div>
          </div>

          {/* Section 7: Assignment and Links */}
          <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
            <h3 className="text-sm font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
              Assignment and Links
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Assigned To <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={newCAPAData.assignedTo}
                  onChange={(e) => setNewCAPAData({ ...newCAPAData, assignedTo: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="Enter responsible person"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Due Date <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  value={newCAPAData.dueDate}
                  onChange={(e) => setNewCAPAData({ ...newCAPAData, dueDate: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Linked NCR ID
                </label>
                <input
                  type="text"
                  value={newCAPAData.linkedNCRId}
                  onChange={(e) => setNewCAPAData({ ...newCAPAData, linkedNCRId: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="e.g., NCR-2025-001"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Linked Audit ID
                </label>
                <input
                  type="text"
                  value={newCAPAData.linkedAuditId}
                  onChange={(e) => setNewCAPAData({ ...newCAPAData, linkedAuditId: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="e.g., AUD-2025-001"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Linked Deviation ID
                </label>
                <input
                  type="text"
                  value={newCAPAData.linkedDeviationId}
                  onChange={(e) => setNewCAPAData({ ...newCAPAData, linkedDeviationId: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="e.g., DEV-2025-001"
                />
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex items-center gap-3 pt-4 border-t">
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-blue-400 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Creating CAPA...
                </>
              ) : (
                <>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                  </svg>
                  Create CAPA
                </>
              )}
            </button>
            <button
              type="button"
              onClick={() => setShowNewCAPAModal(false)}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default CAPAManagement;
