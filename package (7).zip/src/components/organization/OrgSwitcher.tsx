import React, { useState, useEffect, useRef } from 'react';
import { useOrganization } from '@/contexts/OrganizationContext';
import { Building2, ChevronDown, Plus, Check } from 'lucide-react';

const OrgSwitcher: React.FC = () => {
  const { currentOrg, memberships, switchOrganization, isLoading } = useOrganization();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center gap-2 px-3 py-2 bg-gray-100 rounded-lg animate-pulse">
        <div className="w-5 h-5 bg-gray-200 rounded" />
        <div className="w-32 h-4 bg-gray-200 rounded" />
      </div>
    );
  }

  if (!currentOrg) {
    return null;
  }

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors min-w-[200px]"
      >
        <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
          {currentOrg.logo_url ? (
            <img src={currentOrg.logo_url} alt={currentOrg.name} className="w-6 h-6 rounded" />
          ) : (
            <Building2 className="w-4 h-4 text-blue-600" />
          )}
        </div>
        <div className="flex-1 text-left">
          <p className="text-sm font-medium text-gray-900 truncate">{currentOrg.name}</p>
          <p className="text-xs text-gray-500 capitalize">{currentOrg.subscription_status}</p>
        </div>
        <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg z-50">
          <div className="p-2 border-b border-gray-100">
            <p className="text-xs font-medium text-gray-500 uppercase tracking-wider px-2">Organizations</p>
          </div>
          
          <div className="max-h-60 overflow-y-auto">
            {memberships.map((membership) => (
              <button
                key={membership.organization_id}
                onClick={() => {
                  switchOrganization(membership.organization_id);
                  setIsOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2 hover:bg-gray-50 transition-colors ${
                  currentOrg.id === membership.organization_id ? 'bg-blue-50' : ''
                }`}
              >
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                  currentOrg.id === membership.organization_id ? 'bg-blue-100' : 'bg-gray-100'
                }`}>
                  <Building2 className={`w-4 h-4 ${currentOrg.id === membership.organization_id ? 'text-blue-600' : 'text-gray-500'}`} />
                </div>
                <div className="flex-1 text-left">
                  <p className="text-sm font-medium text-gray-900">
                    {membership.organization_id === currentOrg.id ? currentOrg.name : 'Loading...'}
                  </p>
                  <p className="text-xs text-gray-500 capitalize">{membership.role}</p>
                </div>
                {currentOrg.id === membership.organization_id && (
                  <Check className="w-4 h-4 text-blue-600" />
                )}
              </button>
            ))}
          </div>

          <div className="p-2 border-t border-gray-100">
            <button
              onClick={() => {
                setIsOpen(false);
                // TODO: Open create organization modal
              }}
              className="w-full flex items-center gap-2 px-3 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
            >
              <Plus className="w-4 h-4" />
              Create New Organization
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default OrgSwitcher;
