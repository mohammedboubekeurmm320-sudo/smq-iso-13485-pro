import React from 'react';
import { useTheme, ThemeMode } from '@/contexts/ThemeContext';

interface ThemeSwitcherProps {
  showLabels?: boolean;
  variant?: 'buttons' | 'dropdown' | 'icons';
}

const ThemeSwitcher: React.FC<ThemeSwitcherProps> = ({
  showLabels = true,
  variant = 'buttons',
}) => {
  const { themeMode, setThemeMode, theme } = useTheme();

  const themes: { mode: ThemeMode; name: string; icon: React.ReactNode }[] = [
    {
      mode: 'light',
      name: 'Light',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
        </svg>
      ),
    },
    {
      mode: 'dark',
      name: 'Dark',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
        </svg>
      ),
    },
    {
      mode: 'high-contrast',
      name: 'High Contrast',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
        </svg>
      ),
    },
  ];

  if (variant === 'dropdown') {
    return (
      <select
        value={themeMode}
        onChange={(e) => setThemeMode(e.target.value as ThemeMode)}
        className="px-3 py-2 text-sm border border-gray-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        aria-label="Select theme"
      >
        {themes.map((t) => (
          <option key={t.mode} value={t.mode}>
            {t.name}
          </option>
        ))}
      </select>
    );
  }

  if (variant === 'icons') {
    return (
      <div className="flex items-center gap-1" role="radiogroup" aria-label="Theme selection">
        {themes.map((t) => (
          <button
            key={t.mode}
            onClick={() => setThemeMode(t.mode)}
            className={`p-2 rounded-lg transition-colors ${
              themeMode === t.mode
                ? 'bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-300'
                : 'text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800'
            }`}
            role="radio"
            aria-checked={themeMode === t.mode}
            aria-label={`${t.name} theme`}
            title={t.name}
          >
            {t.icon}
          </button>
        ))}
      </div>
    );
  }

  // Default: buttons variant
  return (
    <div className="flex items-center gap-2" role="radiogroup" aria-label="Theme selection">
      {themes.map((t) => (
        <button
          key={t.mode}
          onClick={() => setThemeMode(t.mode)}
          className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
            themeMode === t.mode
              ? 'bg-blue-600 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700'
          }`}
          role="radio"
          aria-checked={themeMode === t.mode}
        >
          {t.icon}
          {showLabels && <span>{t.name}</span>}
        </button>
      ))}
    </div>
  );
};

export default ThemeSwitcher;
