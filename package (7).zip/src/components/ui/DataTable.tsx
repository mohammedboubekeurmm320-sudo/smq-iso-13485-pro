import React, { useState, useMemo, useCallback, memo } from 'react';

interface Column<T> {
  key: keyof T | string;
  header: string;
  render?: (item: T) => React.ReactNode;
  sortable?: boolean;
  mobileHidden?: boolean; // Hide on mobile
}

interface DataTableProps<T> {
  data: T[];
  columns: Column<T>[];
  onRowClick?: (item: T) => void;
  searchPlaceholder?: string;
  searchKeys?: (keyof T)[];
  enableMobileCards?: boolean; // Enable card view on mobile
}

// Memoized DataTable for performance optimization with mobile support
const DataTableInner = <T extends { id: string }>({
  data,
  columns,
  onRowClick,
  searchPlaceholder = 'Search...',
  searchKeys = [],
  enableMobileCards = true,
}: DataTableProps<T>) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortKey, setSortKey] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');

  // Check if we're on mobile
  const [isMobile, setIsMobile] = useState(false);

  // Handle responsive view
  React.useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Auto-switch to card view on mobile if enabled
  React.useEffect(() => {
    if (enableMobileCards && isMobile) {
      setViewMode('cards');
    }
  }, [isMobile, enableMobileCards]);

  const filteredData = useMemo(() => {
    let result = [...data];

    if (searchTerm && searchKeys.length > 0) {
      result = result.filter((item) =>
        searchKeys.some((key) => {
          const value = item[key];
          if (typeof value === 'string') {
            return value.toLowerCase().includes(searchTerm.toLowerCase());
          }
          return false;
        })
      );
    }

    if (sortKey) {
      result.sort((a, b) => {
        const aValue = (a as Record<string, unknown>)[sortKey];
        const bValue = (b as Record<string, unknown>)[sortKey];
        
        if (typeof aValue === 'string' && typeof bValue === 'string') {
          return sortDirection === 'asc'
            ? aValue.localeCompare(bValue)
            : bValue.localeCompare(aValue);
        }
        if (typeof aValue === 'number' && typeof bValue === 'number') {
          return sortDirection === 'asc' ? aValue - bValue : bValue - aValue;
        }
        return 0;
      });
    }

    return result;
  }, [data, searchTerm, searchKeys, sortKey, sortDirection]);

  const handleSort = (key: string) => {
    if (sortKey === key) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortDirection('asc');
    }
  };

  // Mobile card view
  const renderCardView = () => (
    <div className="space-y-3 p-4">
      {filteredData.map((item) => (
        <div
          key={item.id}
          className={`bg-white rounded-lg shadow-sm border border-gray-200 p-4 ${
            onRowClick ? 'cursor-pointer hover:shadow-md transition-shadow' : ''
          }`}
          onClick={() => onRowClick?.(item)}
        >
          {columns.map((column, index) => {
            if (column.mobileHidden) return null;
            
            return (
              <div 
                key={String(column.key)} 
                className={`flex justify-between items-start ${index > 0 ? 'mt-2 pt-2 border-t border-gray-100' : ''}`}
              >
                <span className="text-xs font-medium text-gray-500 uppercase">
                  {column.header}
                </span>
                <span className="text-sm text-gray-900 text-right max-w-[60%]">
                  {column.render
                    ? column.render(item)
                    : String((item as Record<string, unknown>)[String(column.key)] ?? '')}
                </span>
              </div>
            );
          })}
        </div>
      ))}
      
      {filteredData.length === 0 && (
        <div className="p-8 text-center text-gray-500">
          No records found matching your search criteria.
        </div>
      )}
    </div>
  );

  // Table view
  const renderTableView = () => (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead className="bg-gray-50">
          <tr>
            {columns.map((column) => (
              <th
                key={String(column.key)}
                className={`px-4 lg:px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider ${
                  column.sortable ? 'cursor-pointer hover:bg-gray-100 select-none' : ''
                } ${column.mobileHidden ? 'hidden md:table-cell' : ''}`}
                onClick={() => column.sortable && handleSort(String(column.key))}
              >
                <div className="flex items-center gap-2">
                  {column.header}
                  {column.sortable && sortKey === column.key && (
                    <svg
                      className={`w-4 h-4 transition-transform ${
                        sortDirection === 'desc' ? 'rotate-180' : ''
                      }`}
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M5 15l7-7 7 7"
                      />
                    </svg>
                  )}
                </div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200">
          {filteredData.map((item) => (
            <tr
              key={item.id}
              className={`hover:bg-gray-50 transition-colors ${
                onRowClick ? 'cursor-pointer' : ''
              }`}
              onClick={() => onRowClick?.(item)}
            >
              {columns.map((column) => (
                <td 
                  key={String(column.key)} 
                  className={`px-4 lg:px-6 py-4 whitespace-nowrap text-sm text-gray-700 ${column.mobileHidden ? 'hidden md:table-cell' : ''}`}
                >
                  {column.render
                    ? column.render(item)
                    : String((item as Record<string, unknown>)[String(column.key)] ?? '')}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      
      {filteredData.length === 0 && (
        <div className="p-8 text-center text-gray-500">
          No records found matching your search criteria.
        </div>
      )}
    </div>
  );

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      {/* Toolbar */}
      <div className="p-4 border-b border-gray-200 flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <svg
            className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
            />
          </svg>
          <input
            type="text"
            placeholder={searchPlaceholder}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-colors"
          />
        </div>

        {/* View toggle - only show on mobile */}
        {enableMobileCards && (
          <div className="flex items-center gap-2 sm:hidden">
            <button
              onClick={() => setViewMode('table')}
              className={`p-2 rounded-lg transition-colors ${
                viewMode === 'table' 
                  ? 'bg-blue-100 text-blue-600' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
              aria-label="Table view"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" />
              </svg>
            </button>
            <button
              onClick={() => setViewMode('cards')}
              className={`p-2 rounded-lg transition-colors ${
                viewMode === 'cards' 
                  ? 'bg-blue-100 text-blue-600' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
              aria-label="Card view"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
              </svg>
            </button>
          </div>
        )}
      </div>

      {/* Content */}
      {viewMode === 'cards' ? renderCardView() : renderTableView()}

      {/* Footer */}
      <div className="px-4 lg:px-6 py-3 bg-gray-50 border-t border-gray-200 text-sm text-gray-600 flex flex-col sm:flex-row justify-between items-center gap-2">
        <span>
          Showing {filteredData.length} of {data.length} records
        </span>
        {isMobile && (
          <span className="text-xs text-gray-500">
            Tap row to view details
          </span>
        )}
      </div>
    </div>
  );
}

// Export memoized version for better performance
export default memo(DataTableInner) as typeof DataTableInner;
