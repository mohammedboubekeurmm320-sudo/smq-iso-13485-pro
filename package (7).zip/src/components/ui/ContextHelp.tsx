import React, { useState, useCallback } from 'react';

export interface HelpTooltip {
  id: string;
  target: string;
  title: string;
  content: string;
  position?: 'top' | 'bottom' | 'left' | 'right';
}

interface ContextHelpProps {
  tooltips?: HelpTooltip[];
  children: React.ReactNode;
}

interface TooltipState {
  id: string;
  position: { x: number; y: number };
}

const defaultTooltips: HelpTooltip[] = [
  {
    id: 'search',
    target: '[data-help="search"]',
    title: 'Search',
    content: 'Use keywords to search across all documents, CAPAs, NCRs, and more. Press Ctrl+K for quick access.',
    position: 'bottom',
  },
  {
    id: 'create-document',
    target: '[data-help="create-document"]',
    title: 'Create Document',
    content: 'Click to create a new controlled document. Fill in all required fields and submit for approval.',
    position: 'right',
  },
  {
    id: 'export',
    target: '[data-help="export"]',
    title: 'Export Data',
    content: 'Export current view to Excel, PDF, or CSV format. Select columns to include in the export.',
    position: 'bottom',
  },
];

export const ContextHelp: React.FC<ContextHelpProps> = ({ 
  tooltips = defaultTooltips,
  children 
}) => {
  const [activeTooltip, setActiveTooltip] = useState<TooltipState | null>(null);
  const [dismissed, setDismissed] = useState<Set<string>>(new Set());

  const showTooltip = useCallback((tooltipId: string, x: number, y: number) => {
    if (dismissed.has(tooltipId)) return;
    setActiveTooltip({ id: tooltipId, position: { x, y } });
  }, [dismissed]);

  const hideTooltip = useCallback(() => {
    setActiveTooltip(null);
  }, []);

  const dismissTooltip = useCallback((tooltipId: string) => {
    setDismissed((prev) => new Set(prev).add(tooltipId));
    hideTooltip();
  }, [hideTooltip]);

  const activeTooltipData = activeTooltip 
    ? tooltips.find((t) => t.id === activeTooltip.id) 
    : null;

  return (
    <div className="context-help-provider" onMouseLeave={hideTooltip}>
      {children}
      
      {activeTooltipData && activeTooltip && (
        <div
          className="fixed z-50 max-w-xs p-4 bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-200 dark:border-gray-700"
          style={{
            left: Math.min(activeTooltip.position.x, window.innerWidth - 320),
            top: Math.min(activeTooltip.position.y + 10, window.innerHeight - 200),
          }}
          role="tooltip"
        >
          <div className="flex items-start justify-between gap-2 mb-2">
            <h4 className="font-semibold text-gray-900 dark:text-white">
              {activeTooltipData.title}
            </h4>
            <button
              onClick={() => dismissTooltip(activeTooltipData.id)}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              aria-label="Dismiss help"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          <p className="text-sm text-gray-600 dark:text-gray-300">
            {activeTooltipData.content}
          </p>
        </div>
      )}
    </div>
  );
};

// Hook for triggering help tooltips
export const useContextHelp = () => {
  const [helpEnabled, setHelpEnabled] = useState(true);

  const enableHelp = useCallback(() => setHelpEnabled(true), []);
  const disableHelp = useCallback(() => setHelpEnabled(false), []);
  const toggleHelp = useCallback(() => setHelpEnabled((prev) => !prev), []);

  return {
    helpEnabled,
    enableHelp,
    disableHelp,
    toggleHelp,
  };
};

export default ContextHelp;
