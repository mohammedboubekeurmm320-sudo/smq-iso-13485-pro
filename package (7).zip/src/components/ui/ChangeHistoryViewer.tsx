import React from 'react';
import { ChangeRecord } from '@/hooks/useChangeHistory';

interface ChangeHistoryViewerProps {
  changes: ChangeRecord[];
  isLoading?: boolean;
  maxItems?: number;
  showFilters?: boolean;
}

const getChangeTypeColor = (changeType: string): string => {
  const colors: Record<string, string> = {
    create: 'bg-green-100 text-green-800',
    update: 'bg-blue-100 text-blue-800',
    delete: 'bg-red-100 text-red-800',
    view: 'bg-gray-100 text-gray-800',
    export: 'bg-purple-100 text-purple-800',
    sign: 'bg-yellow-100 text-yellow-800',
    approve: 'bg-green-100 text-green-800',
    reject: 'bg-red-100 text-red-800',
  };
  return colors[changeType] || 'bg-gray-100 text-gray-800';
};

const getChangeTypeIcon = (changeType: string): React.ReactNode => {
  const icons: Record<string, React.ReactNode> = {
    create: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
      </svg>
    ),
    update: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
      </svg>
    ),
    delete: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
      </svg>
    ),
    approve: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
      </svg>
    ),
    sign: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
      </svg>
    ),
  };
  return icons[changeType] || (
    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  );
};

const formatDate = (timestamp: string): string => {
  const date = new Date(timestamp);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
  if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
  if (diffDays < 7) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;

  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
};

const ChangeHistoryViewer: React.FC<ChangeHistoryViewerProps> = ({
  changes,
  isLoading = false,
  maxItems,
  showFilters = true,
}) => {
  const [filter, setFilter] = React.useState<string>('all');
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredChanges = React.useMemo(() => {
    let result = changes;

    if (filter !== 'all') {
      result = result.filter((change) => change.changeType === filter);
    }

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(
        (change) =>
          change.description.toLowerCase().includes(term) ||
          change.userName.toLowerCase().includes(term) ||
          change.entityName.toLowerCase().includes(term)
      );
    }

    return maxItems ? result.slice(0, maxItems) : result;
  }, [changes, filter, searchTerm, maxItems]);

  if (isLoading) {
    return (
      <div className="p-4 flex items-center justify-center">
        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
        <span className="ml-2 text-gray-500">Loading history...</span>
      </div>
    );
  }

  if (changes.length === 0) {
    return (
      <div className="p-8 text-center text-gray-500">
        <svg className="w-12 h-12 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <p>No history records found</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {showFilters && (
        <div className="flex flex-col sm:flex-row gap-3 pb-4 border-b border-gray-200">
          {/* Search */}
          <div className="relative flex-1">
            <svg className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input
              type="text"
              placeholder="Search history..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          {/* Filter */}
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="all">All Changes</option>
            <option value="create">Created</option>
            <option value="update">Updated</option>
            <option value="delete">Deleted</option>
            <option value="approve">Approved</option>
            <option value="reject">Rejected</option>
            <option value="sign">Signed</option>
            <option value="export">Exported</option>
          </select>
        </div>
      )}

      {/* Timeline */}
      <div className="space-y-4">
        {filteredChanges.map((change, index) => (
          <div key={change.id || index} className="relative flex gap-4">
            {/* Timeline connector */}
            {index < filteredChanges.length - 1 && (
              <div className="absolute left-4 top-10 bottom-0 w-0.5 bg-gray-200"></div>
            )}

            {/* Icon */}
            <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${getChangeTypeColor(change.changeType)}`}>
              {getChangeTypeIcon(change.changeType)}
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">{change.description}</p>
                  {change.fieldName && (
                    <div className="mt-1 flex items-center gap-2 text-xs">
                      <span className="text-gray-500">{change.fieldName}:</span>
                      <span className="line-through text-red-600">{change.oldValue || 'empty'}</span>
                      <span className="text-gray-400">→</span>
                      <span className="text-green-600">{change.newValue || 'empty'}</span>
                    </div>
                  )}
                </div>
                <span className={`flex-shrink-0 text-xs px-2 py-1 rounded-full ${getChangeTypeColor(change.changeType)}`}>
                  {change.changeType}
                </span>
              </div>

              {/* Meta */}
              <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-gray-500">
                <span className="flex items-center gap-1">
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                  {change.userName}
                </span>
                <span className="flex items-center gap-1">
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  {formatDate(change.timestamp)}
                </span>
                {change.userRole && (
                  <span className="px-1.5 py-0.5 bg-gray-100 rounded text-gray-600">
                    {change.userRole}
                  </span>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredChanges.length === 0 && (
        <div className="p-4 text-center text-gray-500 text-sm">
          No changes match your filters
        </div>
      )}
    </div>
  );
};

export default ChangeHistoryViewer;
