import React, { useState } from 'react';
import { Check, X, Sparkles, ArrowRight } from 'lucide-react';

interface Plan {
  id: string;
  name: string;
  description: string;
  price_monthly: number;
  price_yearly: number;
  features: string[];
  limits: Record<string, any>;
  is_popular?: boolean;
}

interface PricingTableProps {
  plans: Plan[];
  currentPlanId?: string;
  onSelectPlan: (plan: Plan, billingCycle: 'monthly' | 'yearly') => void;
  isLoading?: boolean;
}

const PricingTable: React.FC<PricingTableProps> = ({
  plans,
  currentPlanId,
  onSelectPlan,
  isLoading = false,
}) => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');

  const formatPrice = (cents: number) => {
    if (cents === 0) return 'Custom';
    return (cents / 100).toFixed(2);
  };

  const getYearlySavings = (monthly: number, yearly: number) => {
    const monthlyTotal = monthly * 12;
    const savings = monthlyTotal - yearly;
    return Math.round((savings / monthlyTotal) * 100);
  };

  return (
    <div className="w-full">
      {/* Billing Toggle */}
      <div className="flex justify-center mb-8">
        <div className="bg-gray-100 p-1 rounded-lg flex">
          <button
            onClick={() => setBillingCycle('monthly')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
              billingCycle === 'monthly'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Monthly
          </button>
          <button
            onClick={() => setBillingCycle('yearly')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-all flex items-center gap-2 ${
              billingCycle === 'yearly'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Yearly
            <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">
              Save 20%
            </span>
          </button>
        </div>
      </div>

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {plans.map((plan) => {
          const isCurrentPlan = currentPlanId === plan.id;
          const price = billingCycle === 'monthly' ? plan.price_monthly : plan.price_yearly;
          const isEnterprise = plan.id === 'enterprise';

          return (
            <div
              key={plan.id}
              className={`relative bg-white rounded-2xl border-2 transition-all ${
                plan.is_popular
                  ? 'border-blue-500 shadow-lg scale-105 z-10'
                  : 'border-gray-200 shadow-sm hover:border-gray-300'
              }`}
            >
              {/* Popular Badge */}
              {plan.is_popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <div className="bg-blue-500 text-white px-4 py-1 rounded-full text-sm font-medium flex items-center gap-1">
                    <Sparkles className="w-4 h-4" />
                    Most Popular
                  </div>
                </div>
              )}

              <div className="p-6">
                {/* Plan Header */}
                <div className="text-center mb-6">
                  <h3 className="text-xl font-bold text-gray-900">{plan.name}</h3>
                  <p className="text-sm text-gray-500 mt-1">{plan.description}</p>
                </div>

                {/* Pricing */}
                <div className="text-center mb-6">
                  {isEnterprise ? (
                    <div className="text-3xl font-bold text-gray-900">Custom</div>
                  ) : (
                    <>
                      <div className="flex items-baseline justify-center gap-1">
                        <span className="text-4xl font-bold text-gray-900">
                          €{formatPrice(price)}
                        </span>
                        <span className="text-gray-500">/{billingCycle === 'monthly' ? 'mo' : 'yr'}</span>
                      </div>
                      {billingCycle === 'yearly' && plan.price_monthly > 0 && (
                        <p className="text-sm text-green-600 mt-1">
                          Save {getYearlySavings(plan.price_monthly, plan.price_yearly)}%
                        </p>
                      )}
                    </>
                  )}
                </div>

                {/* Features */}
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <span className="text-sm text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>

                {/* Action Button */}
                <button
                  onClick={() => onSelectPlan(plan, billingCycle)}
                  disabled={isCurrentPlan || isLoading}
                  className={`w-full py-3 px-4 rounded-lg font-medium flex items-center justify-center gap-2 transition-all ${
                    isCurrentPlan
                      ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                      : plan.is_popular
                      ? 'bg-blue-600 text-white hover:bg-blue-700'
                      : 'bg-gray-900 text-white hover:bg-gray-800'
                  }`}
                >
                  {isCurrentPlan ? (
                    'Current Plan'
                  ) : isEnterprise ? (
                    <>
                      Contact Sales
                      <ArrowRight className="w-4 h-4" />
                    </>
                  ) : (
                    <>
                      {currentPlanId ? 'Switch Plan' : 'Get Started'}
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default PricingTable;
