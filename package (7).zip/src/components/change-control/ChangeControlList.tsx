import React, { useState } from 'react';
import { useChangeControl } from '@/contexts/ChangeControlContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Plus, Search, Filter, FileText, AlertCircle, CheckCircle, Clock, XCircle } from 'lucide-react';
import { ChangeControl, ChangeStatus, ChangePriority, ChangeType } from '@/types/qms';

const statusConfig: Record<ChangeStatus, { label: string; color: string; icon: React.ReactNode }> = {
  DRAFT: { label: 'Draft', color: 'bg-gray-100 text-gray-800', icon: <FileText className="h-4 w-4" /> },
  IMPACT_ANALYSIS: { label: 'Impact Analysis', color: 'bg-blue-100 text-blue-800', icon: <Search className="h-4 w-4" /> },
  PENDING_APPROVAL: { label: 'Pending Approval', color: 'bg-yellow-100 text-yellow-800', icon: <Clock className="h-4 w-4" /> },
  APPROVED: { label: 'Approved', color: 'bg-green-100 text-green-800', icon: <CheckCircle className="h-4 w-4" /> },
  REJECTED: { label: 'Rejected', color: 'bg-red-100 text-red-800', icon: <XCircle className="h-4 w-4" /> },
  IMPLEMENTATION: { label: 'Implementation', color: 'bg-purple-100 text-purple-800', icon: <AlertCircle className="h-4 w-4" /> },
  VERIFICATION: { label: 'Verification', color: 'bg-indigo-100 text-indigo-800', icon: <CheckCircle className="h-4 w-4" /> },
  CLOSED: { label: 'Closed', color: 'bg-gray-100 text-gray-600', icon: <CheckCircle className="h-4 w-4" /> },
};

const priorityConfig: Record<ChangePriority, { label: string; color: string }> = {
  LOW: { label: 'Low', color: 'bg-green-100 text-green-800' },
  MEDIUM: { label: 'Medium', color: 'bg-yellow-100 text-yellow-800' },
  HIGH: { label: 'High', color: 'bg-orange-100 text-orange-800' },
  EMERGENCY: { label: 'Emergency', color: 'bg-red-100 text-red-800' },
};

const changeTypeLabels: Record<ChangeType, string> = {
  PROCESS: 'Process',
  DOCUMENT: 'Document',
  DESIGN: 'Design',
  SUPPLIER: 'Supplier',
  EQUIPMENT: 'Equipment',
  SOFTWARE: 'Software',
  MATERIAL: 'Material',
};

interface ChangeControlListProps {
  onSelectChangeControl?: (id: string) => void;
}

export default function ChangeControlList({ onSelectChangeControl }: ChangeControlListProps) {
  const { changeControls, loading, createChangeControl } = useChangeControl();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [newCC, setNewCC] = useState({
    title: '',
    description: '',
    changeType: 'PROCESS' as ChangeType,
    priority: 'MEDIUM' as ChangePriority,
    justification: '',
  });

  const filteredChangeControls = changeControls.filter(cc => {
    const matchesSearch = cc.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cc.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || cc.status === statusFilter;
    const matchesPriority = priorityFilter === 'all' || cc.priority === priorityFilter;
    return matchesSearch && matchesStatus && matchesPriority;
  });

  const handleCreate = async () => {
    if (!newCC.title) return;
    await createChangeControl(newCC);
    setIsCreateDialogOpen(false);
    setNewCC({
      title: '',
      description: '',
      changeType: 'PROCESS',
      priority: 'MEDIUM',
      justification: '',
    });
  };

  const stats = {
    total: changeControls.length,
    draft: changeControls.filter(cc => cc.status === 'DRAFT').length,
    pending: changeControls.filter(cc => cc.status === 'PENDING_APPROVAL').length,
    inProgress: changeControls.filter(cc => ['IMPACT_ANALYSIS', 'IMPLEMENTATION', 'VERIFICATION'].includes(cc.status)).length,
    closed: changeControls.filter(cc => cc.status === 'CLOSED').length,
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Draft</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.draft}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Pending Approval</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.pending}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">In Progress</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.inProgress}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Closed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.closed}</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Actions */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="flex flex-1 gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:flex-initial">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
            <Input
              placeholder="Search change controls..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 w-full sm:w-[250px]"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="DRAFT">Draft</SelectItem>
              <SelectItem value="IMPACT_ANALYSIS">Impact Analysis</SelectItem>
              <SelectItem value="PENDING_APPROVAL">Pending Approval</SelectItem>
              <SelectItem value="APPROVED">Approved</SelectItem>
              <SelectItem value="IMPLEMENTATION">Implementation</SelectItem>
              <SelectItem value="VERIFICATION">Verification</SelectItem>
              <SelectItem value="CLOSED">Closed</SelectItem>
            </SelectContent>
          </Select>
          <Select value={priorityFilter} onValueChange={setPriorityFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Priority" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Priority</SelectItem>
              <SelectItem value="LOW">Low</SelectItem>
              <SelectItem value="MEDIUM">Medium</SelectItem>
              <SelectItem value="HIGH">High</SelectItem>
              <SelectItem value="EMERGENCY">Emergency</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              New Change Request
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Change Control</DialogTitle>
              <DialogDescription>
                Submit a new change request for review and approval.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="title">Title *</Label>
                <Input
                  id="title"
                  value={newCC.title}
                  onChange={(e) => setNewCC({ ...newCC, title: e.target.value })}
                  placeholder="Brief title of the change"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label>Change Type *</Label>
                  <Select
                    value={newCC.changeType}
                    onValueChange={(value) => setNewCC({ ...newCC, changeType: value as ChangeType })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="PROCESS">Process</SelectItem>
                      <SelectItem value="DOCUMENT">Document</SelectItem>
                      <SelectItem value="DESIGN">Design</SelectItem>
                      <SelectItem value="SUPPLIER">Supplier</SelectItem>
                      <SelectItem value="EQUIPMENT">Equipment</SelectItem>
                      <SelectItem value="SOFTWARE">Software</SelectItem>
                      <SelectItem value="MATERIAL">Material</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label>Priority</Label>
                  <Select
                    value={newCC.priority}
                    onValueChange={(value) => setNewCC({ ...newCC, priority: value as ChangePriority })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="LOW">Low</SelectItem>
                      <SelectItem value="MEDIUM">Medium</SelectItem>
                      <SelectItem value="HIGH">High</SelectItem>
                      <SelectItem value="EMERGENCY">Emergency</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={newCC.description}
                  onChange={(e) => setNewCC({ ...newCC, description: e.target.value })}
                  placeholder="Detailed description of the change"
                  rows={3}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="justification">Justification</Label>
                <Textarea
                  id="justification"
                  value={newCC.justification}
                  onChange={(e) => setNewCC({ ...newCC, justification: e.target.value })}
                  placeholder="Why is this change required?"
                  rows={2}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleCreate} disabled={!newCC.title}>Create Change Request</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Title</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Created</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredChangeControls.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                    No change controls found
                  </TableCell>
                </TableRow>
              ) : (
                filteredChangeControls.map((cc) => (
                  <TableRow key={cc.id}>
                    <TableCell className="font-mono text-sm">
                      {cc.id.slice(0, 8).toUpperCase()}
                    </TableCell>
                    <TableCell className="font-medium">
                      <div>{cc.title}</div>
                      {cc.changeType && (
                        <div className="text-xs text-gray-500">{changeTypeLabels[cc.changeType]}</div>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge className={priorityConfig[cc.priority].color}>
                        {priorityConfig[cc.priority].label}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={statusConfig[cc.status].color}>
                        {statusConfig[cc.status].label}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {new Date(cc.createdAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onSelectChangeControl?.(cc.id)}
                      >
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
