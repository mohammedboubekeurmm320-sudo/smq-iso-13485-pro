import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Command, FileText, Settings, Users, Shield, Bell, X, ArrowRight } from 'lucide-react';

interface SearchResult {
  id: string;
  title: string;
  description?: string;
  icon: React.ReactNode;
  action: () => void;
  category: string;
}

const CommandPalette: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  // Define searchable items
  const searchItems: SearchResult[] = [
    {
      id: 'dashboard',
      title: 'Dashboard',
      description: 'View your dashboard',
      icon: <FileText className="w-4 h-4" />,
      action: () => navigate('/'),
      category: 'Pages',
    },
    {
      id: 'documents',
      title: 'Document Control',
      description: 'Manage controlled documents',
      icon: <FileText className="w-4 h-4" />,
      action: () => navigate('/documents'),
      category: 'Modules',
    },
    {
      id: 'capa',
      title: 'CAPA Management',
      description: 'Manage corrective actions',
      icon: <Shield className="w-4 h-4" />,
      action: () => navigate('/capa'),
      category: 'Modules',
    },
    {
      id: 'audits',
      title: 'Audit Management',
      description: 'Schedule and manage audits',
      icon: <Shield className="w-4 h-4" />,
      action: () => navigate('/audits'),
      category: 'Modules',
    },
    {
      id: 'ncr',
      title: 'Non-Conformances',
      description: 'Manage non-conformities',
      icon: <Bell className="w-4 h-4" />,
      action: () => navigate('/non-conformances'),
      category: 'Modules',
    },
    {
      id: 'risks',
      title: 'Risk Management',
      description: 'Manage risks and FMEA',
      icon: <Shield className="w-4 h-4" />,
      action: () => navigate('/risks'),
      category: 'Modules',
    },
    {
      id: 'training',
      title: 'Training Records',
      description: 'Manage training',
      icon: <Users className="w-4 h-4" />,
      action: () => navigate('/training'),
      category: 'Modules',
    },
    {
      id: 'reports',
      title: 'Reports',
      description: 'Generate reports',
      icon: <FileText className="w-4 h-4" />,
      action: () => navigate('/reports'),
      category: 'Modules',
    },
    {
      id: 'settings',
      title: 'Settings',
      description: 'Organization settings',
      icon: <Settings className="w-4 h-4" />,
      action: () => navigate('/settings'),
      category: 'Pages',
    },
    {
      id: 'billing',
      title: 'Billing',
      description: 'Manage subscription',
      icon: <Settings className="w-4 h-4" />,
      action: () => navigate('/billing'),
      category: 'Pages',
    },
  ];

  // Filter results based on query
  useEffect(() => {
    if (!query.trim()) {
      setResults(searchItems.slice(0, 8));
      return;
    }

    const filtered = searchItems.filter(
      item =>
        item.title.toLowerCase().includes(query.toLowerCase()) ||
        item.description?.toLowerCase().includes(query.toLowerCase()) ||
        item.category.toLowerCase().includes(query.toLowerCase())
    );
    setResults(filtered);
    setSelectedIndex(0);
  }, [query]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Open with Cmd+K or Ctrl+K
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsOpen(true);
      }

      if (!isOpen) return;

      // Close with Escape
      if (e.key === 'Escape') {
        setIsOpen(false);
      }

      // Navigate results with arrow keys
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex(prev => (prev + 1) % results.length);
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex(prev => (prev - 1 + results.length) % results.length);
      }

      // Select result with Enter
      if (e.key === 'Enter' && results[selectedIndex]) {
        results[selectedIndex].action();
        setIsOpen(false);
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, results, selectedIndex]);

  // Focus input when opened
  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  // Group results by category
  const groupedResults = results.reduce((acc, item) => {
    if (!acc[item.category]) {
      acc[item.category] = [];
    }
    acc[item.category].push(item);
    return acc;
  }, {} as Record<string, SearchResult[]>);

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="flex items-center gap-2 px-3 py-1.5 bg-gray-100 hover:bg-gray-200 rounded-lg text-sm text-gray-500 transition-colors"
      >
        <Search className="w-4 h-4" />
        <span className="hidden md:inline">Search...</span>
        <kbd className="hidden md:inline-flex items-center gap-0.5 px-1.5 py-0.5 bg-white border border-gray-200 rounded text-xs">
          <Command className="w-3 h-3" />K
        </kbd>
      </button>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-[20vh]">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/50" onClick={() => setIsOpen(false)} />

      {/* Modal */}
      <div className="relative w-full max-w-xl bg-white rounded-xl shadow-2xl overflow-hidden">
        {/* Search Input */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-gray-200">
          <Search className="w-5 h-5 text-gray-400" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search pages, modules, settings..."
            className="flex-1 outline-none text-gray-900 placeholder-gray-400"
          />
          <button
            onClick={() => setIsOpen(false)}
            className="p-1 hover:bg-gray-100 rounded"
          >
            <X className="w-4 h-4 text-gray-400" />
          </button>
        </div>

        {/* Results */}
        <div className="max-h-96 overflow-y-auto py-2">
          {results.length === 0 ? (
            <div className="px-4 py-8 text-center">
              <p className="text-gray-500">No results found for "{query}"</p>
            </div>
          ) : (
            Object.entries(groupedResults).map(([category, items]) => (
              <div key={category}>
                <div className="px-4 py-2">
                  <p className="text-xs font-medium text-gray-400 uppercase tracking-wider">{category}</p>
                </div>
                {items.map((item) => {
                  const globalIndex = results.indexOf(item);
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        item.action();
                        setIsOpen(false);
                      }}
                      className={`w-full flex items-center gap-3 px-4 py-2.5 text-left transition-colors ${
                        globalIndex === selectedIndex
                          ? 'bg-blue-50 text-blue-700'
                          : 'hover:bg-gray-50'
                      }`}
                    >
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                        globalIndex === selectedIndex
                          ? 'bg-blue-100 text-blue-600'
                          : 'bg-gray-100 text-gray-600'
                      }`}>
                        {item.icon}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-gray-900">{item.title}</p>
                        {item.description && (
                          <p className="text-sm text-gray-500 truncate">{item.description}</p>
                        )}
                      </div>
                      {globalIndex === selectedIndex && (
                        <ArrowRight className="w-4 h-4 text-blue-500" />
                      )}
                    </button>
                  );
                })}
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="px-4 py-2 border-t border-gray-100 bg-gray-50 flex items-center justify-between text-xs text-gray-500">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 bg-white border border-gray-200 rounded">↑↓</kbd>
              Navigate
            </span>
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 bg-white border border-gray-200 rounded">↵</kbd>
              Select
            </span>
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 bg-white border border-gray-200 rounded">esc</kbd>
              Close
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CommandPalette;
