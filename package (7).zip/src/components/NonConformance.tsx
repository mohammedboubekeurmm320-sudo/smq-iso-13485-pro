import React, { useState, useMemo } from 'react';
import DataTable from './ui/DataTable';
import StatusBadge from './ui/StatusBadge';
import Modal from './ui/Modal';
import { useNonConformances, useCreateNCR } from '../modules/non-conformances/hooks/useNCRs';
import { NonConformance as NCR } from '../types/qms';
import { useOrganization } from '@/contexts/OrganizationContext';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import CreateCAPAModal from './CreateCAPAModal';

const NonConformance: React.FC = () => {
  const { currentOrganization } = useOrganization();
  const { user } = useAuth();
  const [selectedNCR, setSelectedNCR] = useState<NCR | null>(null);
  const [showNewNCRModal, setShowNewNCRModal] = useState(false);
  const [showCreateCAPAModal, setShowCreateCAPAModal] = useState(false);
  const [filterType, setFilterType] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterSeverity, setFilterSeverity] = useState<string>('all');
  
  // New NCR form state
  const [newNCRData, setNewNCRData] = useState({
    title: '',
    type: 'Product' as string,
    severity: 'Minor' as string,
    source: 'Incoming Inspection' as string,
    sourceDescription: '',
    detectedDate: new Date().toISOString().split('T')[0],
    detectedBy: '',
    lotNumber: '',
    quantityAffected: 0,
    totalQuantity: 0,
    productName: '',
    partNumber: '',
    description: '',
    immediateAction: '',
    assignedTo: '',
    dueDate: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Use React Query hooks for data fetching
  const { data: nonConformances = [], isLoading, error, refetch } = useNonConformances({
    type: filterType !== 'all' ? filterType : undefined,
    status: filterStatus !== 'all' ? filterStatus : undefined,
    severity: filterSeverity !== 'all' ? filterSeverity : undefined,
  });
  
  // Use mutations
  const createNCRMutation = useCreateNCR();

  // Handle new NCR creation
  const handleCreateNCR = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentOrganization || !user) {
      toast.error('Authentication required');
      return;
    }

    // Validation
    if (!newNCRData.title.trim()) {
      toast.error('NCR title is required');
      return;
    }
    if (!newNCRData.description.trim()) {
      toast.error('Description is required');
      return;
    }

    setIsSubmitting(true);
    try {
      await createNCRMutation.mutateAsync({
        input: {
          title: newNCRData.title,
          type: newNCRData.type,
          severity: newNCRData.severity,
          source: newNCRData.source,
          sourceDescription: newNCRData.sourceDescription,
          detectedDate: newNCRData.detectedDate,
          detectedBy: newNCRData.detectedBy || user.email,
          lotNumber: newNCRData.lotNumber,
          quantityAffected: newNCRData.quantityAffected,
          totalQuantity: newNCRData.totalQuantity,
          productName: newNCRData.productName,
          partNumber: newNCRData.partNumber,
          description: newNCRData.description,
          immediateAction: newNCRData.immediateAction,
          assignedTo: newNCRData.assignedTo,
          dueDate: newNCRData.dueDate,
        },
        userId: currentOrganization.id,
      });
      
      toast.success('Non-conformance created successfully!', {
        description: `NCR has been created and is ready for investigation.`,
      });
      
      // Reset form and close modal
      setNewNCRData({
        title: '',
        type: 'Product',
        severity: 'Minor',
        source: 'Incoming Inspection',
        sourceDescription: '',
        detectedDate: new Date().toISOString().split('T')[0],
        detectedBy: '',
        lotNumber: '',
        quantityAffected: 0,
        totalQuantity: 0,
        productName: '',
        partNumber: '',
        description: '',
        immediateAction: '',
        assignedTo: '',
        dueDate: '',
      });
      setShowNewNCRModal(false);
      
      // Refresh the NCR list
      refetch();
    } catch (err: any) {
      toast.error(err.message || 'Failed to create NCR');
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredNCRs = useMemo(() => {
    return nonConformances.filter(ncr => {
      if (filterType !== 'all' && ncr.type !== filterType) return false;
      if (filterStatus !== 'all' && ncr.status !== filterStatus) return false;
      if (filterSeverity !== 'all' && ncr.severity !== filterSeverity) return false;
      return true;
    });
  }, [nonConformances, filterType, filterStatus, filterSeverity]);

  const columns = [
    { key: 'ncrNumber', header: 'NCR #', sortable: true },
    { 
      key: 'title', 
      header: 'Title',
      render: (ncr: NCR) => (
        <span className="line-clamp-1 max-w-xs">{ncr.title}</span>
      )
    },
    { 
      key: 'type', 
      header: 'Type',
      render: (ncr: NCR) => (
        <span className={`px-2 py-1 rounded text-xs font-medium ${
          ncr.type === 'Product' ? 'bg-blue-100 text-blue-700' :
          ncr.type === 'Process' ? 'bg-purple-100 text-purple-700' :
          ncr.type === 'System' ? 'bg-green-100 text-green-700' :
          'bg-orange-100 text-orange-700'
        }`}>
          {ncr.type}
        </span>
      )
    },
    { 
      key: 'severity', 
      header: 'Severity',
      render: (ncr: NCR) => <StatusBadge status={ncr.severity} variant="severity" />
    },
    { 
      key: 'status', 
      header: 'Status',
      render: (ncr: NCR) => <StatusBadge status={ncr.status} />
    },
    { 
      key: 'disposition', 
      header: 'Disposition',
      render: (ncr: NCR) => (
        <span className={`text-sm ${ncr.disposition === 'Pending' ? 'text-gray-500 italic' : 'text-gray-700'}`}>
          {ncr.disposition}
        </span>
      )
    },
    { key: 'assignedTo', header: 'Assigned To', sortable: true },
    { key: 'createdDate', header: 'Created Date', sortable: true },
  ];

  const stats = {
    total: nonConformances.length,
    open: nonConformances.filter(n => n.status === 'Open').length,
    underInvestigation: nonConformances.filter(n => n.status === 'Under Investigation').length,
    pendingDisposition: nonConformances.filter(n => n.status === 'Pending Disposition').length,
    closed: nonConformances.filter(n => n.status === 'Closed').length,
    critical: nonConformances.filter(n => n.severity === 'Critical' && n.status !== 'Closed').length,
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Non-Conformance Reports</h2>
          <p className="text-gray-500 mt-1">Control of nonconforming product per ISO 13485 Section 8.3</p>
        </div>
        <button
          onClick={() => setShowNewNCRModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
          New NCR
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <p className="text-sm text-gray-500">Total NCRs</p>
          <p className="text-2xl font-bold text-gray-900 mt-1">{stats.total}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <p className="text-sm text-gray-500">Open</p>
          <p className="text-2xl font-bold text-yellow-600 mt-1">{stats.open}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <p className="text-sm text-gray-500">Investigating</p>
          <p className="text-2xl font-bold text-blue-600 mt-1">{stats.underInvestigation}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <p className="text-sm text-gray-500">Pending Disposition</p>
          <p className="text-2xl font-bold text-purple-600 mt-1">{stats.pendingDisposition}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <p className="text-sm text-gray-500">Closed</p>
          <p className="text-2xl font-bold text-green-600 mt-1">{stats.closed}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-red-200 p-4 bg-red-50">
          <p className="text-sm text-red-600">Critical Open</p>
          <p className="text-2xl font-bold text-red-700 mt-1">{stats.critical}</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4 flex-wrap">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          >
            <option value="all">All Types</option>
            <option value="Product">Product</option>
            <option value="Process">Process</option>
            <option value="System">System</option>
            <option value="Supplier">Supplier</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          >
            <option value="all">All Statuses</option>
            <option value="Open">Open</option>
            <option value="Under Investigation">Under Investigation</option>
            <option value="Pending Disposition">Pending Disposition</option>
            <option value="Closed">Closed</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Severity</label>
          <select
            value={filterSeverity}
            onChange={(e) => setFilterSeverity(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          >
            <option value="all">All Severities</option>
            <option value="Critical">Critical</option>
            <option value="Major">Major</option>
            <option value="Minor">Minor</option>
          </select>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors flex items-center gap-2">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
            </svg>
            Export
          </button>
        </div>
      </div>

      {/* Data Table */}
      <DataTable
        data={filteredNCRs}
        columns={columns}
        onRowClick={(ncr) => setSelectedNCR(ncr)}
        searchPlaceholder="Search NCRs..."
        searchKeys={['ncrNumber', 'title', 'assignedTo', 'lotNumber']}
      />

      {/* NCR Detail Modal */}
      <Modal
        isOpen={!!selectedNCR}
        onClose={() => setSelectedNCR(null)}
        title="NCR Details"
        size="lg"
      >
        {selectedNCR && (
          <div className="space-y-6">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-3">
                  <h4 className="text-lg font-semibold text-gray-900">{selectedNCR.ncrNumber}</h4>
                  <StatusBadge status={selectedNCR.severity} variant="severity" />
                </div>
                <p className="text-gray-700 mt-1">{selectedNCR.title}</p>
              </div>
              <StatusBadge status={selectedNCR.status} />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Type</p>
                <p className="font-medium text-gray-900">{selectedNCR.type}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Source</p>
                <p className="font-medium text-gray-900">{selectedNCR.source}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Assigned To</p>
                <p className="font-medium text-gray-900">{selectedNCR.assignedTo}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Created Date</p>
                <p className="font-medium text-gray-900">{selectedNCR.createdDate}</p>
              </div>
              {selectedNCR.lotNumber && (
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Lot Number</p>
                  <p className="font-medium text-gray-900">{selectedNCR.lotNumber}</p>
                </div>
              )}
              {selectedNCR.quantity && (
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Quantity Affected</p>
                  <p className="font-medium text-gray-900">{selectedNCR.quantity} units</p>
                </div>
              )}
            </div>

            <div>
              <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Description</p>
              <p className="text-gray-700">{selectedNCR.description}</p>
            </div>

            <div className={`rounded-lg p-4 ${
              selectedNCR.disposition === 'Pending' ? 'bg-yellow-50 border border-yellow-200' :
              selectedNCR.disposition === 'Scrap' ? 'bg-red-50 border border-red-200' :
              'bg-gray-50'
            }`}>
              <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Disposition Decision</p>
              <p className={`font-medium ${
                selectedNCR.disposition === 'Pending' ? 'text-yellow-700' :
                selectedNCR.disposition === 'Scrap' ? 'text-red-700' :
                'text-gray-900'
              }`}>
                {selectedNCR.disposition}
              </p>
            </div>

            {selectedNCR.linkedCapa && (
              <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
                <p className="text-xs text-blue-600 uppercase tracking-wider mb-1">Linked CAPA</p>
                <p className="font-medium text-blue-700">{selectedNCR.linkedCapa}</p>
              </div>
            )}

            <div className="flex items-center gap-3 pt-4 border-t">
              <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                Update NCR
              </button>
              <button className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                Set Disposition
              </button>
              <button 
                onClick={() => setShowCreateCAPAModal(true)}
                className="flex-1 px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors"
              >
                Create CAPA
              </button>
            </div>

            {/* Action Buttons for Creating Related Items - ISO 13485 Workflow */}
            {selectedNCR.status === 'Closed' && !selectedNCR.linkedCapa && (
              <div className="bg-amber-50 rounded-lg p-4 border border-amber-200">
                <h4 className="text-sm font-semibold text-amber-900 mb-3 flex items-center gap-2">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                  Follow-up Actions (ISO 13485:8.5)
                </h4>
                <p className="text-xs text-amber-700 mb-3">
                  This NCR is closed. If root cause analysis indicates systemic issues, create a CAPA to prevent recurrence.
                </p>
                <button 
                  onClick={() => setShowCreateCAPAModal(true)}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                  </svg>
                  Create CAPA from NCR
                </button>
              </div>
            )}

            {/* Traceability Section */}
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="text-sm font-semibold text-gray-900 mb-3 flex items-center gap-2">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                </svg>
                Traceability - Linked Items
              </h4>
              <div className="space-y-2">
                {selectedNCR.linkedCapa ? (
                  <div className="flex items-center justify-between p-2 bg-white rounded border">
                    <div>
                      <span className="font-medium text-amber-600">{selectedNCR.linkedCapa}</span>
                      <p className="text-xs text-gray-500">Linked CAPA</p>
                    </div>
                    <StatusBadge status="Open" />
                  </div>
                ) : (
                  <p className="text-gray-400 italic text-sm">No linked CAPA</p>
                )}
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* Create CAPA Modal - Linked to NCR */}
      <CreateCAPAModal
        isOpen={showCreateCAPAModal}
        onClose={() => setShowCreateCAPAModal(false)}
        sourceNCRId={selectedNCR?.id}
        sourceNCRNumber={selectedNCR?.ncrNumber}
        onSuccess={() => refetch()}
      />

      {/* New NCR Modal */}
      <Modal
        isOpen={showNewNCRModal}
        onClose={() => setShowNewNCRModal(false)}
        title="Create New Non-Conformance Report"
        size="xl"
      >
        <form className="space-y-6" onSubmit={handleCreateNCR}>
          {/* ISO 13485 Section 8.3 Compliance Notice */}
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
            <h4 className="font-medium text-amber-900 mb-2">ISO 13485:2016 Section 8.3 Compliant</h4>
            <p className="text-sm text-amber-700">Non-conformances must be documented, investigated, and root cause analysis performed to determine corrective action.</p>
          </div>

          {/* NCR Identification */}
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-3 pb-2 border-b">NCR Identification</h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  NCR Type <span className="text-red-500">*</span>
                </label>
                <select
                  value={newNCRData.type}
                  onChange={(e) => setNewNCRData({...newNCRData, type: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                  required
                >
                  <option value="Product">Product</option>
                  <option value="Process">Process</option>
                  <option value="System">System</option>
                  <option value="Supplier">Supplier</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Severity <span className="text-red-500">*</span>
                </label>
                <select
                  value={newNCRData.severity}
                  onChange={(e) => setNewNCRData({...newNCRData, severity: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                  required
                >
                  <option value="Critical">Critical - Regulatory/Safety</option>
                  <option value="Major">Major - Major Quality Impact</option>
                  <option value="Minor">Minor - Minor Quality Impact</option>
                </select>
              </div>
            </div>
          </div>

          {/* Source & Detection - ISO 13485:8.3 */}
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-3 pb-2 border-b">Source & Detection (ISO 13485:8.3)</h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Source <span className="text-red-500">*</span>
                </label>
                <select
                  value={newNCRData.source}
                  onChange={(e) => setNewNCRData({...newNCRData, source: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                  required
                >
                  <option value="Incoming Inspection">Incoming Inspection</option>
                  <option value="In-Process Inspection">In-Process Inspection</option>
                  <option value="Final Inspection">Final Inspection</option>
                  <option value="Customer Complaint">Customer Complaint</option>
                  <option value="Internal Audit">Internal Audit</option>
                  <option value="Process Monitoring">Process Monitoring</option>
                  <option value="Supplier">Supplier</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Detected Date <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  value={newNCRData.detectedDate}
                  onChange={(e) => setNewNCRData({...newNCRData, detectedDate: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                  required
                />
              </div>
            </div>
            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Source Description</label>
              <input
                type="text"
                value={newNCRData.sourceDescription}
                onChange={(e) => setNewNCRData({...newNCRData, sourceDescription: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                placeholder="Additional details about the source"
              />
            </div>
          </div>

          {/* Product Information */}
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-3 pb-2 border-b">Product Information</h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Product Name</label>
                <input
                  type="text"
                  value={newNCRData.productName}
                  onChange={(e) => setNewNCRData({...newNCRData, productName: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                  placeholder="Name of affected product"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Part Number</label>
                <input
                  type="text"
                  value={newNCRData.partNumber}
                  onChange={(e) => setNewNCRData({...newNCRData, partNumber: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                  placeholder="Part/Article number"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Lot/Batch Number</label>
                <input
                  type="text"
                  value={newNCRData.lotNumber}
                  onChange={(e) => setNewNCRData({...newNCRData, lotNumber: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                  placeholder="e.g., LOT-2025-0150"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Quantity Affected</label>
                <input
                  type="number"
                  value={newNCRData.quantityAffected}
                  onChange={(e) => setNewNCRData({...newNCRData, quantityAffected: parseInt(e.target.value) || 0})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                  placeholder="Number of affected units"
                />
              </div>
            </div>
          </div>

          {/* NCR Details */}
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-3 pb-2 border-b">NCR Details</h4>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Title <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={newNCRData.title}
                  onChange={(e) => setNewNCRData({...newNCRData, title: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                  placeholder="Brief description of non-conformance"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description <span className="text-red-500">*</span>
                </label>
                <textarea
                  rows={4}
                  value={newNCRData.description}
                  onChange={(e) => setNewNCRData({...newNCRData, description: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                  placeholder="Detailed description of the non-conformance - what happened, when, where, how it was discovered"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Immediate Action (Containment)</label>
                <textarea
                  rows={3}
                  value={newNCRData.immediateAction}
                  onChange={(e) => setNewNCRData({...newNCRData, immediateAction: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                  placeholder="Immediate actions taken to contain the non-conformance (quarantine, rework, etc.)"
                />
              </div>
            </div>
          </div>

          {/* Assignment */}
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-3 pb-2 border-b">Assignment & Due Date</h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Assigned To</label>
                <select
                  value={newNCRData.assignedTo}
                  onChange={(e) => setNewNCRData({...newNCRData, assignedTo: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                >
                  <option value="">Select Person</option>
                  <option value="Sarah Chen">Sarah Chen</option>
                  <option value="Michael Torres">Michael Torres</option>
                  <option value="James Wilson">James Wilson</option>
                  <option value="Emily Rodriguez">Emily Rodriguez</option>
                  <option value="David Martinez">David Martinez</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Response Due Date</label>
                <input
                  type="date"
                  value={newNCRData.dueDate}
                  onChange={(e) => setNewNCRData({...newNCRData, dueDate: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 pt-4 border-t">
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors disabled:opacity-50"
            >
              {isSubmitting ? 'Creating...' : 'Create NCR'}
            </button>
            <button
              type="button"
              onClick={() => setShowNewNCRModal(false)}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default NonConformance;
