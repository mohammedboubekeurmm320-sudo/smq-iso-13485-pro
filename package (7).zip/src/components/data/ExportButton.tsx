import React, { useState } from 'react';
import { Download, FileText, Table, FileJson, Loader2 } from 'lucide-react';

interface ExportButtonProps {
  data: any[];
  filename: string;
  label?: string;
}

const ExportButton: React.FC<ExportButtonProps> = ({ data, filename, label = 'Export' }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [format, setFormat] = useState<'csv' | 'json' | 'xlsx'>('csv');

  const exportFormats = [
    { id: 'csv', name: 'CSV', icon: Table, description: 'Comma-separated values' },
    { id: 'json', name: 'JSON', icon: FileJson, description: 'JavaScript Object Notation' },
  ];

  const handleExport = async () => {
    setIsExporting(true);

    try {
      let content: string;
      let mimeType: string;
      let extension: string;

      if (format === 'csv') {
        if (data.length === 0) {
          alert('No data to export');
          return;
        }
        
        const headers = Object.keys(data[0]);
        const csvRows = [
          headers.join(','),
          ...data.map(row => 
            headers.map(header => {
              const value = row[header];
              // Escape quotes and wrap in quotes if contains comma
              if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
                return `"${value.replace(/"/g, '""')}"`;
              }
              return value ?? '';
            }).join(',')
          )
        ];
        content = csvRows.join('\n');
        mimeType = 'text/csv';
        extension = 'csv';
      } else if (format === 'json') {
        content = JSON.stringify(data, null, 2);
        mimeType = 'application/json';
        extension = 'json';
      } else {
        // For xlsx, we'd need a library like xlsx
        // For now, fall back to CSV
        const headers = Object.keys(data[0]);
        const csvRows = [
          headers.join(','),
          ...data.map(row => headers.map(h => row[h] ?? '').join(','))
        ];
        content = csvRows.join('\n');
        mimeType = 'text/csv';
        extension = 'csv';
      }

      // Create and download file
      const blob = new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${filename}.${extension}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setIsOpen(false);
    } catch (err) {
      console.error('Export failed:', err);
      alert('Export failed. Please try again.');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
      >
        <Download className="w-4 h-4 text-gray-600" />
        <span className="text-sm font-medium text-gray-700">{label}</span>
      </button>

      {isOpen && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setIsOpen(false)} />
          <div className="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-lg border border-gray-200 z-20 overflow-hidden">
            <div className="p-3 border-b border-gray-100">
              <p className="text-sm font-medium text-gray-900">Export Format</p>
              <p className="text-xs text-gray-500">{data.length} rows selected</p>
            </div>
            
            <div className="p-2">
              {exportFormats.map((f) => (
                <button
                  key={f.id}
                  onClick={() => setFormat(f.id as 'csv' | 'json')}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                    format === f.id
                      ? 'bg-blue-50 text-blue-700'
                      : 'hover:bg-gray-50 text-gray-700'
                  }`}
                >
                  <f.icon className="w-4 h-4" />
                  <div className="flex-1 text-left">
                    <p className="text-sm font-medium">{f.name}</p>
                    <p className="text-xs text-gray-500">{f.description}</p>
                  </div>
                  {format === f.id && (
                    <div className="w-2 h-2 bg-blue-500 rounded-full" />
                  )}
                </button>
              ))}
            </div>

            <div className="p-3 border-t border-gray-100 bg-gray-50">
              <button
                onClick={handleExport}
                disabled={isExporting || data.length === 0}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isExporting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Exporting...
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4" />
                    Download {format.toUpperCase()}
                  </>
                )}
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default ExportButton;
