/**
 * PDF Generator Hook
 * Easy-to-use hook for generating PDFs from any component
 */

import { useState, useCallback } from 'react';
import { PDFConfig, defaultPDFConfig, ReportType, generateDocumentId, getReportTypePrefix } from '../utils/pdfUtils';

interface UsePDFGeneratorOptions {
  reportType: ReportType;
  title: string;
  data: any;
  tableData?: Record<string, any>[];
  tableColumns?: { key: string; label: string; width?: number }[];
  notes?: string;
  signatures?: { name: string; role: string; date: string }[];
}

interface UsePDFGeneratorReturn {
  isOpen: boolean;
  config: PDFConfig;
  openPreview: (overrides?: Partial<UsePDFGeneratorOptions>) => void;
  closePreview: () => void;
  updateConfig: (updates: Partial<PDFConfig>) => void;
  options: UsePDFGeneratorOptions;
}

export const usePDFGenerator = (initialOptions: UsePDFGeneratorOptions): UsePDFGeneratorReturn => {
  const [isOpen, setIsOpen] = useState(false);
  const [config, setConfig] = useState<PDFConfig>(() => ({
    ...defaultPDFConfig,
    documentId: generateDocumentId(getReportTypePrefix(initialOptions.reportType)),
    documentTitle: initialOptions.title,
  }));
  const [options, setOptions] = useState<UsePDFGeneratorOptions>(initialOptions);

  const openPreview = useCallback((overrides?: Partial<UsePDFGeneratorOptions>) => {
    if (overrides) {
      setOptions(prev => ({ ...prev, ...overrides }));
      if (overrides.reportType) {
        setConfig(prev => ({
          ...prev,
          documentId: generateDocumentId(getReportTypePrefix(overrides.reportType!)),
        }));
      }
    }
    setIsOpen(true);
  }, []);

  const closePreview = useCallback(() => {
    setIsOpen(false);
  }, []);

  const updateConfig = useCallback((updates: Partial<PDFConfig>) => {
    setConfig(prev => ({ ...prev, ...updates }));
  }, []);

  return {
    isOpen,
    config,
    openPreview,
    closePreview,
    updateConfig,
    options,
  };
};

// Example usage:
// const { isOpen, config, openPreview, closePreview, updateConfig, options } = usePDFGenerator({
//   reportType: 'CAPA',
//   title: 'Rapport CAPA',
//   data: capaData,
// });

export default usePDFGenerator;
