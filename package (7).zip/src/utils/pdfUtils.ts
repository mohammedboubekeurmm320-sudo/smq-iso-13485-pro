/**
 * PDF Generation Utilities
 * Provides helper functions for PDF generation and configuration
 */

// PDF Page sizes (in points, 1pt = 0.3528mm)
export const PageSizes = {
  A4: [595.28, 841.89],
  Letter: [612, 792],
  Legal: [612, 1008],
};

// PDF Configuration Types
export interface PDFConfig {
  // Header configuration
  showHeader: boolean;
  headerTitle: string;
  headerSubtitle: string;
  headerLogo: string | null;
  
  // Footer configuration
  showFooter: boolean;
  showPageNumbers: boolean;
  showDate: boolean;
  showCompanyName: string;
  
  // Document metadata
  documentTitle: string;
  documentId: string;
  revision: string;
  author: string;
  
  // Page settings
  pageSize: 'A4' | 'LETTER' | 'LEGAL';
  orientation: 'portrait' | 'landscape';
  margin: number;
  
  // Colors
  primaryColor: string;
  accentColor: string;
}

// Default configuration
export const defaultPDFConfig: PDFConfig = {
  showHeader: true,
  headerTitle: 'Quality Management System',
  headerSubtitle: 'ISO 13485:2016',
  headerLogo: null,
  
  showFooter: true,
  showPageNumbers: true,
  showDate: true,
  showCompanyName: 'QMS System',
  
  documentTitle: 'Rapport QMS',
  documentId: 'QMS-REP-001',
  revision: 'A',
  author: 'QMS System',
  
  pageSize: 'A4',
  orientation: 'portrait',
  margin: 20,
  
  primaryColor: '#1e40af', // blue-800
  accentColor: '#059669',  // emerald-600
};

// Get page dimensions based on size and orientation
export const getPageDimensions = (config: PDFConfig) => {
  const baseSize = config.pageSize === 'A4' 
    ? PageSizes.A4 
    : config.pageSize === 'LETTER' 
      ? PageSizes.Letter 
      : PageSizes.Legal;
      
  return config.orientation === 'landscape' 
    ? [baseSize[1], baseSize[0]] 
    : baseSize;
};

// Format date for PDF
export const formatPDFDate = (date: Date | string): string => {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleDateString('fr-FR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
};

// Generate document ID
export const generateDocumentId = (prefix: string): string => {
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
  return `${prefix}-${year}${month}-${random}`;
};

// Report types supported
export type ReportType = 'CAPA' | 'NCR' | 'AUDIT' | 'TRAINING' | 'DOCUMENT' | 'RISK' | 'GENERIC';

// Report type labels
export const reportTypeLabels: Record<ReportType, string> = {
  CAPA: 'Action corrective / preventive',
  NCR: 'Non-conformité',
  AUDIT: 'Audit',
  TRAINING: 'Formation',
  DOCUMENT: 'Document',
  RISK: 'Risque',
  GENERIC: 'Rapport général',
};

// Get report type prefix for document ID
export const getReportTypePrefix = (type: ReportType): string => {
  const prefixes: Record<ReportType, string> = {
    CAPA: 'CAPA',
    NCR: 'NCR',
    AUDIT: 'AUD',
    TRAINING: 'TRG',
    DOCUMENT: 'DOC',
    RISK: 'RSK',
    GENERIC: 'RPT',
  };
  return prefixes[type];
};

// Color utilities for PDF
export const hexToRGB = (hex: string): [number, number, number] => {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  if (!result) return [0, 0, 0];
  return [
    parseInt(result[1], 16) / 255,
    parseInt(result[2], 16) / 255,
    parseInt(result[3], 16) / 255,
  ];
};

// Status colors for different report types
export const getStatusColor = (status: string): string => {
  const statusColors: Record<string, string> = {
    // General statuses
    'Open': '#dc2626',
    'Closed': '#16a34a',
    'In Progress': '#2563eb',
    'Pending': '#d97706',
    'Cancelled': '#6b7280',
    
    // CAPA specific
    'Investigation': '#7c3aed',
    'Implementation': '#0891b2',
    'Verification': '#059669',
    
    // NCR specific
    'Under Investigation': '#7c3aed',
    'Pending Disposition': '#d97706',
    
    // Training specific
    'Completed': '#16a34a',
    'Scheduled': '#2563eb',
    'Overdue': '#dc2626',
    
    // Document specific
    'Draft': '#6b7280',
    'In Review': '#d97706',
    'Approved': '#16a34a',
    'Obsolete': '#dc2626',
  };
  
  return statusColors[status] || '#6b7280';
};
