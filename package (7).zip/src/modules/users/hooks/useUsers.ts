// React Query Hooks pour les Utilisateurs
// Gestion du state et des side-effects pour les utilisateurs

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { userService, UserFilters, User } from '../services/userService';
import { QMSError } from '@/lib/error/QMSError';
import { toast } from 'sonner';

// Clés de cache pour React Query
export const userKeys = {
  all: ['users'] as const,
  lists: () => [...userKeys.all, 'list'] as const,
  list: (filters: UserFilters) => [...userKeys.lists(), filters] as const,
  details: () => [...userKeys.all, 'detail'] as const,
  detail: (id: string) => [...userKeys.details(), id] as const,
  stats: () => [...userKeys.all, 'stats'] as const,
};

// Hook pour récupérer la liste des utilisateurs
export const useUsers = (organizationId: string, filters?: UserFilters) => {
  return useQuery({
    queryKey: userKeys.list(filters || {}),
    queryFn: () => userService.getUsers(organizationId, filters),
    enabled: !!organizationId,
    staleTime: 5 * 60 * 1000, // 5 minutes
    retry: 3,
  });
};

// Hook pour récupérer un utilisateur par ID
export const useUser = (userId: string) => {
  return useQuery({
    queryKey: userKeys.detail(userId),
    queryFn: () => userService.getUserById(userId),
    enabled: !!userId,
    staleTime: 5 * 60 * 1000,
  });
};

// Hook pour les statistiques des utilisateurs
export const useUserStats = (organizationId: string) => {
  return useQuery({
    queryKey: userKeys.stats(),
    queryFn: () => userService.getUserStats(organizationId),
    enabled: !!organizationId,
    staleTime: 60 * 1000, // 1 minute
  });
};

// Hook pour créer un utilisateur
export const useCreateUser = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      organizationId,
      userData,
    }: {
      organizationId: string;
      userData: Partial<User>;
    }) => userService.createUser(organizationId, userData),

    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: userKeys.all });
      queryClient.invalidateQueries({ queryKey: userKeys.stats() });
      
      toast.success('User created successfully', {
        description: `User ${data.full_name} has been created.`,
      });
    },

    onError: (error: Error) => {
      const qmsError = error as QMSError;
      toast.error(qmsError.userMessage || 'Failed to create user');
    },
  });
};

// Hook pour mettre à jour un utilisateur
export const useUpdateUser = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      userId,
      userData,
    }: {
      userId: string;
      userData: Partial<User>;
    }) => userService.updateUser(userId, userData),

    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: userKeys.all });
      queryClient.invalidateQueries({ queryKey: userKeys.detail(variables.userId) });
      queryClient.invalidateQueries({ queryKey: userKeys.stats() });
      
      toast.success('User updated successfully', {
        description: `User ${data.full_name} has been updated.`,
      });
    },

    onError: (error: Error) => {
      const qmsError = error as QMSError;
      toast.error(qmsError.userMessage || 'Failed to update user');
    },
  });
};

// Hook pour supprimer un utilisateur
export const useDeleteUser = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ userId }: { userId: string }) => userService.deleteUser(userId),

    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: userKeys.all });
      queryClient.invalidateQueries({ queryKey: userKeys.stats() });
      
      toast.success('User deleted successfully', {
        description: 'User has been removed from the organization.',
      });
    },

    onError: (error: Error) => {
      const qmsError = error as QMSError;
      toast.error(qmsError.userMessage || 'Failed to delete user');
    },
  });
};

export default {
  useUsers,
  useUser,
  useUserStats,
  useCreateUser,
  useUpdateUser,
  useDeleteUser,
};
