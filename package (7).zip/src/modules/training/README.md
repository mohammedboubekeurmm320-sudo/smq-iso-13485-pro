# Training Module

## Overview

This module handles training records per ISO 13485 Section 7.2 and 7.3 requirements for personnel competency.

## Services

### trainingService.ts

Main service for training management.

#### Methods

- `getAll(filters?)` - Retrieve all training records
- `getById(id)` - Get a single training record
- `create(input, userId)` - Create a new training record
- `update(id, input, userId)` - Update training record
- `getStats()` - Get training statistics
- `getExpiringTrainings(days)` - Get trainings expiring soon

## Hooks

### useTrainings

React Query hook for training list management.

```typescript
const { data } = useTrainings({ status: 'Pending' });
```

## Types

```typescript
interface TrainingRecord {
  id: string;
  employeeName: string;
  employeeId?: string;
  department: string;
  trainingTitle: string;
  trainingType: 'Initial' | 'Refresher' | 'Certification' | 'On-the-job';
  status: 'Pending' | 'In Progress' | 'Completed' | 'Expired';
  completionDate?: string;
  dueDate: string;
  trainer?: string;
  certificateUrl?: string;
}
```

## Compliance

- ISO 13485:2016 Section 7.2 - Competence
- ISO 13485:2016 Section 7.3 - Awareness
