// React Query Hooks pour les Formations

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { trainingService, TrainingFilters, CreateTrainingInput } from '../services/trainingService';
import { QMSError } from '@/lib/error/QMSError';
import { toast } from 'sonner';

export const trainingKeys = {
  all: ['training'] as const,
  lists: () => [...trainingKeys.all, 'list'] as const,
  list: (filters: TrainingFilters) => [...trainingKeys.lists(), filters] as const,
  details: () => [...trainingKeys.all, 'detail'] as const,
  detail: (id: string) => [...trainingKeys.details(), id] as const,
  stats: () => [...trainingKeys.all, 'stats'] as const,
  expiring: (days: number) => [...trainingKeys.all, 'expiring', days] as const,
};

export const useTrainings = (filters?: TrainingFilters) => {
  return useQuery({
    queryKey: trainingKeys.list(filters || {}),
    queryFn: () => trainingService.getAll(filters),
    staleTime: 5 * 60 * 1000,
  });
};

export const useTraining = (id: string) => {
  return useQuery({
    queryKey: trainingKeys.detail(id),
    queryFn: () => trainingService.getById(id),
    enabled: !!id,
    staleTime: 5 * 60 * 1000,
  });
};

export const useTrainingStats = () => {
  return useQuery({
    queryKey: trainingKeys.stats(),
    queryFn: () => trainingService.getStats(),
    staleTime: 60 * 1000,
  });
};

export const useExpiringTrainings = (days: number = 30) => {
  return useQuery({
    queryKey: trainingKeys.expiring(days),
    queryFn: () => trainingService.getExpiringTrainings(days),
    staleTime: 60 * 1000,
  });
};

export const useCreateTraining = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      input,
      userId,
    }: {
      input: CreateTrainingInput;
      userId: string;
    }) => trainingService.create(input, userId),

    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: trainingKeys.all });
      toast.success('Training record created successfully');
    },

    onError: (error: Error) => {
      const qmsError = error as QMSError;
      toast.error(qmsError.userMessage || 'Failed to create training');
    },
  });
};

export const useCompleteTraining = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      id,
      certificateUrl,
      userId,
    }: {
      id: string;
      certificateUrl: string;
      userId: string;
    }) => trainingService.complete(id, certificateUrl, userId),

    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: trainingKeys.all });
      toast.success('Training completed successfully');
    },

    onError: (error: Error) => {
      const qmsError = error as QMSError;
      toast.error(qmsError.userMessage || 'Failed to complete training');
    },
  });
};

export default {
  useTrainings,
  useTraining,
  useTrainingStats,
  useExpiringTrainings,
  useCreateTraining,
  useCompleteTraining,
};
