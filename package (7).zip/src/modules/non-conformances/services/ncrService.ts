// Non-Conformance Service - Service pour les non-conformités
// Conforme ISO 13485 Section 8.3

import { supabase } from '@/lib/supabase';
import { NonConformance } from '@/types/qms';
import { QMSError, handleSupabaseError, NetworkError } from '@/lib/error/QMSError';
import { auditApi } from '../../documents/services/auditService';

// Demo store for offline mode
const demoNCRs: NonConformance[] = [
  {
    id: 'demo-ncr-1',
    ncrNumber: 'NCR-2024-0001',
    title: 'Non-conformité dimensionnelle',
    type: 'Product',
    status: 'Open',
    severity: 'Major',
    source: 'Inspection',
    sourceDescription: 'Contrôle qualité lors de la production',
    detectedDate: '2024-01-20',
    detectedBy: 'Jean Dupont',
    lotNumber: 'LOT-2024-0156',
    quantityAffected: 50,
    totalQuantity: 500,
    productName: 'Implant orthopédique',
    partNumber: 'IMP-001',
    description: 'Écart dimensionnel détecté sur le diamètre externe des implants',
    immediateAction: 'Quarantaine des pièces concernées',
    containmentEffective: true,
    disposition: 'Pending',
    assignedTo: 'Responsable Qualité',
    createdDate: '2024-01-20',
    dueDate: '2024-02-20',
    created_by: 'demo-user-1',
    created_at: '2024-01-20T10:00:00Z',
    updated_at: '2024-01-20T10:00:00Z',
  },
  {
    id: 'demo-ncr-2',
    ncrNumber: 'NCR-2024-0002',
    title: 'Procédure non suivie',
    type: 'Process',
    status: 'In Progress',
    severity: 'Minor',
    source: 'Internal Audit',
    sourceDescription: 'Audit interne processus de stérilisation',
    detectedDate: '2024-02-01',
    detectedBy: 'Sophie Bernard',
    description: 'Procédure de stérilisation non respectée - température inférieure au seuil',
    immediateAction: 'Arrêt immédiat du process',
    containmentEffective: true,
    rootCauseAnalysis: 'Formation insuffisante de l\'opérateur',
    disposition: 'Use As Is',
    dispositionJustification: 'Impact minimal sur le produit',
    assignedTo: 'Responsable Production',
    createdDate: '2024-02-01',
    dueDate: '2024-03-01',
    created_by: 'demo-user-2',
    created_at: '2024-02-01T10:00:00Z',
    updated_at: '2024-02-10T10:00:00Z',
  },
  {
    id: 'demo-ncr-3',
    ncrNumber: 'NCR-2024-0003',
    title: 'Équipement défectueux',
    type: 'Equipment',
    status: 'Closed',
    severity: 'Critical',
    source: 'Maintenance',
    sourceDescription: 'Vérification préventive',
    detectedDate: '2024-01-10',
    detectedBy: 'Pierre Martin',
    productName: 'Machine de soudage',
    description: 'Défaut détecté sur l\'étalonnage de la machine de soudage laser',
    immediateAction: 'Mise hors service immédiate',
    containmentEffective: true,
    rootCauseAnalysis: 'Usure naturelle des composants',
    disposition: 'Rework',
    dispositionJustification: 'Réétalonnage réalisé avec succès',
    dispositionApprovedBy: 'Responsable Qualité',
    dispositionDate: '2024-01-25',
    effectivenessVerification: 'Vérification complète réalisée - equipment conforme',
    verificationDate: '2024-02-01',
    verifiedBy: 'Jean Dupont',
    assignedTo: 'Responsable Maintenance',
    createdDate: '2024-01-10',
    closedDate: '2024-02-01',
    created_by: 'demo-user-1',
    created_at: '2024-01-10T10:00:00Z',
    updated_at: '2024-02-01T10:00:00Z',
  },
];

export interface NCRFilters {
  status?: string;
  severity?: string;
  type?: string;
  search?: string;
}

// Interface for database response (snake_case)
interface NCRDatabase {
  id: string;
  ncr_number: string;
  title: string;
  type: string;
  status: string;
  severity: string;
  source: string;
  source_description?: string;
  detected_date: string;
  detected_by?: string;
  lot_number?: string;
  quantity_affected?: number;
  total_quantity?: number;
  product_name?: string;
  part_number?: string;
  description: string;
  immediate_action?: string;
  containment_effective?: boolean;
  root_cause_analysis?: string;
  five_whys?: string[];
  fishbone_diagram?: Record<string, string>;
  disposition: string;
  disposition_justification?: string;
  disposition_approved_by?: string;
  disposition_date?: string;
  effectiveness_verification?: string;
  verification_date?: string;
  verified_by?: string;
  linked_capa?: string;
  linked_audit_id?: string;
  linked_deviation_id?: string;
  assigned_to: string;
  created_date: string;
  closed_date?: string;
  due_date?: string;
  created_by?: string;
  created_at?: string;
  updated_at?: string;
}

// Mapper la réponse de la base de données vers le type TypeScript
const mapDatabaseToNCR = (dbNCR: NCRDatabase): NonConformance => ({
  id: dbNCR.id,
  ncrNumber: dbNCR.ncr_number,
  title: dbNCR.title,
  type: dbNCR.type as NonConformance['type'],
  status: dbNCR.status as NonConformance['status'],
  severity: dbNCR.severity as NonConformance['severity'],
  source: dbNCR.source as NonConformance['source'],
  sourceDescription: dbNCR.source_description,
  detectedDate: dbNCR.detected_date,
  detectedBy: dbNCR.detected_by,
  lotNumber: dbNCR.lot_number,
  quantityAffected: dbNCR.quantity_affected,
  totalQuantity: dbNCR.total_quantity,
  productName: dbNCR.product_name,
  partNumber: dbNCR.part_number,
  description: dbNCR.description,
  immediateAction: dbNCR.immediate_action,
  containmentEffective: dbNCR.containment_effective,
  rootCauseAnalysis: dbNCR.root_cause_analysis,
  fiveWhys: dbNCR.five_whys,
  fishboneDiagram: dbNCR.fishbone_diagram,
  disposition: dbNCR.disposition as NonConformance['disposition'],
  dispositionJustification: dbNCR.disposition_justification,
  dispositionApprovedBy: dbNCR.disposition_approved_by,
  dispositionDate: dbNCR.disposition_date,
  effectivenessVerification: dbNCR.effectiveness_verification,
  verificationDate: dbNCR.verification_date,
  verifiedBy: dbNCR.verified_by,
  linkedCapa: dbNCR.linked_capa,
  linkedAuditId: dbNCR.linked_audit_id,
  linkedDeviationId: dbNCR.linked_deviation_id,
  assignedTo: dbNCR.assigned_to,
  createdDate: dbNCR.created_date,
  closedDate: dbNCR.closed_date,
  dueDate: dbNCR.due_date,
  created_by: dbNCR.created_by,
  created_at: dbNCR.created_at,
  updated_at: dbNCR.updated_at,
});

export interface CreateNCRInput {
  title: string;
  description: string;
  type?: string;
  severity?: string;
  source?: string;
  sourceDescription?: string;
  detectedDate?: string;
  detectedBy?: string;
  lotNumber?: string;
  quantityAffected?: number;
  totalQuantity?: number;
  productName?: string;
  partNumber?: string;
  immediateAction?: string;
  assignedTo?: string;
  department?: string;
  dueDate?: string;
}

export interface UpdateNCRInput {
  title?: string;
  description?: string;
  status?: string;
  severity?: string;
  rootCauseAnalysis?: string;
  disposition?: string;
  dispositionJustification?: string;
  linkedCapa?: string;
  assignedTo?: string;
  immediateAction?: string;
  effectivenessVerification?: string;
}

export const ncrService = {
  async getAll(filters?: NCRFilters): Promise<NonConformance[]> {
    try {
      let query = supabase
        .from('non_conformances')
        .select('*')
        .order('created_at', { ascending: false });

      if (filters?.status && filters.status !== 'all') {
        query = query.eq('status', filters.status);
      }
      if (filters?.severity && filters.severity !== 'all') {
        query = query.eq('severity', filters.severity);
      }
      if (filters?.type && filters.type !== 'all') {
        query = query.eq('type', filters.type);
      }
      if (filters?.search) {
        query = query.or(`title.ilike.%${filters.search}%,ncr_number.ilike.%${filters.search}%`);
      }

      const { data, error } = await query;

      if (error) throw handleSupabaseError(error, 'fetch non conformances');

      return (data || []).map(mapDatabaseToNCR);
    } catch (error) {
      // Fallback to demo data in offline mode
      console.log('Using demo NCR data');
      let filtered = [...demoNCRs];
      if (filters?.status && filters.status !== 'all') {
        filtered = filtered.filter(n => n.status === filters.status);
      }
      if (filters?.severity && filters.severity !== 'all') {
        filtered = filtered.filter(n => n.severity === filters.severity);
      }
      if (filters?.type && filters.type !== 'all') {
        filtered = filtered.filter(n => n.type === filters.type);
      }
      if (filters?.search) {
        const search = filters.search.toLowerCase();
        filtered = filtered.filter(n => 
          n.title.toLowerCase().includes(search) || 
          n.ncrNumber.toLowerCase().includes(search)
        );
      }
      return filtered.sort((a, b) => new Date(b.created_at || '').getTime() - new Date(a.created_at || '').getTime());
    }
  },

  async getById(id: string): Promise<NonConformance | null> {
    try {
      const { data, error } = await supabase
        .from('non_conformances')
        .select('*')
        .eq('id', id)
        .single();

      if (error) {
        if (error.code === 'PGRST116') return null;
        throw handleSupabaseError(error, 'fetch non conformance');
      }

      return data ? mapDatabaseToNCR(data) : null;
    } catch (error) {
      // Fallback to demo data in offline mode
      console.log('Using demo NCR');
      return demoNCRs.find(n => n.id === id) || null;
    }
  },

  async create(input: CreateNCRInput, userId: string): Promise<NonConformance> {
    try {
      const ncrNumber = await generateNCRNumber();

      const { data, error } = await supabase
        .from('non_conformances')
        .insert({
          ncr_number: ncrNumber,
          title: input.title,
          description: input.description,
          type: input.type || 'Product',
          severity: input.severity || 'Minor',
          source: input.source || 'Other',
          source_description: input.sourceDescription,
          detected_date: input.detectedDate || new Date().toISOString().split('T')[0],
          detected_by: input.detectedBy,
          lot_number: input.lotNumber,
          quantity_affected: input.quantityAffected,
          total_quantity: input.totalQuantity,
          product_name: input.productName,
          part_number: input.partNumber,
          immediate_action: input.immediateAction,
          assigned_to: input.assignedTo || 'Unassigned',
          due_date: input.dueDate,
          status: 'Open',
          disposition: 'Pending',
          created_by: userId,
          created_date: new Date().toISOString(),
        })
        .select()
        .single();

      if (error) throw handleSupabaseError(error, 'create non conformance');

      await auditApi.logAudit({
        action: 'CREATE',
        tableName: 'non_conformances',
        recordId: data.id,
        userId,
        newValues: data,
      });

      return mapDatabaseToNCR(data);
    } catch (error) {
      if (error instanceof QMSError) throw error;
      throw new NetworkError('Failed to create non-conformance', { originalError: error as Error });
    }
  },

  async update(id: string, input: UpdateNCRInput, userId: string): Promise<NonConformance> {
    try {
      const oldNCR = await this.getById(id);

      const { data, error } = await supabase
        .from('non_conformances')
        .update({
          ...input,
          updated_at: new Date().toISOString(),
        })
        .eq('id', id)
        .select()
        .single();

      if (error) throw handleSupabaseError(error, 'update non conformance');

      await auditApi.logAudit({
        action: 'UPDATE',
        tableName: 'non_conformances',
        recordId: id,
        userId,
        oldValues: oldNCR,
        newValues: data,
      });

      return data;
    } catch (error) {
      if (error instanceof QMSError) throw error;
      throw new NetworkError('Failed to update non-conformance', { originalError: error as Error });
    }
  },

  async close(id: string, userId: string): Promise<NonConformance> {
    return this.update(id, {
      status: 'Closed',
    }, userId);
  },

  async getStats(): Promise<{
    total: number;
    open: number;
    inProgress: number;
    closed: number;
    critical: number;
  }> {
    try {
      const { data, error } = await supabase
        .from('non_conformances')
        .select('status, severity');

      if (error) throw handleSupabaseError(error, 'fetch ncr stats');

      const ncrs = data || [];
      return {
        total: ncrs.length,
        open: ncrs.filter(n => n.status === 'Open').length,
        inProgress: ncrs.filter(n => n.status === 'In Progress').length,
        closed: ncrs.filter(n => n.status === 'Closed').length,
        critical: ncrs.filter(n => n.severity === 'Critical').length,
      };
    } catch (error) {
      // Fallback to demo data in offline mode
      console.log('Using demo NCR stats');
      return {
        total: demoNCRs.length,
        open: demoNCRs.filter(n => n.status === 'Open').length,
        inProgress: demoNCRs.filter(n => n.status === 'In Progress').length,
        closed: demoNCRs.filter(n => n.status === 'Closed').length,
        critical: demoNCRs.filter(n => n.severity === 'Critical').length,
      };
    }
  },
};

async function generateNCRNumber(): Promise<string> {
  const year = new Date().getFullYear();
  const { count } = await supabase
    .from('non_conformances')
    .select('*', { count: 'exact', head: true });

  const num = (count || 0) + 1;
  return `NCR-${year}-${num.toString().padStart(4, '0')}`;
}

export default ncrService;
