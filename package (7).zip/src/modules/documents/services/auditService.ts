// Audit Service - Service pour la traçabilité ISO 13485
// Conforme aux exigences d'audit trail immuable

import { supabase } from '@/lib/supabase';
import { QMSError, handleSupabaseError, NetworkError } from '@/lib/error/QMSError';

export interface AuditLogEntry {
  id?: string;
  action: string;
  tableName: string;
  recordId: string;
  oldValues?: Record<string, any>;
  newValues?: Record<string, any>;
  userId?: string;
  userEmail?: string;
  ipAddress?: string;
  timestamp?: string;
}

export interface AuditFilters {
  tableName?: string;
  recordId?: string;
  userId?: string;
  action?: string;
  startDate?: string;
  endDate?: string;
}

// Service d'audit trail
export const auditApi = {
  // Logger une action dans l'audit trail
  async logAudit(entry: AuditLogEntry): Promise<void> {
    try {
      const { error } = await supabase.from('audit_trail').insert({
        action: entry.action,
        table_name: entry.tableName,
        record_id: entry.recordId,
        old_values: entry.oldValues,
        new_values: entry.newValues,
        user_id: entry.userId,
        user_email: entry.userEmail,
        ip_address: entry.ipAddress || 'client',
        timestamp: new Date().toISOString(),
      });

      if (error) {
        // Ne pas bloquer l'application si l'audit échoue
        console.error('Failed to log audit trail:', error);
      }
    } catch (error) {
      // Ne pas propager l'erreur - l'audit trail est secondaire
      console.error('Audit trail logging failed:', error);
    }
  },

  // Récupérer les logs d'audit avec filtres
  async getAuditLogs(filters?: AuditFilters): Promise<AuditLogEntry[]> {
    try {
      let query = supabase
        .from('audit_trail')
        .select('*')
        .order('timestamp', { ascending: false });

      if (filters?.tableName) {
        query = query.eq('table_name', filters.tableName);
      }
      if (filters?.recordId) {
        query = query.eq('record_id', filters.recordId);
      }
      if (filters?.userId) {
        query = query.eq('user_id', filters.userId);
      }
      if (filters?.action) {
        query = query.eq('action', filters.action);
      }
      if (filters?.startDate) {
        query = query.gte('timestamp', filters.startDate);
      }
      if (filters?.endDate) {
        query = query.lte('timestamp', filters.endDate);
      }

      // Limiter les résultats
      query = query.limit(1000);

      const { data, error } = await query;

      if (error) throw handleSupabaseError(error, 'fetch audit logs');

      return data || [];
    } catch (error) {
      if (error instanceof QMSError) throw error;
      throw new NetworkError('Failed to fetch audit logs', { originalError: error as Error });
    }
  },

  // Récupérer l'historique d'un document spécifique
  async getDocumentHistory(documentId: string): Promise<AuditLogEntry[]> {
    return this.getAuditLogs({ tableName: 'documents', recordId: documentId });
  },

  // Vérifier l'intégrité d'un document signé
  async verifyDocumentIntegrity(
    documentId: string,
    expectedHash?: string
  ): Promise<{ isValid: boolean; signatures: any[] }> {
    try {
      // Récupérer toutes les signatures du document
      const { data: signatures, error } = await supabase
        .from('signatures')
        .select('*')
        .eq('document_id', documentId)
        .order('timestamp', { ascending: false });

      if (error) throw handleSupabaseError(error, 'verify document signatures');

      // Si un hash est fourni, vérifier qu'il correspond
      if (expectedHash && signatures) {
        const matchingSignature = signatures.find(s => s.hash === expectedHash);
        return {
          isValid: !!matchingSignature,
          signatures: signatures || [],
        };
      }

      return {
        isValid: (signatures?.length || 0) > 0,
        signatures: signatures || [],
      };
    } catch (error) {
      if (error instanceof QMSError) throw error;
      throw new NetworkError('Failed to verify document integrity', { originalError: error as Error });
    }
  },

  // Exporter les logs d'audit (pour les audits externes)
  async exportAuditLogs(
    filters?: AuditFilters,
    format: 'json' | 'csv' = 'json'
  ): Promise<string> {
    const logs = await this.getAuditLogs(filters);

    if (format === 'csv') {
      // Convertir en CSV
      const headers = ['Timestamp', 'Action', 'Table', 'Record ID', 'User', 'Changes'];
      const rows = logs.map(log => [
        log.timestamp,
        log.action,
        log.tableName,
        log.recordId,
        log.userEmail || log.userId,
        JSON.stringify({ old: log.oldValues, new: log.newValues }),
      ]);
      
      return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    }

    return JSON.stringify(logs, null, 2);
  },
};

export default auditApi;
