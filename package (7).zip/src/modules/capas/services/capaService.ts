// CAPA Service - Service pour les actions correctives et préventives
// Conforme ISO 13485 Section 8.5.2 & 8.5.3

import { supabase } from '@/lib/supabase';
import { CAPA } from '@/types/qms';
import { QMSError, handleSupabaseError, NetworkError } from '@/lib/error/QMSError';
import { auditApi } from '../../documents/services/auditService';

export interface CAPAFilters {
  status?: string;
  type?: string;
  priority?: string;
  search?: string;
}

// Demo CAPA store - persists during session
let demoCAPAsStore: CAPA[] = [
  {
    id: 'capa-001',
    capaNumber: 'CAPA-2025-001',
    title: 'Documentation process improvement',
    type: 'Corrective',
    status: 'Open',
    priority: 'Medium',
    source: 'Process Improvement',
    description: 'Streamline the document approval workflow to reduce delays',
    problemStatement: 'Current document approval process takes 15+ days',
    investigationDetails: 'Analysis of Q1 2025 data shows bottlenecks in Quality Manager review',
    rootCauseAnalysis: 'Manual routing and lack of parallel review steps',
    rootCauseCategory: 'Process',
    immediateCorrection: 'Implemented email notifications for pending reviews',
    assignedTo: 'Sarah Chen',
    assignedDate: '2025-01-15',
    dueDate: '2025-02-28',
    createdDate: '2025-01-15',
  },
  {
    id: 'capa-002',
    capaNumber: 'CAPA-2025-002',
    title: 'Supplier quality issue - Component XYZ',
    type: 'Corrective',
    status: 'In Progress',
    priority: 'High',
    source: 'Incoming Inspection',
    description: 'Recurring quality issues with component from Supplier ABC',
    problemStatement: '3 batches rejected due to dimensional tolerances out of specification',
    rootCauseAnalysis: 'Supplier manufacturing process drift detected',
    rootCauseCategory: 'Supplier',
    linkedNCRId: 'ncr-001',
    assignedTo: 'Michael Torres',
    assignedDate: '2025-01-20',
    dueDate: '2025-02-15',
    createdDate: '2025-01-20',
  },
  {
    id: 'capa-003',
    capaNumber: 'CAPA-2025-003',
    title: 'Training compliance gap identified',
    type: 'Preventive',
    status: 'Verification',
    priority: 'Low',
    source: 'Internal Audit',
    description: 'Some operators not completing mandatory annual training',
    problemStatement: 'Audit finding AUD-2025-012 identified 12% training gap',
    rootCauseAnalysis: 'Training calendar not integrated with onboarding process',
    rootCauseCategory: 'System',
    linkedAuditId: 'audit-001',
    assignedTo: 'Emily Rodriguez',
    assignedDate: '2025-01-25',
    dueDate: '2025-03-15',
    createdDate: '2025-01-25',
  },
  {
    id: 'capa-004',
    capaNumber: 'CAPA-2024-045',
    title: 'Equipment calibration drift',
    type: 'Corrective',
    status: 'Closed',
    priority: 'Critical',
    source: 'Equipment Monitoring',
    description: 'Calibration drift identified in critical measurement equipment',
    rootCauseAnalysis: 'Preventive maintenance schedule not followed',
    rootCauseCategory: 'Equipment',
    correctiveAction: 'Updated PM schedule and added automated alerts',
    closureDate: '2024-12-15',
    assignedTo: 'James Wilson',
    assignedDate: '2024-11-01',
    dueDate: '2024-12-01',
    createdDate: '2024-11-01',
    closedDate: '2024-12-15',
  },
];

// Interface for database response (snake_case)
interface CAPADatabase {
  id: string;
  capa_number: string;
  title: string;
  type: string;
  status: string;
  priority: string;
  source: string;
  source_reference_id?: string;
  source_description?: string;
  description: string;
  problem_statement?: string;
  investigation_details?: string;
  root_cause_analysis?: string;
  root_cause_category?: string;
  five_whys?: string[];
  fishbone_diagram?: Record<string, string>;
  immediate_correction?: string;
  correction_implementation_date?: string;
  corrective_action?: string;
  corrective_action_plan?: string;
  action_implementation_date?: string;
  effectiveness_verification_method?: string;
  effectiveness_criteria?: string;
  effectiveness_review_date?: string;
  effectiveness_result?: string;
  effectiveness_evidence?: string;
  closure_date?: string;
  closure_comments?: string;
  approved_by?: string;
  approval_date?: string;
  linked_ncr_id?: string;
  linked_audit_id?: string;
  linked_deviation_id?: string;
  assigned_to: string;
  assigned_date?: string;
  due_date: string;
  created_date: string;
  closed_date?: string;
  created_by?: string;
  created_at?: string;
  updated_at?: string;
}

// Mapper la réponse de la base de données vers le type TypeScript
const mapDatabaseToCAPA = (dbCAPA: CAPADatabase): CAPA => ({
  id: dbCAPA.id,
  capaNumber: dbCAPA.capa_number,
  title: dbCAPA.title,
  type: dbCAPA.type as CAPA['type'],
  status: dbCAPA.status as CAPA['status'],
  priority: dbCAPA.priority as CAPA['priority'],
  source: dbCAPA.source as CAPA['source'],
  sourceReferenceId: dbCAPA.source_reference_id,
  sourceDescription: dbCAPA.source_description,
  description: dbCAPA.description,
  problemStatement: dbCAPA.problem_statement,
  investigationDetails: dbCAPA.investigation_details,
  rootCauseAnalysis: dbCAPA.root_cause_analysis,
  rootCauseCategory: dbCAPA.root_cause_category as CAPA['rootCauseCategory'],
  fiveWhys: dbCAPA.five_whys,
  fishboneDiagram: dbCAPA.fishbone_diagram,
  immediateCorrection: dbCAPA.immediate_correction,
  correctionImplementationDate: dbCAPA.correction_implementation_date,
  correctiveAction: dbCAPA.corrective_action,
  correctiveActionPlan: dbCAPA.corrective_action_plan,
  actionImplementationDate: dbCAPA.action_implementation_date,
  effectivenessVerificationMethod: dbCAPA.effectiveness_verification_method,
  effectivenessCriteria: dbCAPA.effectiveness_criteria,
  effectivenessReviewDate: dbCAPA.effectiveness_review_date,
  effectivenessResult: dbCAPA.effectiveness_result as CAPA['effectivenessResult'],
  effectivenessEvidence: dbCAPA.effectiveness_evidence,
  closureDate: dbCAPA.closure_date,
  closureComments: dbCAPA.closure_comments,
  approvedBy: dbCAPA.approved_by,
  approvalDate: dbCAPA.approval_date,
  linkedNCRId: dbCAPA.linked_ncr_id,
  linkedAuditId: dbCAPA.linked_audit_id,
  linkedDeviationId: dbCAPA.linked_deviation_id,
  assignedTo: dbCAPA.assigned_to,
  assignedDate: dbCAPA.assigned_date,
  dueDate: dbCAPA.due_date,
  createdDate: dbCAPA.created_date,
  closedDate: dbCAPA.closed_date,
  created_by: dbCAPA.created_by,
  created_at: dbCAPA.created_at,
  updated_at: dbCAPA.updated_at,
});

export interface CreateCAPAInput {
  title: string;
  type: 'Corrective' | 'Preventive';
  source?: string;
  sourceReferenceId?: string;
  sourceDescription?: string;
  description?: string;
  problemStatement?: string;
  priority?: string;
  assignedTo?: string;
  dueDate?: string;
  linkedNCRId?: string;
  linkedAuditId?: string;
  linkedDeviationId?: string;
}

export interface UpdateCAPAInput {
  title?: string;
  description?: string;
  status?: string;
  priority?: string;
  investigationDetails?: string;
  rootCauseAnalysis?: string;
  rootCauseCategory?: string;
  immediateCorrection?: string;
  correctionImplementationDate?: string;
  correctiveAction?: string;
  correctiveActionPlan?: string;
  actionImplementationDate?: string;
  effectivenessVerificationMethod?: string;
  effectivenessCriteria?: string;
  effectivenessReviewDate?: string;
  effectivenessResult?: string;
  effectivenessEvidence?: string;
  closureDate?: string;
  closureComments?: string;
  approvedBy?: string;
  linkedNCRId?: string;
  linkedAuditId?: string;
  assignedTo?: string;
  dueDate?: string;
}

// Service CAPA
export const capaService = {
  async getAll(filters?: CAPAFilters): Promise<CAPA[]> {
    try {
      let query = supabase
        .from('capas')
        .select('*')
        .order('created_at', { ascending: false });

      if (filters?.status && filters.status !== 'all') {
        query = query.eq('status', filters.status);
      }
      if (filters?.type && filters.type !== 'all') {
        query = query.eq('type', filters.type);
      }
      if (filters?.priority && filters.priority !== 'all') {
        query = query.eq('priority', filters.priority);
      }
      if (filters?.search) {
        query = query.or(`title.ilike.%${filters.search}%,capa_number.ilike.%${filters.search}%`);
      }

      const { data, error } = await query;

      if (error) throw handleSupabaseError(error, 'fetch capas');

      return (data || []).map(mapDatabaseToCAPA);
    } catch (error) {
      // Return demo data from store if Supabase is not available
      console.log('Using demo CAPAs store');
      
      let filteredCAPAs = demoCAPAsStore;
      
      // Apply filters to demo data
      if (filters?.status && filters.status !== 'all') {
        filteredCAPAs = filteredCAPAs.filter(c => c.status === filters.status);
      }
      if (filters?.type && filters.type !== 'all') {
        filteredCAPAs = filteredCAPAs.filter(c => c.type === filters.type);
      }
      if (filters?.priority && filters.priority !== 'all') {
        filteredCAPAs = filteredCAPAs.filter(c => c.priority === filters.priority);
      }
      if (filters?.search) {
        const searchLower = filters.search.toLowerCase();
        filteredCAPAs = filteredCAPAs.filter(c => 
          c.title.toLowerCase().includes(searchLower) || 
          c.capaNumber.toLowerCase().includes(searchLower)
        );
      }
      
      return filteredCAPAs;
    }
  },

  async getById(id: string): Promise<CAPA | null> {
    try {
      const { data, error } = await supabase
        .from('capas')
        .select('*')
        .eq('id', id)
        .single();

      if (error) {
        if (error.code === 'PGRST116') return null;
        throw handleSupabaseError(error, 'fetch capa by id');
      }

      return data ? mapDatabaseToCAPA(data) : null;
    } catch (error) {
      // Demo mode: search in local store
      const demoCAPA = demoCAPAsStore.find(c => c.id === id);
      if (demoCAPA) {
        return demoCAPA;
      }
      if (error instanceof QMSError) throw error;
      throw new NetworkError('Failed to fetch CAPA', { originalError: error as Error });
    }
  },

  async create(input: CreateCAPAInput, userId: string): Promise<CAPA> {
    try {
      const capaNumber = await generateCAPANumber();

      const { data, error } = await supabase
        .from('capas')
        .insert({
          capa_number: capaNumber,
          title: input.title,
          type: input.type,
          source: input.source || 'Other',
          source_reference_id: input.sourceReferenceId,
          source_description: input.sourceDescription,
          description: input.description,
          problem_statement: input.problemStatement,
          priority: input.priority || 'Medium',
          status: 'Open',
          assigned_to: input.assignedTo || 'Unassigned',
          assigned_date: new Date().toISOString(),
          due_date: input.dueDate || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          linked_ncr_id: input.linkedNCRId,
          linked_audit_id: input.linkedAuditId,
          linked_deviation_id: input.linkedDeviationId,
          created_by: userId,
          created_date: new Date().toISOString(),
        })
        .select()
        .single();

      if (error) throw handleSupabaseError(error, 'create capa');

      await auditApi.logAudit({
        action: 'CREATE',
        tableName: 'capas',
        recordId: data.id,
        userId,
        newValues: data,
      });

      return mapDatabaseToCAPA(data);
    } catch (error) {
      // Demo mode: create mock CAPA in local store
      const capaNumber = `CAPA-${new Date().getFullYear()}-${String(demoCAPAsStore.length + 1).padStart(3, '0')}`;
      
      const newCAPA: CAPA = {
        id: `capa-demo-${Date.now()}`,
        capaNumber,
        title: input.title,
        type: input.type as CAPA['type'],
        status: 'Open',
        priority: (input.priority as CAPA['priority']) || 'Medium',
        source: (input.source as CAPA['source']) || 'Other',
        description: input.description || '',
        problemStatement: input.problemStatement,
        assignedTo: input.assignedTo || 'Unassigned',
        assignedDate: new Date().toISOString().split('T')[0],
        dueDate: input.dueDate || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        createdDate: new Date().toISOString().split('T')[0],
        linkedNCRId: input.linkedNCRId,
        linkedAuditId: input.linkedAuditId,
        linkedDeviationId: input.linkedDeviationId,
      };
      
      // Add to demo store
      demoCAPAsStore = [newCAPA, ...demoCAPAsStore];
      
      return newCAPA;
    }
  },

  async update(id: string, input: UpdateCAPAInput, userId: string): Promise<CAPA> {
    try {
      const oldCAPA = await this.getById(id);

      const { data, error } = await supabase
        .from('capas')
        .update({
          ...input,
          updated_at: new Date().toISOString(),
        })
        .eq('id', id)
        .select()
        .single();

      if (error) throw handleSupabaseError(error, 'update capa');

      await auditApi.logAudit({
        action: 'UPDATE',
        tableName: 'capas',
        recordId: id,
        userId,
        oldValues: oldCAPA,
        newValues: data,
      });

      return data;
    } catch (error) {
      if (error instanceof QMSError) throw error;
      throw new NetworkError('Failed to update CAPA', { originalError: error as Error });
    }
  },

  async close(id: string, userId: string): Promise<CAPA> {
    return this.update(id, {
      status: 'Closed',
    }, userId);
  },

  async getStats(): Promise<{
    total: number;
    open: number;
    inProgress: number;
    closed: number;
    critical: number;
  }> {
    try {
      const { data, error } = await supabase
        .from('capas')
        .select('status, priority');

      if (error) throw handleSupabaseError(error, 'fetch capa stats');

      const capas = data || [];
      return {
        total: capas.length,
        open: capas.filter(c => c.status === 'Open').length,
        inProgress: capas.filter(c => c.status === 'In Progress').length,
        closed: capas.filter(c => c.status === 'Closed').length,
        critical: capas.filter(c => c.priority === 'Critical').length,
      };
    } catch (error) {
      if (error instanceof QMSError) throw error;
      throw new NetworkError('Failed to fetch CAPA stats', { originalError: error as Error });
    }
  },
};

// Générer un numéro CAPA unique
async function generateCAPANumber(): Promise<string> {
  const year = new Date().getFullYear();
  const { count } = await supabase
    .from('capas')
    .select('*', { count: 'exact', head: true });

  const num = (count || 0) + 1;
  return `CAPA-${year}-${num.toString().padStart(4, '0')}`;
}

export default capaService;
