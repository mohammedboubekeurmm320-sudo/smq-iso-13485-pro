// React Query Hooks pour les CAPAs
// Gestion du state et des side-effects pour les CAPAs

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { capaService, CAPAFilters } from '../services/capaService';
import { QMSError } from '@/lib/error/QMSError';
import { toast } from 'sonner';

// Clés de cache pour React Query
export const capaKeys = {
  all: ['capas'] as const,
  lists: () => [...capaKeys.all, 'list'] as const,
  list: (filters: CAPAFilters) => [...capaKeys.lists(), filters] as const,
  details: () => [...capaKeys.all, 'detail'] as const,
  detail: (id: string) => [...capaKeys.details(), id] as const,
  stats: () => [...capaKeys.all, 'stats'] as const,
};

// Hook pour récupérer la liste des CAPAs
export const useCAPAs = (filters?: CAPAFilters) => {
  return useQuery({
    queryKey: capaKeys.list(filters || {}),
    queryFn: () => capaService.getAll(filters),
    staleTime: 5 * 60 * 1000,
    retry: 3,
  });
};

// Hook pour récupérer une CAPA par ID
export const useCAPA = (id: string) => {
  return useQuery({
    queryKey: capaKeys.detail(id),
    queryFn: () => capaService.getById(id),
    enabled: !!id,
    staleTime: 5 * 60 * 1000,
  });
};

// Hook pour les statistiques CAPA
export const useCAPAStats = () => {
  return useQuery({
    queryKey: capaKeys.stats(),
    queryFn: () => capaService.getStats(),
    staleTime: 60 * 1000,
  });
};

// Hook pour créer une CAPA
export const useCreateCAPA = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      input,
      userId,
    }: {
      input: {
        title: string;
        type: 'Corrective' | 'Preventive';
        source?: string;
        sourceReferenceId?: string;
        sourceDescription?: string;
        description?: string;
        problemStatement?: string;
        priority?: string;
        assignedTo?: string;
        dueDate?: string;
        linkedNCRId?: string;
        linkedAuditId?: string;
        linkedDeviationId?: string;
      };
      userId: string;
    }) => capaService.create(input, userId),

    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: capaKeys.all });
      queryClient.invalidateQueries({ queryKey: capaKeys.stats() });
      
      toast.success('CAPA created successfully', {
        description: `CAPA ${data.capaNumber} has been created.`,
      });
    },

    onError: (error: Error) => {
      const qmsError = error as QMSError;
      toast.error(qmsError.userMessage || 'Failed to create CAPA');
    },
  });
};

// Hook pour mettre à jour une CAPA
export const useUpdateCAPA = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      id,
      input,
      userId,
    }: {
      id: string;
      input: {
        title?: string;
        description?: string;
        status?: string;
        priority?: string;
        rootCause?: string;
        proposedAction?: string;
        assignedTo?: string;
        dueDate?: string;
      };
      userId: string;
    }) => capaService.update(id, input, userId),

    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: capaKeys.all });
      queryClient.invalidateQueries({ queryKey: capaKeys.detail(variables.id) });
      queryClient.invalidateQueries({ queryKey: capaKeys.stats() });
      
      toast.success('CAPA updated successfully');
    },

    onError: (error: Error) => {
      const qmsError = error as QMSError;
      toast.error(qmsError.userMessage || 'Failed to update CAPA');
    },
  });
};

// Hook pour fermer une CAPA
export const useCloseCAPA = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      id,
      userId,
    }: {
      id: string;
      userId: string;
    }) => capaService.close(id, userId),

    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: capaKeys.all });
      queryClient.invalidateQueries({ queryKey: capaKeys.stats() });
      
      toast.success('CAPA closed successfully');
    },

    onError: (error: Error) => {
      const qmsError = error as QMSError;
      toast.error(qmsError.userMessage || 'Failed to close CAPA');
    },
  });
};

export default {
  useCAPAs,
  useCAPA,
  useCAPAStats,
  useCreateCAPA,
  useUpdateCAPA,
  useCloseCAPA,
};
