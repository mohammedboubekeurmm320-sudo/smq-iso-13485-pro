# Legal Documents Module

## Overview

This module handles legal and regulatory documents such as Terms of Service, Privacy Policy, and Data Processing Agreements.

## Services

### legalDocumentService.ts

Main service for legal document management.

#### Methods

- `getDocuments(documentType)` - Retrieve all documents of a type
- `getDocumentById(id)` - Get a single document
- `getDocumentByVersion(type, version)` - Get document by version
- `createDocument(data)` - Create a new version
- `updateDocument(id, data)` - Update a document

## Hooks

### useLegalDocuments

React Query hook for legal document list management.

```typescript
const { data } = useLegalDocuments('privacy_policy');
```

### useLegalDocumentByVersion

Hook for retrieving a specific version.

```typescript
const { data } = useLegalDocumentByVersion('terms_of_service', '2.0');
```

## Types

```typescript
interface LegalDocument {
  id: string;
  type: string;
  version: string;
  title: string;
  content: string;
  is_active: boolean;
  effective_date: string;
  created_at: string;
  updated_at?: string;
}
```

## Document Types

- `terms_of_service` - Conditions Générales d'Utilisation
- `privacy_policy` - Politique de Confidentialité
- `DPA` - Accord de Traitement des Données (Data Processing Agreement)
- `cookie_policy` - Politique des Cookies
