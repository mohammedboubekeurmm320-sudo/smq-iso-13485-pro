// React Query Hooks pour les Documents Légaux state et des side
// Gestion du-effects pour les documents légaux

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { legalDocumentService, LegalDocument } from '../services/legalDocumentService';
import { QMSError } from '@/lib/error/QMSError';
import { toast } from 'sonner';

// Clés de cache pour React Query
export const legalDocumentKeys = {
  all: ['legalDocuments'] as const,
  lists: () => [...legalDocumentKeys.all, 'list'] as const,
  list: (type: string) => [...legalDocumentKeys.lists(), type] as const,
  details: () => [...legalDocumentKeys.all, 'detail'] as const,
  detail: (id: string) => [...legalDocumentKeys.details(), id] as const,
};

// Hook pour récupérer les documents légaux par type
export const useLegalDocuments = (documentType: string) => {
  return useQuery({
    queryKey: legalDocumentKeys.list(documentType),
    queryFn: () => legalDocumentService.getDocuments(documentType),
    enabled: !!documentType,
    staleTime: 5 * 60 * 1000, // 5 minutes
    retry: 2,
  });
};

// Hook pour récupérer un document légal par ID
export const useLegalDocument = (documentId: string) => {
  return useQuery({
    queryKey: legalDocumentKeys.detail(documentId),
    queryFn: () => legalDocumentService.getDocumentById(documentId),
    enabled: !!documentId,
    staleTime: 5 * 60 * 1000,
  });
};

// Hook pour récupérer un document par version
export const useLegalDocumentByVersion = (documentType: string, version: string) => {
  return useQuery({
    queryKey: [...legalDocumentKeys.list(documentType), version],
    queryFn: () => legalDocumentService.getDocumentByVersion(documentType, version),
    enabled: !!documentType && !!version,
    staleTime: 5 * 60 * 1000,
  });
};

// Hook pour créer un document légal
export const useCreateLegalDocument = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (documentData: Partial<LegalDocument>) => 
      legalDocumentService.createDocument(documentData),

    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: legalDocumentKeys.all });
      
      toast.success('Legal document created successfully', {
        description: `Document ${data.title} has been created.`,
      });
    },

    onError: (error: Error) => {
      const qmsError = error as QMSError;
      toast.error(qmsError.userMessage || 'Failed to create legal document');
    },
  });
};

// Hook pour mettre à jour un document légal
export const useUpdateLegalDocument = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      documentId,
      documentData,
    }: {
      documentId: string;
      documentData: Partial<LegalDocument>;
    }) => legalDocumentService.updateDocument(documentId, documentData),

    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: legalDocumentKeys.all });
      queryClient.invalidateQueries({ queryKey: legalDocumentKeys.detail(variables.documentId) });
      
      toast.success('Legal document updated successfully', {
        description: `Document has been updated.`,
      });
    },

    onError: (error: Error) => {
      const qmsError = error as QMSError;
      toast.error(qmsError.userMessage || 'Failed to update legal document');
    },
  });
};

export default {
  useLegalDocuments,
  useLegalDocument,
  useLegalDocumentByVersion,
  useCreateLegalDocument,
  useUpdateLegalDocument,
};
