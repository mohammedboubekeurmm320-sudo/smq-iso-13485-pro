// Audit Service - Service pour la gestion des audits
// Conforme ISO 13485 Section 8.2 & 8.2.1

import { supabase } from '@/lib/supabase';
import { QMSError, handleSupabaseError, NetworkError } from '@/lib/error/QMSError';

// Demo store for offline mode
const demoAudits: Audit[] = [
  {
    id: 'demo-audit-1',
    auditNumber: 'AUD-2024-0001',
    title: 'Audit interne système qualité',
    description: 'Audit interne complet du système de management de la qualité selon ISO 13485:2016',
    type: 'Internal',
    status: 'Completed',
    scheduledDate: '2024-01-15',
    completedDate: '2024-01-17',
    leadAuditor: 'Marie Martin',
    auditees: ['Jean Dupont', 'Sophie Bernard', 'Pierre Martin'],
    department: 'Qualité',
    scope: 'Système de management de la qualité complet',
    auditCriteria: 'ISO 13485:2016, 21 CFR Part 820',
    auditProgram: 'Programme annuel 2024',
    standardReferences: ['ISO 13485:2016', 'ISO 9001:2015'],
    findings: 3,
    observations: 5,
    majorFindings: 1,
    minorFindings: 2,
    opportunitiesForImprovement: 'Améliorer la traçabilité des formations',
    conclusion: 'Pass',
    auditSummary: 'Le système de management de la qualité est efficace et conforme aux exigences ISO 13485. Quelques opportunités d\'amélioration identifiées.',
    followUpRequired: true,
    followUpDate: '2024-04-15',
    created_at: '2024-01-01T10:00:00Z',
    updated_at: '2024-01-17T10:00:00Z',
  },
  {
    id: 'demo-audit-2',
    auditNumber: 'AUD-2024-0002',
    title: 'Audit fournisseur - Matières premières',
    description: 'Audit de qualification du fournisseur de matières premières médicales',
    type: 'Supplier',
    status: 'In Progress',
    scheduledDate: '2024-02-20',
    leadAuditor: 'Sophie Bernard',
    auditees: ['Responsable Achats', 'Responsable Qualité Fournisseur'],
    department: 'Achats',
    scope: 'Processus d\'approvisionnement et contrôle qualité',
    auditCriteria: 'ISO 13485:2016 Section 7.4',
    auditProgram: 'Programme annuel 2024',
    findings: 0,
    observations: 2,
    conclusion: 'Pending',
    created_at: '2024-02-01T10:00:00Z',
    updated_at: '2024-02-20T10:00:00Z',
  },
  {
    id: 'demo-audit-3',
    auditNumber: 'AUD-2024-0003',
    title: 'Audit FDA preparación',
    description: 'Préparation à l\'inspection FDA',
    type: 'Regulatory',
    status: 'Scheduled',
    scheduledDate: '2024-03-15',
    leadAuditor: 'Jean Dupont',
    auditees: ['Direction', 'Responsable Qualité', 'Responsable Production'],
    department: 'Qualité',
    scope: 'Pré-inspection FDA - Mock inspection',
    auditCriteria: '21 CFR Part 820',
    auditProgram: 'Programme annuel 2024',
    findings: 0,
    observations: 0,
    conclusion: 'Pending',
    created_at: '2024-02-15T10:00:00Z',
    updated_at: '2024-02-15T10:00:00Z',
  },
];

export interface Audit {
  id: string;
  auditNumber: string;
  title: string;
  description?: string;
  type: 'Internal' | 'External' | 'Supplier' | 'Regulatory' | 'Unannounced';
  status: 'Scheduled' | 'In Progress' | 'Completed' | 'Cancelled';
  scheduledDate: string;
  completedDate?: string;
  leadAuditor: string;
  auditees: string[];
  department: string;
  scope: string;
  // ISO 13485:8.2.2 - Audit criteria and scope
  auditCriteria?: string;
  auditProgram?: string;
  standardReferences?: string;
  // ISO 13485:8.2.2 - Findings
  findings: number;
  observations: number;
  majorFindings?: number;
  minorFindings?: number;
  opportunitiesForImprovement?: string;
  // ISO 13485:8.2.2 - Conclusion
  conclusion?: 'Pass' | 'Fail' | 'Conditional Pass' | 'Pending';
  auditSummary?: string;
  followUpRequired?: boolean;
  followUpDate?: string;
  created_at?: string;
  updated_at?: string;
}

export interface AuditFilters {
  type?: string;
  status?: string;
  department?: string;
  startDate?: string;
  endDate?: string;
  search?: string;
}

// Interface for database response (snake_case)
interface AuditDatabase {
  id: string;
  audit_number: string;
  title: string;
  description?: string;
  type: string;
  status: string;
  scheduled_date: string;
  completed_date?: string;
  lead_auditor: string;
  auditees: string[];
  department: string;
  scope: string;
  audit_criteria?: string;
  audit_program?: string;
  standard_references?: string;
  findings: number;
  observations: number;
  major_findings?: number;
  minor_findings?: number;
  opportunities_for_improvement?: string;
  conclusion?: string;
  audit_summary?: string;
  follow_up_required?: boolean;
  follow_up_date?: string;
  created_at?: string;
  updated_at?: string;
}

// Mapper la réponse de la base de données vers le type TypeScript
const mapDatabaseToAudit = (dbAudit: AuditDatabase): Audit => ({
  id: dbAudit.id,
  auditNumber: dbAudit.audit_number,
  title: dbAudit.title,
  description: dbAudit.description,
  type: dbAudit.type as Audit['type'],
  status: dbAudit.status as Audit['status'],
  scheduledDate: dbAudit.scheduled_date,
  completedDate: dbAudit.completed_date,
  leadAuditor: dbAudit.lead_auditor,
  auditees: dbAudit.auditees || [],
  department: dbAudit.department,
  scope: dbAudit.scope,
  auditCriteria: dbAudit.audit_criteria,
  auditProgram: dbAudit.audit_program,
  standardReferences: dbAudit.standard_references,
  findings: dbAudit.findings || 0,
  observations: dbAudit.observations || 0,
  majorFindings: dbAudit.major_findings,
  minorFindings: dbAudit.minor_findings,
  opportunitiesForImprovement: dbAudit.opportunities_for_improvement,
  conclusion: dbAudit.conclusion as Audit['conclusion'],
  auditSummary: dbAudit.audit_summary,
  followUpRequired: dbAudit.follow_up_required,
  followUpDate: dbAudit.follow_up_date,
  created_at: dbAudit.created_at,
  updated_at: dbAudit.updated_at,
});

// Service de gestion des audits
export const auditService = {
  // Récupérer tous les audits
  async getAudits(organizationId: string, filters?: AuditFilters): Promise<Audit[]> {
    try {
      let query = supabase
        .from('audits')
        .select('*')
        .eq('organization_id', organizationId)
        .order('scheduled_date', { ascending: false });

      if (filters?.type && filters.type !== 'all') {
        query = query.eq('type', filters.type);
      }

      if (filters?.status && filters.status !== 'all') {
        query = query.eq('status', filters.status);
      }

      if (filters?.department && filters.department !== 'all') {
        query = query.eq('department', filters.department);
      }

      if (filters?.search) {
        query = query.or(`title.ilike.%${filters.search}%,audit_number.ilike.%${filters.search}%`);
      }

      const { data, error } = await query;

      if (error) throw handleSupabaseError(error, 'fetch audits');

      return (data || []).map(mapDatabaseToAudit);
    } catch (error) {
      // Fallback to demo data in offline mode
      console.log('Using demo audit data');
      let filtered = [...demoAudits];
      if (filters?.type && filters.type !== 'all') {
        filtered = filtered.filter(a => a.type === filters.type);
      }
      if (filters?.status && filters.status !== 'all') {
        filtered = filtered.filter(a => a.status === filters.status);
      }
      if (filters?.department && filters.department !== 'all') {
        filtered = filtered.filter(a => a.department === filters.department);
      }
      if (filters?.search) {
        const search = filters.search.toLowerCase();
        filtered = filtered.filter(a => 
          a.title.toLowerCase().includes(search) || 
          a.auditNumber.toLowerCase().includes(search)
        );
      }
      return filtered.sort((a, b) => new Date(b.scheduledDate).getTime() - new Date(a.scheduledDate).getTime());
    }
  },

  // Récupérer un audit par ID
  async getAuditById(auditId: string): Promise<Audit | null> {
    try {
      const { data, error } = await supabase
        .from('audits')
        .select('*')
        .eq('id', auditId)
        .single();

      if (error) {
        if (error.code === 'PGRST116') return null;
        throw handleSupabaseError(error, 'fetch audit');
      }

      return data ? mapDatabaseToAudit(data) : null;
    } catch (error) {
      // Fallback to demo data in offline mode
      console.log('Using demo audit');
      return demoAudits.find(a => a.id === auditId) || null;
    }
  },

  // Créer un nouvel audit (ISO 13485:8.2.2)
  async createAudit(organizationId: string, auditData: Partial<Audit>): Promise<Audit> {
    try {
      // Générer un numéro d'audit unique
      const auditNumber = await generateAuditNumber(organizationId);

      const { data, error } = await supabase
        .from('audits')
        .insert({
          organization_id: organizationId,
          audit_number: auditNumber,
          title: auditData.title,
          description: auditData.description,
          type: auditData.type || 'Internal',
          status: 'Scheduled',
          scheduled_date: auditData.scheduledDate,
          lead_auditor: auditData.leadAuditor,
          auditees: auditData.auditees || [],
          department: auditData.department,
          scope: auditData.scope,
          audit_criteria: auditData.auditCriteria,
          audit_program: auditData.auditProgram,
          standard_references: auditData.standardReferences,
          findings: 0,
          observations: 0,
          conclusion: 'Pending',
        })
        .select()
        .single();

      if (error) throw handleSupabaseError(error, 'create audit');

      return mapDatabaseToAudit(data);
    } catch (error) {
      if (error instanceof QMSError) throw error;
      throw new NetworkError('Failed to create audit', { originalError: error as Error });
    }
  },

  // Mettre à jour un audit
  async updateAudit(auditId: string, auditData: Partial<Audit>): Promise<Audit> {
    try {
      const { data, error } = await supabase
        .from('audits')
        .update({
          title: auditData.title,
          description: auditData.description,
          type: auditData.type,
          status: auditData.status,
          scheduled_date: auditData.scheduledDate,
          completed_date: auditData.completedDate,
          lead_auditor: auditData.leadAuditor,
          department: auditData.department,
          scope: auditData.scope,
          findings: auditData.findings,
          observations: auditData.observations,
          updated_at: new Date().toISOString(),
        })
        .eq('id', auditId)
        .select()
        .single();

      if (error) throw handleSupabaseError(error, 'update audit');

      return {
        id: data.id,
        auditNumber: data.audit_number,
        title: data.title,
        description: data.description,
        type: data.type,
        status: data.status,
        scheduledDate: data.scheduled_date,
        completedDate: data.completed_date,
        leadAuditor: data.lead_auditor,
        department: data.department,
        scope: data.scope,
        findings: data.findings || 0,
        observations: data.observations || 0,
        created_at: data.created_at,
        updated_at: data.updated_at,
      };
    } catch (error) {
      if (error instanceof QMSError) throw error;
      throw new NetworkError('Failed to update audit', { originalError: error as Error });
    }
  },

  // Obtenir les statistiques des audits
  async getAuditStats(organizationId: string): Promise<{
    total: number;
    scheduled: number;
    inProgress: number;
    completed: number;
    byType: Record<string, number>;
  }> {
    try {
      const { data, error } = await supabase
        .from('audits')
        .select('type, status')
        .eq('organization_id', organizationId);

      if (error) throw handleSupabaseError(error, 'fetch audit stats');

      const audits = data || [];
      const byType: Record<string, number> = {};

      let scheduled = 0;
      let inProgress = 0;
      let completed = 0;

      audits.forEach(audit => {
        byType[audit.type] = (byType[audit.type] || 0) + 1;
        
        if (audit.status === 'Scheduled') scheduled++;
        else if (audit.status === 'In Progress') inProgress++;
        else if (audit.status === 'Completed') completed++;
      });

      return {
        total: audits.length,
        scheduled,
        inProgress,
        completed,
        byType,
      };
    } catch (error) {
      // Fallback to demo data in offline mode
      console.log('Using demo audit stats');
      const byType: Record<string, number> = {};
      demoAudits.forEach(audit => {
        byType[audit.type] = (byType[audit.type] || 0) + 1;
      });
      return {
        total: demoAudits.length,
        scheduled: demoAudits.filter(a => a.status === 'Scheduled').length,
        inProgress: demoAudits.filter(a => a.status === 'In Progress').length,
        completed: demoAudits.filter(a => a.status === 'Completed').length,
        byType,
      };
    }
  },
};

// Générer un numéro d'audit unique
async function generateAuditNumber(organizationId: string): Promise<string> {
  try {
    const year = new Date().getFullYear();
    const prefix = `AUD-${year}`;

    // Récupérer le dernier numéro d'audit
    const { data, error } = await supabase
      .from('audits')
      .select('audit_number')
      .like('audit_number', `${prefix}%`)
      .order('created_at', { ascending: false })
      .limit(1);

    if (error) throw handleSupabaseError(error, 'generate audit number');

    let nextNumber = 1;
    if (data && data.length > 0) {
      const lastNumber = parseInt(data[0].audit_number.split('-').pop() || '0', 10);
      nextNumber = lastNumber + 1;
    }

    return `${prefix}-${nextNumber.toString().padStart(4, '0')}`;
  } catch (error) {
    // En cas d'erreur, générer un numéro aléatoire
    const year = new Date().getFullYear();
    const random = Math.floor(Math.random() * 9999).toString().padStart(4, '0');
    return `AUD-${year}-${random}`;
  }
}

export default auditService;
