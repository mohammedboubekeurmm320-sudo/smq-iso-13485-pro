// React Query Hooks pour les Audits
// Gestion du state et des side-effects pour les audits

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { auditService, AuditFilters, Audit } from '../services/auditService';
import { QMSError } from '@/lib/error/QMSError';
import { toast } from 'sonner';

// Clés de cache pour React Query
export const auditKeys = {
  all: ['audits'] as const,
  lists: () => [...auditKeys.all, 'list'] as const,
  list: (filters: AuditFilters) => [...auditKeys.lists(), filters] as const,
  details: () => [...auditKeys.all, 'detail'] as const,
  detail: (id: string) => [...auditKeys.details(), id] as const,
  stats: () => [...auditKeys.all, 'stats'] as const,
};

// Hook pour récupérer la liste des audits
export const useAudits = (organizationId: string, filters?: AuditFilters) => {
  return useQuery({
    queryKey: auditKeys.list(filters || {}),
    queryFn: () => auditService.getAudits(organizationId, filters),
    enabled: !!organizationId,
    staleTime: 5 * 60 * 1000, // 5 minutes
    retry: 3,
  });
};

// Hook pour récupérer un audit par ID
export const useAudit = (auditId: string) => {
  return useQuery({
    queryKey: auditKeys.detail(auditId),
    queryFn: () => auditService.getAuditById(auditId),
    enabled: !!auditId,
    staleTime: 5 * 60 * 1000,
  });
};

// Hook pour les statistiques des audits
export const useAuditStats = (organizationId: string) => {
  return useQuery({
    queryKey: auditKeys.stats(),
    queryFn: () => auditService.getAuditStats(organizationId),
    enabled: !!organizationId,
    staleTime: 60 * 1000, // 1 minute
  });
};

// Hook pour créer un audit
export const useCreateAudit = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      organizationId,
      auditData,
    }: {
      organizationId: string;
      auditData: Partial<Audit>;
    }) => auditService.createAudit(organizationId, auditData),

    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: auditKeys.all });
      queryClient.invalidateQueries({ queryKey: auditKeys.stats() });
      
      toast.success('Audit created successfully', {
        description: `Audit ${data.auditNumber} has been created.`,
      });
    },

    onError: (error: Error) => {
      const qmsError = error as QMSError;
      toast.error(qmsError.userMessage || 'Failed to create audit');
    },
  });
};

// Hook pour mettre à jour un audit
export const useUpdateAudit = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      auditId,
      auditData,
    }: {
      auditId: string;
      auditData: Partial<Audit>;
    }) => auditService.updateAudit(auditId, auditData),

    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: auditKeys.all });
      queryClient.invalidateQueries({ queryKey: auditKeys.detail(variables.auditId) });
      queryClient.invalidateQueries({ queryKey: auditKeys.stats() });
      
      toast.success('Audit updated successfully', {
        description: `Audit ${data.auditNumber} has been updated.`,
      });
    },

    onError: (error: Error) => {
      const qmsError = error as QMSError;
      toast.error(qmsError.userMessage || 'Failed to update audit');
    },
  });
};

export default {
  useAudits,
  useAudit,
  useAuditStats,
  useCreateAudit,
  useUpdateAudit,
};
