// API Service Layer for Supabase
// Replaces mock data with real database queries

import { supabase } from '@/lib/supabase';
import { Document, CAPA, Audit, NonConformance, TrainingRecord } from '@/types/qms';

// Generic error handler
const handleError = (error: any, context: string): never => {
  console.error(`[API Error] ${context}:`, error);
  throw new Error(error.message || `Failed to ${context}`);
};

// Documents API
export const documentsApi = {
  async getAll(): Promise<Document[]> {
    try {
      const { data, error } = await supabase
        .from('documents')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.warn('Using fallback data - Supabase not available');
      return [];
    }
  },

  async create(doc: Partial<Document>): Promise<Document> {
    const { data, error } = await supabase
      .from('documents')
      .insert(doc)
      .select()
      .single();
    
    if (error) handleError(error, 'create document');
    return data;
  },

  async update(id: string, doc: Partial<Document>): Promise<Document> {
    const { data, error } = await supabase
      .from('documents')
      .update({ ...doc, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    
    if (error) handleError(error, 'update document');
    return data;
  },

  async delete(id: string): Promise<void> {
    const { error } = await supabase
      .from('documents')
      .delete()
      .eq('id', id);
    
    if (error) handleError(error, 'delete document');
  },

  async signDocument(docId: string, userId: string, password: string, reason: string): Promise<boolean> {
    // Verify password first
    const { error: authError } = await supabase.auth.signInWithPassword({
      email: userId,
      password
    });
    
    if (authError) {
      throw new Error('Invalid password');
    }

    // Create signature record
    const { error: sigError } = await supabase.from('signatures').insert({
      document_id: docId,
      user_id: userId,
      role: 'Approver',
      reason: reason,
      hash: btoa(`${docId}-${userId}-${Date.now()}`),
      timestamp: new Date().toISOString()
    });

    if (sigError) handleError(sigError, 'create signature');

    // Update document status to Approved
    const { error: updateError } = await supabase
      .from('documents')
      .update({ status: 'Approved', updated_at: new Date().toISOString() })
      .eq('id', docId);

    if (updateError) handleError(updateError, 'approve document');

    // Log to audit trail
    await this.logAudit('SIGN', 'documents', docId, null, { status: 'Approved' });

    return true;
  }
};

// CAPA API
export const capaApi = {
  async getAll(): Promise<CAPA[]> {
    try {
      const { data, error } = await supabase
        .from('capas')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.warn('Using fallback data - Supabase not available');
      return [];
    }
  },

  async create(capa: Partial<CAPA>): Promise<CAPA> {
    const { data, error } = await supabase
      .from('capas')
      .insert(capa)
      .select()
      .single();
    
    if (error) handleError(error, 'create CAPA');
    return data;
  },

  async update(id: string, capa: Partial<CAPA>): Promise<CAPA> {
    const { data, error } = await supabase
      .from('capas')
      .update(capa)
      .eq('id', id)
      .select()
      .single();
    
    if (error) handleError(error, 'update CAPA');
    return data;
  }
};

// Audit Trail API
export const auditApi = {
  async logAudit(
    action: string,
    tableName: string,
    recordId: string,
    oldValues: any = null,
    newValues: any = null,
    userId?: string
  ): Promise<void> {
    const { error } = await supabase.from('audit_trail').insert({
      action,
      table_name: tableName,
      record_id: recordId,
      old_values: oldValues,
      new_values: newValues,
      user_id: userId || 'system',
      ip_address: 'client',
      timestamp: new Date().toISOString()
    });

    if (error) {
      console.error('Failed to log audit trail:', error);
      // Non-blocking - don't throw
    }
  },

  async getAuditLogs(tableName?: string, recordId?: string): Promise<any[]> {
    let query = supabase
      .from('audit_trail')
      .select('*')
      .order('timestamp', { ascending: false });

    if (tableName) query = query.eq('table_name', tableName);
    if (recordId) query = query.eq('record_id', recordId);

    const { data, error } = await query;
    if (error) handleError(error, 'get audit logs');
    return data || [];
  }
};

// Training Records API
export const trainingApi = {
  async getAll(): Promise<TrainingRecord[]> {
    try {
      const { data, error } = await supabase
        .from('training_records')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.warn('Using fallback data - Supabase not available');
      return [];
    }
  },

  async create(record: Partial<TrainingRecord>): Promise<TrainingRecord> {
    const { data, error } = await supabase
      .from('training_records')
      .insert(record)
      .select()
      .single();
    
    if (error) handleError(error, 'create training record');
    return data;
  }
};

// Non-Conformance API
export const ncrApi = {
  async getAll(): Promise<NonConformance[]> {
    try {
      const { data, error } = await supabase
        .from('non_conformances')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.warn('Using fallback data - Supabase not available');
      return [];
    }
  },

  async create(ncr: Partial<NonConformance>): Promise<NonConformance> {
    const { data, error } = await supabase
      .from('non_conformances')
      .insert(ncr)
      .select()
      .single();
    
    if (error) handleError(error, 'create NCR');
    return data;
  }
};
