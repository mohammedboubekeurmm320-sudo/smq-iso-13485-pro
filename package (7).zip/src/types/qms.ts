// QMS Types based on ISO 13485 requirements

export interface Document {
  id: string;
  documentNumber: string;
  title: string;
  type: 'SOP' | 'WI' | 'Form' | 'Policy' | 'Specification' | 'Technical' | 'Risk Analysis' | 'Validation Protocol' | 'Record';
  version: string;
  status: 'Draft' | 'In Review' | 'Approved' | 'Obsolete';
  effectiveDate: string;
  expirationDate: string;
  owner: string;
  department: string;
  lastReviewed: string;
  nextReview: string;
  description: string;
  // ISO 13485:2016 Section 4.2.4 additional fields
  classification?: 'Internal' | 'External' | 'Regulatory' | 'Confidential';
  retentionPeriod?: string;
  scope?: string;
  references?: string;
  attachments?: string[];
  created_by?: string;
  created_at?: string;
  updated_at?: string;
}

export interface CAPA {
  id: string;
  capaNumber: string;
  title: string;
  type: 'Corrective' | 'Preventive';
  status: 'Open' | 'Investigation' | 'Implementation' | 'Effectiveness Check' | 'Closed';
  priority: 'Critical' | 'High' | 'Medium' | 'Low';
  // ISO 13485:8.5.2 - Source and reference
  source: 'Non-Conformance' | 'Audit Finding' | 'Customer Complaint' | 'Regulatory Finding' | 'Process Deviation' | 'Supplier Issue' | 'Other';
  sourceReferenceId?: string;
  sourceDescription?: string;
  // ISO 13485:8.5.2 - Problem statement
  description: string;
  problemStatement?: string;
  // ISO 13485:8.5.2 - Investigation
  investigationDetails?: string;
  rootCauseAnalysis?: string;
  rootCauseCategory?: 'Man' | 'Machine' | 'Method' | 'Material' | 'Measurement' | 'Environment' | 'Management';
  fiveWhys?: string[];
  fishboneDiagram?: Record<string, string>;
  // ISO 13485:8.5.2 - Correction and corrective action
  immediateCorrection?: string;
  correctionImplementationDate?: string;
  correctiveAction?: string;
  correctiveActionPlan?: string;
  actionImplementationDate?: string;
  // ISO 13485:8.5.3 - Effectiveness verification
  effectivenessVerificationMethod?: 'Audit' | 'Monitoring' | 'Testing' | 'Data Analysis' | 'Customer Feedback' | 'Other';
  effectivenessCriteria?: string;
  effectivenessReviewDate?: string;
  effectivenessResult?: 'Effective' | 'Not Effective' | 'Pending Review';
  effectivenessEvidence?: string;
  // ISO 13485:8.5.2 - Closure
  closureDate?: string;
  closureComments?: string;
  approvedBy?: string;
  approvalDate?: string;
  // Links
  linkedNCRId?: string;
  linkedAuditId?: string;
  linkedDeviationId?: string;
  // Assignment
  assignedTo: string;
  assignedDate?: string;
  dueDate: string;
  createdDate: string;
  closedDate?: string;
  // Metadata
  created_by?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Audit {
  id: string;
  auditNumber: string;
  title: string;
  description?: string;
  type: 'Internal' | 'External' | 'Supplier' | 'Regulatory' | 'Unannounced';
  status: 'Scheduled' | 'In Progress' | 'Completed' | 'Cancelled';
  scheduledDate: string;
  completedDate?: string;
  leadAuditor: string;
  auditees: string[];
  scope: string;
  // ISO 13485:8.2.2 - Audit criteria and scope
  auditCriteria?: string;
  auditProgram?: string;
  standardReferences?: string;
  // ISO 13485:8.2.2 - Findings
  findings: number;
  observations: number;
  majorFindings?: number;
  minorFindings?: number;
  opportunitiesForImprovement?: string;
  // ISO 13485:8.2.2 - Conclusion
  conclusion?: 'Pass' | 'Fail' | 'Conditional Pass' | 'Pending';
  auditSummary?: string;
  followUpRequired?: boolean;
  followUpDate?: string;
  department: string;
  // Metadata
  created_by?: string;
  created_at?: string;
  updated_at?: string;
}

export interface NonConformance {
  id: string;
  ncrNumber: string;
  title: string;
  type: 'Product' | 'Process' | 'System' | 'Supplier';
  status: 'Open' | 'Under Investigation' | 'Pending Disposition' | 'Closed';
  severity: 'Critical' | 'Major' | 'Minor';
  // ISO 13485:8.3 - Source and detection
  source: 'Incoming Inspection' | 'In-Process Inspection' | 'Final Inspection' | 'Customer Complaint' | 'Internal Audit' | 'Process Monitoring' | 'Supplier' | 'Other';
  sourceDescription?: string;
  detectedDate: string;
  detectedBy?: string;
  // Product/Lot information
  lotNumber?: string;
  quantityAffected?: number;
  totalQuantity?: number;
  productName?: string;
  partNumber?: string;
  // ISO 13485:8.3 - Description
  description: string;
  // ISO 13485:8.3 - Immediate action (containment)
  immediateAction?: string;
  containmentEffective?: boolean;
  // ISO 13485:8.3 - Root cause analysis
  rootCauseAnalysis?: string;
  fiveWhys?: string[];
  fishboneDiagram?: Record<string, string>;
  // ISO 13485:8.3 - Disposition
  disposition: 'Use As Is' | 'Rework' | 'Scrap' | 'Return to Supplier' | 'Concession' | 'Pending';
  dispositionJustification?: string;
  dispositionApprovedBy?: string;
  dispositionDate?: string;
  // Verification
  effectivenessVerification?: string;
  verificationDate?: string;
  verifiedBy?: string;
  // Links
  linkedCapa?: string;
  linkedAuditId?: string;
  linkedDeviationId?: string;
  // Assignment
  assignedTo: string;
  createdDate: string;
  closedDate?: string;
  dueDate?: string;
  // Metadata
  created_by?: string;
  created_at?: string;
  updated_at?: string;
}

export interface TrainingRecord {
  id: string;
  // Employee Information - ISO 13485:7.2
  employeeId: string;
  employeeName: string;
  employeeEmail?: string;
  department: string;
  jobTitle?: string;
  
  // Training Details - ISO 13485:7.2
  trainingTitle: string;
  trainingType: 'Initial' | 'Refresher' | 'Certification' | 'On-the-Job' | 'External';
  trainingCategory?: 'GMP' | 'ISO 13485' | 'Quality' | 'Technical' | 'Safety' | 'Regulatory' | 'Software' | 'Process';
  trainingProvider?: string;
  trainingLocation?: string;
  
  // ISO 13485:7.2 - Competence requirements
  competenceRequirements?: string;
  skillsMatrixArea?: string;
  
  // Status and dates - ISO 13485:7.3
  status: 'Completed' | 'In Progress' | 'Overdue' | 'Scheduled' | 'Cancelled';
  completedDate?: string;
  dueDate: string;
  startDate?: string;
  expirationDate?: string;
  
  // Training delivery
  trainer: string;
  trainingMethod?: 'Classroom' | 'Online' | 'OJT' | 'Workshop' | 'External Course' | 'Self-Paced';
  trainingDuration?: string;
  
  // Assessment - ISO 13485:7.3
  assessmentMethod?: 'Exam' | 'Practical' | 'Observation' | 'Certification' | 'Portfolio';
  score?: number;
  passingScore?: number;
  assessmentDate?: string;
  assessorName?: string;
  
  // Documentation - ISO 13485:7.3
  documentRef: string;
  certificateNumber?: string;
  certificateUrl?: string;
  trainingMaterialRef?: string;
  
  // Effectiveness - ISO 13485:7.3.1
  effectivenessCriteria?: string;
  effectivenessEvaluation?: 'Effective' | 'Needs Improvement' | 'Not Effective';
  effectivenessComments?: string;
  
  // Verification and validation
  verifiedBy?: string;
  verificationDate?: string;
  approvalStatus?: 'Pending' | 'Approved' | 'Rejected';
  approvedBy?: string;
  approvalDate?: string;
  
  // Links to other modules
  linkedCAPAId?: string;
  linkedAuditId?: string;
  
  // Metadata
  created_by?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Risk {
  id: string;
  
  // ISO 14971 - Risk Identification
  riskId: string;
  title: string;
  description: string;
  
  // ISO 14971:2019 - Risk Analysis
  // Product Information
  deviceName?: string;
  deviceClass?: 'Class I' | 'Class IIa' | 'Class IIb' | 'Class III';
  intendedUse?: string;
  intendedUser?: string;
  useEnvironment?: string;
  
  // Hazard Identification - ISO 14971:2019 Clause 5.3
  hazardIdentification?: string;
  hazard: string;
  hazardousSituation?: string;
  harm: string;
  harmSeverity?: 1 | 2 | 3 | 4 | 5;
  harmSeverityClassification?: 'Negligible' | 'Minor' | 'Serious' | 'Critical' | 'Catastrophic';
  
  // Risk Estimation - ISO 14971:2019 Clause 5.4
  severity: 1 | 2 | 3 | 4 | 5;
  probability: 1 | 2 | 3 | 4 | 5;
  detectability: 1 | 2 | 3 | 4 | 5;
  initialRPN?: number; // Risk Priority Number
  riskLevel: 'Acceptable' | 'ALARP' | 'Unacceptable';
  
  // Category
  category: 'Design' | 'Manufacturing' | 'Use/Misuse' | 'Environmental' | 'Regulatory' | 'Software' | 'Biological' | 'Supplier';
  
  // Risk Evaluation - ISO 14971:2019 Clause 5.5
  riskAcceptabilityCriteria?: string;
  riskBenefitAnalysis?: string;
  
  // Risk Control - ISO 14971:2019 Clause 7
  mitigationMeasures: string;
  riskControlMeasures?: string[];
  riskControlOption?: 'Inherently Safe Design' | 'Protective Measure' | 'Information for Safety';
  
  // Residual Risk - ISO 14971:2019 Clause 7.6
  residualSeverity: 1 | 2 | 3 | 4 | 5;
  residualProbability: 1 | 2 | 3 | 4 | 5;
  residualDetectability?: 1 | 2 | 3 | 4 | 5;
  residualRPN?: number;
  residualRiskLevel: 'Acceptable' | 'ALARP' | 'Unacceptable';
  
  // Risk Review and Monitoring - ISO 14971:2019 Clause 10
  status: 'Open' | 'Analysis' | 'Mitigation' | 'Verification' | 'Accepted' | 'Closed';
  owner: string;
  reviewFrequency?: string;
  lastReviewed: string;
  nextReview?: string;
  
  // Verification of Risk Control Measures - ISO 14971:2019 Clause 7.5
  verificationMethod?: string;
  verificationDate?: string;
  verifiedBy?: string;
  verificationEvidence?: string;
  
  // Production and Post-Production - ISO 14971:2019 Clause 9
  feedbackSource?: string;
  fieldSafetyIssue?: string;
  trendAnalysis?: string;
  
  // FMEA specific fields
  failureMode?: string;
  failureEffect?: string;
  failureCause?: string;
  detectionMethod?: string;
  
  // Documentation - ISO 14971:2019 Clause 8
  riskAnalysisReport?: string;
  riskManagementFile?: string;
  
  // Links to other modules
  linkedCAPAId?: string;
  linkedDeviationId?: string;
  linkedDocumentId?: string;
  
  // Dates
  createdDate: string;
  closedDate?: string;
  dueDate?: string;
  
  // Metadata
  created_by?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Employee {
  id: string;
  name: string;
  email: string;
  department: string;
  role: string;
  hireDate: string;
  trainings: TrainingRecord[];
}

export interface KPIData {
  label: string;
  value: number;
  target: number;
  trend: 'up' | 'down' | 'stable';
  unit?: string;
}

export interface AuditFinding {
  id: string;
  auditId: string;
  findingNumber: string;
  type: 'Major NC' | 'Minor NC' | 'Observation' | 'Opportunity for Improvement';
  clause: string;
  description: string;
  evidence: string;
  status: 'Open' | 'In Progress' | 'Closed';
  dueDate: string;
  assignedTo: string;
}

export type ViewType = 'dashboard' | 'documents' | 'capa' | 'audits' | 'ncr' | 'training' | 'risk' | 'reports' | 'compliance' | 'change_control' | 'deviation' | 'users';

// ============================================
// CHANGE CONTROL TYPES (ISO 13485 §7.3.9)
// ============================================

export type ChangeType = 'PROCESS' | 'DOCUMENT' | 'DESIGN' | 'SUPPLIER' | 'EQUIPMENT' | 'SOFTWARE' | 'MATERIAL';
export type ChangePriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'EMERGENCY';
export type ChangeStatus = 'DRAFT' | 'IMPACT_ANALYSIS' | 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED' | 'IMPLEMENTATION' | 'VERIFICATION' | 'CLOSED';
export type ImpactArea = 'QUALITY' | 'REGULATORY' | 'SAFETY' | 'OPERATIONS' | 'SUPPLY_CHAIN' | 'DOCUMENTATION' | 'TRAINING';
export type ImpactRiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface ChangeControl {
  id: string;
  title: string;
  description?: string;
  changeType: ChangeType;
  priority: ChangePriority;
  status: ChangeStatus;
  initiatorId?: string;
  currentAssigneeId?: string;
  justification?: string;
  affectedSystems?: string;
  riskAssessmentSummary?: string;
  implementationPlan?: ImplementationTask[];
  impactAnalysisCompleted: boolean;
  approvalRequiredFrom?: string;
  approvedBy?: string;
  approvedAt?: string;
  implementationStartDate?: string;
  implementationCompletionDate?: string;
  effectivenessVerified: boolean;
  verificationNotes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ImplementationTask {
  id: string;
  task: string;
  assigneeId?: string;
  dueDate?: string;
  completed: boolean;
  completedAt?: string;
}

export interface ChangeControlImpact {
  id: string;
  changeControlId: string;
  impactArea: ImpactArea;
  impactDescription?: string;
  riskLevel?: ImpactRiskLevel;
  mitigationPlan?: string;
  assessedBy?: string;
  assessedAt?: string;
}

export interface ChangeControlApproval {
  id: string;
  changeControlId: string;
  approverId?: string;
  approvalOrder: number;
  role?: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'N/A';
  comments?: string;
  signedAt?: string;
  signatureHash?: string;
}

// ============================================
// DEVIATION TYPES (ISO 13485 §8.3)
// ============================================

export type DeviationSeverity = 'MINOR' | 'MAJOR' | 'CRITICAL';
export type DeviationDetectability = 'HIGH' | 'MEDIUM' | 'LOW';
export type DeviationDisposition = 'USE_AS_IS' | 'REWORK' | 'REPAIR' | 'SCRAP' | 'RETURN_TO_VENDOR' | 'CONCESSION';
export type DeviationStatus = 'OPEN' | 'UNDER_INVESTIGATION' | 'QA_REVIEW' | 'PENDING_DISPOSITION' | 'CLOSED' | 'REJECTED';

export interface Deviation {
  id: string;
  referenceNumber: string;
  title: string;
  occurrenceDate: string;
  identifiedById?: string;
  descriptionOfEvent: string;
  immediateActionTaken?: string;
  rootCauseAnalysis?: string;
  fiveWhys?: string[];
  fishboneDiagram?: Record<string, string>;
  impactAssessment?: string;
  severity: DeviationSeverity;
  detectability?: DeviationDetectability;
  riskPriorityNumber?: number;
  disposition?: DeviationDisposition;
  dispositionJustification?: string;
  dispositionApprovedBy?: string;
  dispositionApprovedAt?: string;
  capaRequired: boolean;
  linkedCapaId?: string;
  status: DeviationStatus;
  investigationCompleted: boolean;
  productQuarantined: boolean;
  quarantineLotNumber?: string;
  createdAt: string;
  updatedAt?: string;
  closedAt?: string;
}

export interface DeviationCategory {
  id: string;
  name: string;
  description?: string;
  isActive: boolean;
}

// ============================================
// ELECTRONIC SIGNATURES (21 CFR Part 11)
// ============================================

export type ModuleType = 'CHANGE_CONTROL' | 'DEVIATION' | 'CAPA' | 'AUDIT' | 'DOCUMENT';

export interface ElectronicSignature {
  id: string;
  moduleType: ModuleType;
  recordId: string;
  userId: string;
  role: string;
  meaning: string;
  signatureHash: string;
  signedAt: string;
  isValid: boolean;
  supersededBy?: string;
}

// ============================================
// AUDIT TRAIL (21 CFR Part 11)
// ============================================

export interface AuditTrailEntry {
  id: string;
  moduleType: ModuleType;
  recordId: string;
  fieldName: string;
  oldValue?: string;
  newValue?: string;
  changeReason?: string;
  userId?: string;
  timestamp: string;
}
