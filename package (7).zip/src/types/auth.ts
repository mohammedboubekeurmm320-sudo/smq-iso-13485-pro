export type UserRole = 'admin' | 'quality_manager' | 'auditor' | 'document_controller' | 'executive' | 'operator';

export interface UserProfile {
  id: string;
  email: string;
  full_name: string | null;
  role: UserRole;
  department: string | null;
  job_title: string | null;
  phone: string | null;
  avatar_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface Permission {
  canApproveDocuments: boolean;
  canCreateDocuments: boolean;
  canEditDocuments: boolean;
  canDeleteDocuments: boolean;
  canCloseCAPAs: boolean;
  canCreateCAPAs: boolean;
  canEditCAPAs: boolean;
  canCreateAuditFindings: boolean;
  canScheduleAudits: boolean;
  canCreateNCRs: boolean;
  canSetDisposition: boolean;
  canManageTraining: boolean;
  canManageRisks: boolean;
  canViewReports: boolean;
  canExportData: boolean;
  canManageUsers: boolean;
  // Document visibility by status (ISO 13485 compliance)
  canViewDraftDocuments: boolean;
  canViewInReviewDocuments: boolean;
  canViewApprovedDocuments: boolean;
  canViewObsoleteDocuments: boolean;
}

export const rolePermissions: Record<UserRole, Permission> = {
  admin: {
    canApproveDocuments: true,
    canCreateDocuments: true,
    canEditDocuments: true,
    canDeleteDocuments: true,
    canCloseCAPAs: true,
    canCreateCAPAs: true,
    canEditCAPAs: true,
    canCreateAuditFindings: true,
    canScheduleAudits: true,
    canCreateNCRs: true,
    canSetDisposition: true,
    canManageTraining: true,
    canManageRisks: true,
    canViewReports: true,
    canExportData: true,
    canManageUsers: true,
    // Full visibility - ISO 13485 compliance
    canViewDraftDocuments: true,
    canViewInReviewDocuments: true,
    canViewApprovedDocuments: true,
    canViewObsoleteDocuments: true,
  },
  quality_manager: {
    canApproveDocuments: true,
    canCreateDocuments: true,
    canEditDocuments: true,
    canDeleteDocuments: true,
    canCloseCAPAs: true,
    canCreateCAPAs: true,
    canEditCAPAs: true,
    canCreateAuditFindings: true,
    canScheduleAudits: true,
    canCreateNCRs: true,
    canSetDisposition: true,
    canManageTraining: true,
    canManageRisks: true,
    canViewReports: true,
    canExportData: true,
    canManageUsers: true,
    // Full visibility for workflow management
    canViewDraftDocuments: true,
    canViewInReviewDocuments: true,
    canViewApprovedDocuments: true,
    canViewObsoleteDocuments: true,
  },
  executive: {
    canApproveDocuments: true,
    canCreateDocuments: false,
    canEditDocuments: false,
    canDeleteDocuments: false,
    canCloseCAPAs: true,
    canCreateCAPAs: false,
    canEditCAPAs: false,
    canCreateAuditFindings: false,
    canScheduleAudits: false,
    canCreateNCRs: false,
    canSetDisposition: true,
    canManageTraining: false,
    canManageRisks: true,
    canViewReports: true,
    canExportData: true,
    canManageUsers: true,
    // Executives see approved and obsolete (historical) documents
    canViewDraftDocuments: false,
    canViewInReviewDocuments: false,
    canViewApprovedDocuments: true,
    canViewObsoleteDocuments: true,
  },
  auditor: {
    canApproveDocuments: false,
    canCreateDocuments: false,
    canEditDocuments: false,
    canDeleteDocuments: false,
    canCloseCAPAs: false,
    canCreateCAPAs: true,
    canEditCAPAs: true,
    canCreateAuditFindings: true,
    canScheduleAudits: true,
    canCreateNCRs: true,
    canSetDisposition: false,
    canManageTraining: false,
    canManageRisks: true,
    canViewReports: true,
    canExportData: true,
    canManageUsers: false,
    // Auditors see approved and obsolete for historical reference
    canViewDraftDocuments: false,
    canViewInReviewDocuments: false,
    canViewApprovedDocuments: true,
    canViewObsoleteDocuments: true,
  },
  document_controller: {
    canApproveDocuments: false,
    canCreateDocuments: true,
    canEditDocuments: true,
    canDeleteDocuments: false,
    canCloseCAPAs: false,
    canCreateCAPAs: false,
    canEditCAPAs: false,
    canCreateAuditFindings: false,
    canScheduleAudits: false,
    canCreateNCRs: false,
    canSetDisposition: false,
    canManageTraining: true,
    canManageRisks: false,
    canViewReports: true,
    canExportData: true,
    canManageUsers: false,
    // Document controllers manage the full workflow
    canViewDraftDocuments: true,
    canViewInReviewDocuments: true,
    canViewApprovedDocuments: true,
    canViewObsoleteDocuments: true,
  },
  operator: {
    canApproveDocuments: false,
    canCreateDocuments: false,
    canEditDocuments: false,
    canDeleteDocuments: false,
    canCloseCAPAs: false,
    canCreateCAPAs: false,
    canEditCAPAs: false,
    canCreateAuditFindings: false,
    canScheduleAudits: false,
    canCreateNCRs: false,
    canSetDisposition: false,
    canManageTraining: false,
    canManageRisks: false,
    canViewReports: true,
    canExportData: false,
    canManageUsers: false,
    // Operators only see approved documents (active procedures)
    canViewDraftDocuments: false,
    canViewInReviewDocuments: false,
    canViewApprovedDocuments: true,
    canViewObsoleteDocuments: false,
  },
};

export const roleLabels: Record<UserRole, string> = {
  admin: 'Administrator',
  quality_manager: 'Quality Manager',
  executive: 'Executive',
  auditor: 'Auditor',
  document_controller: 'Document Controller',
  operator: 'Operator',
};

export const roleDescriptions: Record<UserRole, string> = {
  admin: 'Full system access including user management and settings',
  quality_manager: 'Full access to all QMS functions including user management',
  executive: 'View reports, approve documents, and manage strategic decisions',
  auditor: 'Create audit findings, schedule audits, and manage CAPAs',
  document_controller: 'Manage document workflows and training records',
  operator: 'Read-only access to documents and procedures',
};
