import { describe, it, expect } from 'vitest';
import { 
  formatDate, 
  generateDocumentNumber, 
  calculateRiskLevel,
  validateEmail,
  hashString 
} from '../lib/utils';

describe('utils', () => {
  describe('formatDate', () => {
    it('should format date correctly', () => {
      const date = '2024-01-15T10:30:00Z';
      const formatted = formatDate(date);
      expect(formatted).toContain('2024');
    });

    it('should handle invalid dates', () => {
      const formatted = formatDate('invalid-date');
      expect(formatted).toBe('Invalid Date');
    });
  });

  describe('generateDocumentNumber', () => {
    it('should generate document number with prefix', () => {
      const docNumber = generateDocumentNumber('SOP', 'org-1');
      expect(docNumber).toMatch(/^SOP-\d{4}-\d+$/);
    });

    it('should generate unique document numbers', () => {
      const doc1 = generateDocumentNumber('WI', 'org-1');
      const doc2 = generateDocumentNumber('WI', 'org-1');
      // Numbers should be different (timestamp-based)
      expect(doc1).not.toBe(doc2);
    });
  });

  describe('calculateRiskLevel', () => {
    it('should return Acceptable for low risk', () => {
      expect(calculateRiskLevel(1, 1)).toBe('Acceptable');
      expect(calculateRiskLevel(2, 1)).toBe('Acceptable');
      expect(calculateRiskLevel(1, 2)).toBe('Acceptable');
    });

    it('should return Unacceptable for high risk', () => {
      expect(calculateRiskLevel(5, 5)).toBe('Unacceptable');
      expect(calculateRiskLevel(5, 4)).toBe('Unacceptable');
      expect(calculateRiskLevel(4, 5)).toBe('Unacceptable');
    });

    it('should return ALARP for medium risk', () => {
      expect(calculateRiskLevel(3, 3)).toBe('ALARP');
      expect(calculateRiskLevel(4, 3)).toBe('ALARP');
      expect(calculateRiskLevel(3, 4)).toBe('ALARP');
    });
  });

  describe('validateEmail', () => {
    it('should validate correct email formats', () => {
      expect(validateEmail('test@example.com')).toBe(true);
      expect(validateEmail('user.name@domain.org')).toBe(true);
      expect(validateEmail('user+tag@domain.co.uk')).toBe(true);
    });

    it('should reject invalid email formats', () => {
      expect(validateEmail('invalid')).toBe(false);
      expect(validateEmail('@example.com')).toBe(false);
      expect(validateEmail('test@')).toBe(false);
      expect(validateEmail('')).toBe(false);
    });
  });

  describe('hashString', () => {
    it('should generate consistent hash for same input', () => {
      const hash1 = hashString('test-string');
      const hash2 = hashString('test-string');
      expect(hash1).toBe(hash2);
    });

    it('should generate different hash for different input', () => {
      const hash1 = hashString('test-1');
      const hash2 = hashString('test-2');
      expect(hash1).not.toBe(hash2);
    });

    it('should return 64-character hex string', () => {
      const hash = hashString('test');
      expect(hash).toMatch(/^[a-f0-9]{64}$/);
    });
  });
});
