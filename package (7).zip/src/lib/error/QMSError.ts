// QMSError - Hiérarchie d'erreurs pour le système QMS
// Conforme aux exigences ISO 13485 pour la traçabilité des erreurs

// Enum pour la sévérité des erreurs
export enum ErrorSeverity {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high',
  CRITICAL = 'critical',
}

// Enum pour la catégorie d'erreurs
export enum ErrorCategory {
  NETWORK = 'network',
  AUTH = 'auth',
  VALIDATION = 'validation',
  DATABASE = 'database',
  COMPLIANCE = 'compliance',
  UNKNOWN = 'unknown',
}

// Interface pour les options d'erreur
export interface QMSErrorOptions {
  code?: string;
  severity?: ErrorSeverity;
  category?: ErrorCategory;
  userMessage?: string;
  retryable?: boolean;
  details?: Record<string, any>;
  originalError?: Error;
}

// Classe de base QMSError
export class QMSError extends Error {
  public readonly code: string;
  public readonly severity: ErrorSeverity;
  public readonly category: ErrorCategory;
  public readonly userMessage: string;
  public readonly retryable: boolean;
  public readonly details: Record<string, any>;
  public readonly originalError?: Error;
  public readonly timestamp: Date;

  constructor(
    message: string,
    options: QMSErrorOptions = {}
  ) {
    super(message);
    this.name = 'QMSError';
    this.code = options.code || 'QMS_ERROR';
    this.severity = options.severity || ErrorSeverity.MEDIUM;
    this.category = options.category || ErrorCategory.UNKNOWN;
    this.userMessage = options.userMessage || message;
    this.retryable = options.retryable || false;
    this.details = options.details || {};
    this.originalError = options.originalError;
    this.timestamp = new Date();

    // Capture de la stack trace
    Error.captureStackTrace(this, this.constructor);
  }

  // Sérialisation pour logging
  toJSON() {
    return {
      name: this.name,
      message: this.message,
      code: this.code,
      severity: this.severity,
      category: this.category,
      userMessage: this.userMessage,
      retryable: this.retryable,
      details: this.details,
      timestamp: this.timestamp.toISOString(),
      stack: this.stack,
    };
  }
}

// Erreur réseau (problèmes de connectivité)
export class NetworkError extends QMSError {
  constructor(message: string, options: QMSErrorOptions = {}) {
    super(message, {
      ...options,
      code: options.code || 'NETWORK_ERROR',
      category: ErrorCategory.NETWORK,
      severity: options.severity || ErrorSeverity.HIGH,
      retryable: options.retryable !== undefined ? options.retryable : true,
    });
    this.name = 'NetworkError';
  }
}

// Erreur d'authentification
export class AuthError extends QMSError {
  constructor(message: string, options: QMSErrorOptions = {}) {
    super(message, {
      ...options,
      code: options.code || 'AUTH_ERROR',
      category: ErrorCategory.AUTH,
      severity: ErrorSeverity.HIGH,
      retryable: false,
    });
    this.name = 'AuthError';
  }
}

// Erreur de validation des données
export class ValidationError extends QMSError {
  public readonly validationErrors: Record<string, string[]>;

  constructor(
    message: string,
    validationErrors: Record<string, string[]> = {},
    options: QMSErrorOptions = {}
  ) {
    super(message, {
      ...options,
      code: options.code || 'VALIDATION_ERROR',
      category: ErrorCategory.VALIDATION,
      severity: ErrorSeverity.MEDIUM,
      retryable: false,
      details: {
        ...options.details,
        validationErrors,
      },
    });
    this.name = 'ValidationError';
    this.validationErrors = validationErrors;
  }
}

// Erreur de base de données
export class DatabaseError extends QMSError {
  constructor(message: string, options: QMSErrorOptions = {}) {
    super(message, {
      ...options,
      code: options.code || 'DATABASE_ERROR',
      category: ErrorCategory.DATABASE,
      severity: ErrorSeverity.CRITICAL,
      retryable: options.retryable !== undefined ? options.retryable : false,
    });
    this.name = 'DatabaseError';
  }
}

// Erreur de conformité (règles métier ISO 13485)
export class ComplianceError extends QMSError {
  constructor(message: string, options: QMSErrorOptions = {}) {
    super(message, {
      ...options,
      code: options.code || 'COMPLIANCE_ERROR',
      category: ErrorCategory.COMPLIANCE,
      severity: ErrorSeverity.CRITICAL,
      retryable: false,
    });
    this.name = 'ComplianceError';
  }
}

// Factory pour créer des erreurs depuis des erreurs Supabase
export const handleSupabaseError = (error: any, context?: string): QMSError => {
  const message = error?.message || 'An unexpected database error occurred';
  
  // Mapper les codes d'erreur Supabase vers nos types
  if (error?.code === 'PGRST301' || error?.code === '42501') {
    // Row Level Security violation
    return new AuthError(`Access denied: ${message}`, {
      code: 'RLS_VIOLATION',
      details: { context, supabaseCode: error.code },
      originalError: error,
    });
  }

  if (error?.code === '23505') {
    // Contrainte unique violée
    return new ValidationError(`Duplicate entry: ${message}`, {
      code: 'DUPLICATE_ENTRY',
      details: { constraint: error.code, context },
      originalError: error,
    });
  }

  if (error?.code === '23503') {
    // Clé étrangère violée
    return new DatabaseError(`Referenced record not found: ${message}`, {
      code: 'FOREIGN_KEY_VIOLATION',
      details: { constraint: error.code, context },
      originalError: error,
    });
  }

  if (error?.status === 401) {
    return new AuthError('Session expired. Please log in again.', {
      code: 'SESSION_EXPIRED',
      originalError: error,
    });
  }

  if (error?.status === 403) {
    return new AuthError('You do not have permission to perform this action.', {
      code: 'FORBIDDEN',
      originalError: error,
    });
  }

  if (error?.status >= 500) {
    return new DatabaseError('Server error. Please try again later.', {
      code: 'SERVER_ERROR',
      retryable: true,
      originalError: error,
    });
  }

  // Erreur inconnue
  return new QMSError(message, {
    code: 'UNKNOWN_ERROR',
    details: { context, supabaseError: error },
    originalError: error,
  });
};

// Handler générique pour afficher les erreurs
export const handleError = (
  error: Error | QMSError,
  options: {
    showToast?: boolean;
    logToSentry?: boolean;
    additionalContext?: Record<string, any>;
  } = {}
) => {
  const { showToast = true, logToSentry = true, additionalContext = {} } = options;

  // Logger dans la console en développement
  if (process.env.NODE_ENV === 'development') {
    console.error('[QMS Error]:', error);
  }

  // Logger vers Sentry en production
  if (logToSentry && typeof window !== 'undefined') {
    const sentry = (window as any).Sentry;
    if (sentry) {
      sentry.captureException(error, {
        extra: {
          ...additionalContext,
          errorType: error.constructor.name,
          timestamp: new Date().toISOString(),
        },
      });
    }
  }

  // Toast notification (sera appelé depuis le composant)
  return error;
};

export default QMSError;
