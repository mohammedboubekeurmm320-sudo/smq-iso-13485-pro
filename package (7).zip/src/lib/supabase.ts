import { createClient } from '@supabase/supabase-js';

// Get Supabase configuration from environment variables
// IMPORTANT: For production, set these in Netlify dashboard
// VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY must be configured
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Validate that required environment variables are set
if (!supabaseUrl || !supabaseKey) {
  console.error('Missing Supabase environment variables!');
  console.error('Please set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY');
}

const supabase = createClient(supabaseUrl || '', supabaseKey || '');

export { supabase };
