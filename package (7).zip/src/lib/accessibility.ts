// Accessibility utilities for improved keyboard navigation and screen reader support

/**
 * Keyboard navigation utilities
 */

// Focus trap for modals and dialogs
export const trapFocus = (containerRef: React.RefObject<HTMLElement>) => {
  const focusableElements = containerRef.current?.querySelectorAll(
    'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
  );
  
  if (!focusableElements || focusableElements.length === 0) return;
  
  const firstElement = focusableElements[0] as HTMLElement;
  const lastElement = focusableElements[focusableElements.length - 1] as HTMLElement;
  
  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key !== 'Tab') return;
    
    if (e.shiftKey) {
      if (document.activeElement === firstElement) {
        e.preventDefault();
        lastElement.focus();
      }
    } else {
      if (document.activeElement === lastElement) {
        e.preventDefault();
        firstElement.focus();
      }
    }
  };
  
  document.addEventListener('keydown', handleKeyDown);
  
  return () => {
    document.removeEventListener('keydown', handleKeyDown);
  };
};

// Close on escape key
export const useEscapeKey = (callback: () => void) => {
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        callback();
      }
    };
    
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [callback]);
};

import React from 'react';

// Skip link for keyboard navigation
export const SkipLink: React.FC<{ targetId: string; children: React.ReactNode }> = ({
  targetId,
  children,
}) => (
  <a
    href={`#${targetId}`}
    className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:px-4 focus:py-2 focus:bg-blue-600 focus:text-white focus:rounded-lg focus:outline-none"
  >
    {children}
  </a>
);

// Live region for screen reader announcements
export const LiveRegion: React.FC<{ message: string; politeness?: 'polite' | 'assertive' }> = ({
  message,
  politeness = 'polite',
}) => (
  <div
    role="status"
    aria-live={politeness}
    aria-atomic="true"
    className="sr-only"
  >
    {message}
  </div>
);

// Focus indicator styles
export const focusVisibleStyles = `
  focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2
`;

// Improved button with focus indicators
export const AccessibleButton: React.FC<React.ButtonHTMLAttributes<HTMLButtonElement>> = ({
  className = '',
  ...props
}) => (
  <button
    className={`${focusVisibleStyles} ${className}`}
    {...props}
  />
);

// Improved link with focus indicators
export const AccessibleLink: React.FC<React.AnchorHTMLAttributes<HTMLAnchorElement>> = ({
  className = '',
  ...props
}) => (
  <a
    className={`${focusVisibleStyles} ${className}`}
    {...props}
  />
);
