import React, { useState } from 'react';
import { useSubscription } from '@/hooks/useSubscription';
import PricingTable from '@/components/billing/PricingTable';
import SubscriptionStatus from '@/components/billing/SubscriptionStatus';
import InvoiceHistory from '@/components/billing/InvoiceHistory';
import { Loader2, CreditCard, Settings, AlertCircle } from 'lucide-react';

const BillingPage: React.FC = () => {
  const { 
    subscription, 
    plans, 
    invoices, 
    isLoading, 
    error,
    createCheckoutSession,
    createPortalSession,
    cancelSubscription,
    updateSubscription,
  } = useSubscription();
  
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSelectPlan = async (plan: any, billingCycle: 'monthly' | 'yearly') => {
    if (plan.id === 'enterprise') {
      // Redirect to contact page or open modal
      window.location.href = 'mailto:sales@iso13485.com?subject=Enterprise Plan Inquiry';
      return;
    }

    setIsProcessing(true);
    try {
      if (subscription) {
        // Update existing subscription
        await updateSubscription(plan.id);
      } else {
        // Create new subscription
        const url = await createCheckoutSession(plan.id, billingCycle);
        window.location.href = url;
      }
    } catch (err: any) {
      console.error('Error:', err);
      alert(err.message || 'Failed to process subscription');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleManageBilling = async () => {
    try {
      const url = await createPortalSession();
      window.location.href = url;
    } catch (err: any) {
      console.error('Error:', err);
      alert(err.message || 'Failed to open billing portal');
    }
  };

  const handleCancelSubscription = async () => {
    if (!confirm('Are you sure you want to cancel your subscription? You will lose access to premium features at the end of your billing period.')) {
      return;
    }

    setIsProcessing(true);
    try {
      await cancelSubscription();
    } catch (err: any) {
      console.error('Error:', err);
      alert(err.message || 'Failed to cancel subscription');
    } finally {
      setIsProcessing(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="p-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Billing & Subscription</h1>
        <p className="text-gray-500 mt-1">Manage your subscription and billing information</p>
      </div>

      {/* Error Alert */}
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-red-800">{error}</p>
          </div>
        </div>
      )}

      {/* Current Subscription Status */}
      {subscription && (
        <div className="mb-8">
          <SubscriptionStatus
            status={subscription.status}
            planName={subscription.plan?.name || 'Unknown Plan'}
            currentPeriodEnd={subscription.current_period_end || undefined}
            trialEnd={subscription.trial_end || undefined}
            cancelAtPeriodEnd={subscription.cancel_at_period_end}
            onManageBilling={handleManageBilling}
          />

          {/* Cancel Button */}
          {subscription.status === 'active' && !subscription.cancel_at_period_end && (
            <div className="mt-4 flex justify-end">
              <button
                onClick={handleCancelSubscription}
                disabled={isProcessing}
                className="text-sm text-red-600 hover:text-red-700 font-medium"
              >
                {isProcessing ? 'Processing...' : 'Cancel Subscription'}
              </button>
            </div>
          )}
        </div>
      )}

      {/* Pricing Table */}
      <div className="mb-12">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Choose Your Plan</h2>
        <PricingTable
          plans={plans.map(plan => ({
            ...plan,
            is_popular: plan.id === 'professional',
            features: plan.features || [],
          }))}
          currentPlanId={subscription?.plan_id}
          onSelectPlan={handleSelectPlan}
          isLoading={isProcessing}
        />
      </div>

      {/* Invoice History */}
      <div>
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Invoice History</h2>
        <InvoiceHistory
          invoices={invoices}
          isLoading={isLoading}
          onDownloadPDF={(invoice) => {
            if (invoice.pdf_url) {
              window.open(invoice.pdf_url, '_blank');
            }
          }}
        />
      </div>
    </div>
  );
};

export default BillingPage;
