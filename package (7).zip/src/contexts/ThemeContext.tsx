import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

export type ThemeMode = 'light' | 'dark' | 'high-contrast';

export interface ThemeColors {
  background: string;
  foreground: string;
  primary: string;
  primaryForeground: string;
  secondary: string;
  secondaryForeground: string;
  muted: string;
  mutedForeground: string;
  accent: string;
  accentForeground: string;
  border: string;
  input: string;
  ring: string;
  error: string;
  errorForeground: string;
  success: string;
  warning: string;
  card: string;
  cardForeground: string;
  popover: string;
  popoverForeground: string;
}

export interface Theme {
  mode: ThemeMode;
  name: string;
  colors: ThemeColors;
}

const themes: Record<ThemeMode, Theme> = {
  light: {
    mode: 'light',
    name: 'Light',
    colors: {
      background: '#f9fafb',
      foreground: '#111827',
      primary: '#2563eb',
      primaryForeground: '#ffffff',
      secondary: '#f3f4f6',
      secondaryForeground: '#1f2937',
      muted: '#f3f4f6',
      mutedForeground: '#6b7280',
      accent: '#eff6ff',
      accentForeground: '#2563eb',
      border: '#e5e7eb',
      input: '#e5e7eb',
      ring: '#2563eb',
      error: '#ef4444',
      errorForeground: '#ffffff',
      success: '#22c55e',
      warning: '#f59e0b',
      card: '#ffffff',
      cardForeground: '#111827',
      popover: '#ffffff',
      popoverForeground: '#111827',
    },
  },
  dark: {
    mode: 'dark',
    name: 'Dark',
    colors: {
      background: '#111827',
      foreground: '#f9fafb',
      primary: '#3b82f6',
      primaryForeground: '#ffffff',
      secondary: '#1f2937',
      secondaryForeground: '#f9fafb',
      muted: '#1f2937',
      mutedForeground: '#9ca3af',
      accent: '#1e3a8a',
      accentForeground: '#3b82f6',
      border: '#374151',
      input: '#374151',
      ring: '#3b82f6',
      error: '#f87171',
      errorForeground: '#7f1d1d',
      success: '#4ade80',
      warning: '#fbbf24',
      card: '#1f2937',
      cardForeground: '#f9fafb',
      popover: '#1f2937',
      popoverForeground: '#f9fafb',
    },
  },
  'high-contrast': {
    mode: 'high-contrast',
    name: 'High Contrast',
    colors: {
      background: '#000000',
      foreground: '#ffffff',
      primary: '#ffff00',
      primaryForeground: '#000000',
      secondary: '#1a1a1a',
      secondaryForeground: '#ffffff',
      muted: '#1a1a1a',
      mutedForeground: '#cccccc',
      accent: '#003300',
      accentForeground: '#00ff00',
      border: '#ffffff',
      input: '#ffffff',
      ring: '#ffff00',
      error: '#ff0000',
      errorForeground: '#ffffff',
      success: '#00ff00',
      warning: '#ffff00',
      card: '#000000',
      cardForeground: '#ffffff',
      popover: '#000000',
      popoverForeground: '#ffffff',
    },
  },
};

interface ThemeContextType {
  theme: Theme;
  themeMode: ThemeMode;
  setThemeMode: (mode: ThemeMode) => void;
  toggleTheme: () => void;
  colors: ThemeColors;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

const STORAGE_KEY = 'qms_theme_mode';

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [themeMode, setThemeModeState] = useState<ThemeMode>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored && (stored === 'light' || stored === 'dark' || stored === 'high-contrast')) {
        return stored;
      }
    }
    return 'light';
  });

  const theme = themes[themeMode];
  const colors = theme.colors;

  const setThemeMode = useCallback((mode: ThemeMode) => {
    setThemeModeState(mode);
    localStorage.setItem(STORAGE_KEY, mode);
  }, []);

  const toggleTheme = useCallback(() => {
    const modes: ThemeMode[] = ['light', 'dark', 'high-contrast'];
    const currentIndex = modes.indexOf(themeMode);
    const nextIndex = (currentIndex + 1) % modes.length;
    setThemeMode(modes[nextIndex]);
  }, [themeMode, setThemeMode]);

  // Apply theme to document
  useEffect(() => {
    const root = document.documentElement;
    
    // Set CSS variables
    root.style.setProperty('--background', colors.background);
    root.style.setProperty('--foreground', colors.foreground);
    root.style.setProperty('--primary', colors.primary);
    root.style.setProperty('--primary-foreground', colors.primaryForeground);
    root.style.setProperty('--secondary', colors.secondary);
    root.style.setProperty('--secondary-foreground', colors.secondaryForeground);
    root.style.setProperty('--muted', colors.muted);
    root.style.setProperty('--muted-foreground', colors.mutedForeground);
    root.style.setProperty('--accent', colors.accent);
    root.style.setProperty('--accent-foreground', colors.accentForeground);
    root.style.setProperty('--border', colors.border);
    root.style.setProperty('--input', colors.input);
    root.style.setProperty('--ring', colors.ring);
    root.style.setProperty('--error', colors.error);
    root.style.setProperty('--error-foreground', colors.errorForeground);
    root.style.setProperty('--success', colors.success);
    root.style.setProperty('--warning', colors.warning);
    root.style.setProperty('--card', colors.card);
    root.style.setProperty('--card-foreground', colors.cardForeground);
    root.style.setProperty('--popover', colors.popover);
    root.style.setProperty('--popover-foreground', colors.popoverForeground);

    // Set data attribute for CSS selectors
    root.setAttribute('data-theme', themeMode);
    
    // Update body class for dark mode
    if (themeMode === 'dark') {
      document.body.classList.add('dark');
    } else {
      document.body.classList.remove('dark');
    }
  }, [colors, themeMode]);

  return (
    <ThemeContext.Provider value={{ theme, themeMode, setThemeMode, toggleTheme, colors }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

export { themes };
export default ThemeProvider;
