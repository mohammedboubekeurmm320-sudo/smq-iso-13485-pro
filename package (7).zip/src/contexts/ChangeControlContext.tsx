import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from './AuthContext';
import { ChangeControl, ChangeControlImpact, ChangeControlApproval, ChangeStatus, ChangePriority, ChangeType } from '@/types/qms';

interface ChangeControlContextType {
  changeControls: ChangeControl[];
  loading: boolean;
  error: string | null;
  fetchChangeControls: () => Promise<void>;
  getChangeControl: (id: string) => Promise<ChangeControl | null>;
  createChangeControl: (data: Partial<ChangeControl>) => Promise<ChangeControl | null>;
  updateChangeControl: (id: string, data: Partial<ChangeControl>) => Promise<void>;
  updateStatus: (id: string, status: ChangeStatus) => Promise<void>;
  deleteChangeControl: (id: string) => Promise<void>;
  getImpacts: (changeControlId: string) => Promise<ChangeControlImpact[]>;
  addImpact: (data: Partial<ChangeControlImpact>) => Promise<void>;
  updateImpact: (id: string, data: Partial<ChangeControlImpact>) => Promise<void>;
  getApprovals: (changeControlId: string) => Promise<ChangeControlApproval[]>;
  addApproval: (data: Partial<ChangeControlApproval>) => Promise<void>;
  approve: (approvalId: string, comments?: string) => Promise<void>;
}

const ChangeControlContext = createContext<ChangeControlContextType | undefined>(undefined);

export const useChangeControl = () => {
  const context = useContext(ChangeControlContext);
  if (!context) {
    throw new Error('useChangeControl must be used within a ChangeControlProvider');
  }
  return context;
};

export const ChangeControlProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [changeControls, setChangeControls] = useState<ChangeControl[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchChangeControls = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: fetchError } = await supabase
        .from('change_controls')
        .select('*')
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;

      const mapped = (data || []).map((row: any) => ({
        id: row.id,
        title: row.title,
        description: row.description,
        changeType: row.change_type as ChangeType,
        priority: row.priority as ChangePriority,
        status: row.status as ChangeStatus,
        initiatorId: row.initiator_id,
        currentAssigneeId: row.current_assignee_id,
        justification: row.justification,
        affectedSystems: row.affected_systems,
        riskAssessmentSummary: row.risk_assessment_summary,
        implementationPlan: row.implementation_plan || [],
        impactAnalysisCompleted: row.impact_analysis_completed || false,
        approvalRequiredFrom: row.approval_required_from,
        approvedBy: row.approved_by,
        approvedAt: row.approved_at,
        implementationStartDate: row.implementation_start_date,
        implementationCompletionDate: row.implementation_completion_date,
        effectivenessVerified: row.effectiveness_verified || false,
        verificationNotes: row.verification_notes,
        createdAt: row.created_at,
        updatedAt: row.updated_at,
      }));

      setChangeControls(mapped);
    } catch (err: any) {
      console.error('Error fetching change controls:', err);
      // Provide demo data if table doesn't exist
      setChangeControls(getDemoChangeControls());
    } finally {
      setLoading(false);
    }
  }, []);

  const getChangeControl = useCallback(async (id: string): Promise<ChangeControl | null> => {
    try {
      const { data, error } = await supabase
        .from('change_controls')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;

      return data ? {
        id: data.id,
        title: data.title,
        description: data.description,
        changeType: data.change_type as ChangeType,
        priority: data.priority as ChangePriority,
        status: data.status as ChangeStatus,
        initiatorId: data.initiator_id,
        currentAssigneeId: data.current_assignee_id,
        justification: data.justification,
        affectedSystems: data.affected_systems,
        riskAssessmentSummary: data.risk_assessment_summary,
        implementationPlan: data.implementation_plan || [],
        impactAnalysisCompleted: data.impact_analysis_completed || false,
        approvalRequiredFrom: data.approval_required_from,
        approvedBy: data.approved_by,
        approvedAt: data.approved_at,
        implementationStartDate: data.implementation_start_date,
        implementationCompletionDate: data.implementation_completion_date,
        effectivenessVerified: data.effectiveness_verified || false,
        verificationNotes: data.verification_notes,
        createdAt: data.created_at,
        updatedAt: data.updated_at,
      } : null;
    } catch (err) {
      console.error('Error fetching change control:', err);
      return getDemoChangeControls().find(cc => cc.id === id) || null;
    }
  }, []);

  const createChangeControl = useCallback(async (data: Partial<ChangeControl>): Promise<ChangeControl | null> => {
    try {
      const { data: result, error } = await supabase
        .from('change_controls')
        .insert({
          title: data.title,
          description: data.description,
          change_type: data.changeType,
          priority: data.priority || 'MEDIUM',
          status: 'DRAFT',
          initiator_id: user?.id,
          current_assignee_id: data.currentAssigneeId || user?.id,
          justification: data.justification,
          affected_systems: data.affectedSystems,
          risk_assessment_summary: data.riskAssessmentSummary,
          implementation_plan: data.implementationPlan || [],
        })
        .select()
        .single();

      if (error) throw error;

      await fetchChangeControls();
      return result ? {
        id: result.id,
        title: result.title,
        description: result.description,
        changeType: result.change_type,
        priority: result.priority,
        status: result.status,
        initiatorId: result.initiator_id,
        currentAssigneeId: result.current_assignee_id,
        createdAt: result.created_at,
        updatedAt: result.updated_at,
        impactAnalysisCompleted: false,
        effectivenessVerified: false,
      } : null;
    } catch (err) {
      console.error('Error creating change control:', err);
      // Return demo data
      const newDemo: ChangeControl = {
        id: `demo-cc-${Date.now()}`,
        title: data.title || 'New Change Request',
        description: data.description,
        changeType: data.changeType || 'PROCESS',
        priority: data.priority || 'MEDIUM',
        status: 'DRAFT',
        initiatorId: user?.id,
        currentAssigneeId: data.currentAssigneeId || user?.id,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        impactAnalysisCompleted: false,
        effectivenessVerified: false,
      };
      setChangeControls(prev => [newDemo, ...prev]);
      return newDemo;
    }
  }, [user, fetchChangeControls]);

  const updateChangeControl = useCallback(async (id: string, data: Partial<ChangeControl>) => {
    try {
      const updateObj: any = {};
      if (data.title !== undefined) updateObj.title = data.title;
      if (data.description !== undefined) updateObj.description = data.description;
      if (data.changeType !== undefined) updateObj.change_type = data.changeType;
      if (data.priority !== undefined) updateObj.priority = data.priority;
      if (data.status !== undefined) updateObj.status = data.status;
      if (data.justification !== undefined) updateObj.justification = data.justification;
      if (data.affectedSystems !== undefined) updateObj.affected_systems = data.affectedSystems;
      if (data.riskAssessmentSummary !== undefined) updateObj.risk_assessment_summary = data.riskAssessmentSummary;
      if (data.implementationPlan !== undefined) updateObj.implementation_plan = data.implementationPlan;
      if (data.impactAnalysisCompleted !== undefined) updateObj.impact_analysis_completed = data.impactAnalysisCompleted;
      if (data.effectivenessVerified !== undefined) updateObj.effectiveness_verified = data.effectivenessVerified;

      updateObj.updated_at = new Date().toISOString();

      const { error } = await supabase
        .from('change_controls')
        .update(updateObj)
        .eq('id', id);

      if (error) throw error;
      await fetchChangeControls();
    } catch (err) {
      console.error('Error updating change control:', err);
    }
  }, [fetchChangeControls]);

  const updateStatus = useCallback(async (id: string, status: ChangeStatus) => {
    await updateChangeControl(id, { status });
  }, [updateChangeControl]);

  const deleteChangeControl = useCallback(async (id: string) => {
    try {
      const { error } = await supabase
        .from('change_controls')
        .delete()
        .eq('id', id);

      if (error) throw error;
      await fetchChangeControls();
    } catch (err) {
      console.error('Error deleting change control:', err);
    }
  }, [fetchChangeControls]);

  const getImpacts = useCallback(async (changeControlId: string): Promise<ChangeControlImpact[]> => {
    try {
      const { data, error } = await supabase
        .from('change_control_impacts')
        .select('*')
        .eq('change_control_id', changeControlId);

      if (error) throw error;

      return (data || []).map((row: any) => ({
        id: row.id,
        changeControlId: row.change_control_id,
        impactArea: row.impact_area,
        impactDescription: row.impact_description,
        riskLevel: row.risk_level,
        mitigationPlan: row.mitigation_plan,
        assessedBy: row.assessed_by,
        assessedAt: row.assessed_at,
      }));
    } catch (err) {
      console.error('Error fetching impacts:', err);
      return [];
    }
  }, []);

  const addImpact = useCallback(async (data: Partial<ChangeControlImpact>) => {
    try {
      const { error } = await supabase
        .from('change_control_impacts')
        .insert({
          change_control_id: data.changeControlId,
          impact_area: data.impactArea,
          impact_description: data.impactDescription,
          risk_level: data.riskLevel,
          mitigation_plan: data.mitigationPlan,
          assessed_by: user?.id,
        });

      if (error) throw error;
    } catch (err) {
      console.error('Error adding impact:', err);
    }
  }, [user]);

  const updateImpact = useCallback(async (id: string, data: Partial<ChangeControlImpact>) => {
    try {
      const updateObj: any = {};
      if (data.impactDescription !== undefined) updateObj.impact_description = data.impactDescription;
      if (data.riskLevel !== undefined) updateObj.risk_level = data.riskLevel;
      if (data.mitigationPlan !== undefined) updateObj.mitigation_plan = data.mitigationPlan;

      const { error } = await supabase
        .from('change_control_impacts')
        .update(updateObj)
        .eq('id', id);

      if (error) throw error;
    } catch (err) {
      console.error('Error updating impact:', err);
    }
  }, []);

  const getApprovals = useCallback(async (changeControlId: string): Promise<ChangeControlApproval[]> => {
    try {
      const { data, error } = await supabase
        .from('change_control_approvals')
        .select('*')
        .eq('change_control_id', changeControlId)
        .order('approval_order', { ascending: true });

      if (error) throw error;

      return (data || []).map((row: any) => ({
        id: row.id,
        changeControlId: row.change_control_id,
        approverId: row.approver_id,
        approvalOrder: row.approval_order,
        role: row.role,
        status: row.status,
        comments: row.comments,
        signedAt: row.signed_at,
        signatureHash: row.signature_hash,
      }));
    } catch (err) {
      console.error('Error fetching approvals:', err);
      return [];
    }
  }, []);

  const addApproval = useCallback(async (data: Partial<ChangeControlApproval>) => {
    try {
      const { error } = await supabase
        .from('change_control_approvals')
        .insert({
          change_control_id: data.changeControlId,
          approver_id: data.approverId,
          approval_order: data.approvalOrder || 1,
          role: data.role,
          status: 'PENDING',
        });

      if (error) throw error;
    } catch (err) {
      console.error('Error adding approval:', err);
    }
  }, []);

  const approve = useCallback(async (approvalId: string, comments?: string) => {
    try {
      const signatureHash = `SIG-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

      const { error } = await supabase
        .from('change_control_approvals')
        .update({
          status: 'APPROVED',
          comments: comments,
          signed_at: new Date().toISOString(),
          signature_hash: signatureHash,
        })
        .eq('id', approvalId);

      if (error) throw error;
    } catch (err) {
      console.error('Error approving:', err);
    }
  }, []);

  useEffect(() => {
    fetchChangeControls();
  }, [fetchChangeControls]);

  return (
    <ChangeControlContext.Provider
      value={{
        changeControls,
        loading,
        error,
        fetchChangeControls,
        getChangeControl,
        createChangeControl,
        updateChangeControl,
        updateStatus,
        deleteChangeControl,
        getImpacts,
        addImpact,
        updateImpact,
        getApprovals,
        addApproval,
        approve,
      }}
    >
      {children}
    </ChangeControlContext.Provider>
  );
};

// Demo data for when database is not available
function getDemoChangeControls(): ChangeControl[] {
  return [
    {
      id: 'demo-cc-1',
      title: 'Update SOP-001 Welding Procedure',
      description: 'Update welding parameters based on new equipment specifications',
      changeType: 'PROCESS',
      priority: 'HIGH',
      status: 'PENDING_APPROVAL',
      initiatorId: 'user-1',
      currentAssigneeId: 'user-2',
      justification: 'New equipment requires different parameters',
      affectedSystems: 'Manufacturing, Quality',
      riskAssessmentSummary: 'Low risk - no product impact',
      implementationPlan: [],
      impactAnalysisCompleted: true,
      approvalRequiredFrom: 'Quality Manager',
      createdAt: '2024-01-15T10:00:00Z',
      updatedAt: '2024-01-15T10:00:00Z',
      effectivenessVerified: false,
    },
    {
      id: 'demo-cc-2',
      title: 'Change Supplier for Raw Material X',
      description: 'Alternative supplier qualification for cost reduction',
      changeType: 'SUPPLIER',
      priority: 'MEDIUM',
      status: 'IMPLEMENTATION',
      initiatorId: 'user-1',
      currentAssigneeId: 'user-3',
      justification: 'Cost reduction of 15%',
      affectedSystems: 'Supply Chain, Quality',
      riskAssessmentSummary: 'Medium risk - requires re-qualification',
      implementationPlan: [],
      impactAnalysisCompleted: true,
      approvalRequiredFrom: 'Quality Manager',
      implementationStartDate: '2024-02-01',
      createdAt: '2024-01-10T09:00:00Z',
      updatedAt: '2024-01-20T14:00:00Z',
      effectivenessVerified: false,
    },
    {
      id: 'demo-cc-3',
      title: 'Software Version Upgrade',
      description: 'Upgrade QMS software to latest version',
      changeType: 'SOFTWARE',
      priority: 'LOW',
      status: 'DRAFT',
      initiatorId: 'user-2',
      currentAssigneeId: 'user-2',
      justification: 'Security patches and new features',
      affectedSystems: 'IT, Quality',
      implementationPlan: [],
      impactAnalysisCompleted: false,
      createdAt: '2024-01-20T11:00:00Z',
      updatedAt: '2024-01-20T11:00:00Z',
      effectivenessVerified: false,
    },
  ];
}
