import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { supabase } from '../lib/supabase';

interface LegalDocument {
  id: string;
  type: string;
  version: string;
  title: string;
  content: string;
  is_active: boolean;
  effective_date: string;
}

interface UserConsent {
  id: string;
  user_id: string;
  document_type: string;
  document_version: string;
  consent_given: boolean;
  consent_at: string;
}

interface ComplianceReport {
  id: string;
  type: string;
  title: string;
  period_start: string;
  period_end: string;
  status: string;
  file_url?: string;
}

interface ComplianceContextType {
  complianceStatus: 'compliant' | 'warning' | 'critical';
  pendingDocuments: LegalDocument[];
  isLoading: boolean;
  checkCompliance: () => Promise<void>;
  acceptDocument: (docId: string, version: string) => Promise<boolean>;
  generateReport: (config: ReportConfig) => Promise<ComplianceReport | null>;
  legalDocuments: LegalDocument[];
  userConsents: UserConsent[];
  fetchLegalDocuments: () => Promise<void>;
}

interface ReportConfig {
  type: string;
  title: string;
  periodStart: string;
  periodEnd: string;
  filters?: Record<string, unknown>;
}

const ComplianceContext = createContext<ComplianceContextType | undefined>(undefined);

export function ComplianceProvider({ children }: { children: React.ReactNode }) {
  const [complianceStatus, setComplianceStatus] = useState<'compliant' | 'warning' | 'critical'>('compliant');
  const [pendingDocuments, setPendingDocuments] = useState<LegalDocument[]>([]);
  const [legalDocuments, setLegalDocuments] = useState<LegalDocument[]>([]);
  const [userConsents, setUserConsents] = useState<UserConsent[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchLegalDocuments = useCallback(async () => {
    try {
      const { data: docs, error } = await supabase
        .from('legal_documents')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) {
        // Table might not exist in demo mode
        console.log('Legal documents table not available in demo mode');
        setLegalDocuments([]);
        return;
      }
      setLegalDocuments(docs || []);
    } catch (error) {
      console.log('Error fetching legal documents, using demo mode');
      setLegalDocuments([]);
    }
  }, []);

  const checkCompliance = useCallback(async () => {
    try {
      setIsLoading(true);
      
      // Fetch active legal documents
      await fetchLegalDocuments();

      // Fetch user's consents
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        // In demo mode or without auth, set default compliant status
        setPendingDocuments([]);
        setComplianceStatus('compliant');
        setIsLoading(false);
        return;
      }

      const { data: consents, error: consentError } = await supabase
        .from('user_consents')
        .select('*')
        .eq('user_id', user.id);

      if (consentError) {
        // Table might not exist in demo mode
        console.log('Consent table not available, using demo mode');
        setUserConsents([]);
      } else {
        setUserConsents(consents || []);
      }

      // Check for pending documents
      const { data: activeDocs, error: docsError } = await supabase
        .from('legal_documents')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (docsError || !activeDocs || activeDocs.length === 0) {
        // Table might not exist or no docs in demo mode
        setPendingDocuments([]);
        setComplianceStatus('compliant');
        setIsLoading(false);
        return;
      }

      const latestDocsByType = new Map<string, LegalDocument>();
      activeDocs.forEach(doc => {
        const existing = latestDocsByType.get(doc.type);
        if (!existing || new Date(doc.created_at) > new Date(existing.created_at)) {
          latestDocsByType.set(doc.type, doc);
        }
      });

      const pending: LegalDocument[] = [];
      latestDocsByType.forEach((doc) => {
        const userConsent = consents?.find(
          c => c.document_type === doc.type && c.consent_given === true
        );
        if (!userConsent || userConsent.document_version !== doc.version) {
          pending.push(doc);
        }
      });

      setPendingDocuments(pending);
      
      // Set compliance status based on pending documents
      if (pending.length === 0) {
        setComplianceStatus('compliant');
      } else if (pending.length <= 2) {
        setComplianceStatus('warning');
      } else {
        setComplianceStatus('critical');
      }
    } catch (error) {
      console.error('Error checking compliance:', error);
      // In case of error, set default compliant status for demo mode
      setPendingDocuments([]);
      setComplianceStatus('compliant');
    } finally {
      setIsLoading(false);
    }
  }, [fetchLegalDocuments]);

  const acceptDocument = useCallback(async (docId: string, version: string): Promise<boolean> => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        console.error('No user found');
        return false;
      }

      const doc = legalDocuments.find(d => d.id === docId);
      if (!doc) {
        console.error('Document not found');
        return false;
      }

      // Get IP address (approximation - in production, use Edge Function)
      const ipResponse = await fetch('https://api.ipify.org?format=json');
      const ipData = await ipResponse.json();
      const ipAddress = ipData.ip;

      const { error } = await supabase.from('user_consents').insert({
        user_id: user.id,
        document_type: doc.type,
        document_version: version,
        consent_given: true,
        consent_at: new Date().toISOString(),
        ip_address: ipAddress,
        user_agent: navigator.userAgent,
      });

      if (error) throw error;

      // Log the consent in audit trail
      const { data: orgMember } = await supabase
        .from('organization_members')
        .select('organization_id')
        .eq('user_id', user.id)
        .single();

      if (orgMember) {
        await supabase.rpc('create_audit_log', {
          p_organization_id: orgMember.organization_id,
          p_user_id: user.id,
          p_user_email: user.email,
          p_action: 'CONSENT',
          p_entity_type: 'legal_document',
          p_entity_id: docId,
          p_entity_name: `${doc.type} v${version}`,
          p_new_value: JSON.stringify({ consented: true, version }),
          p_description: `User accepted ${doc.type} version ${version}`,
        });
      }

      // Refresh compliance status
      await checkCompliance();
      return true;
    } catch (error) {
      console.error('Error accepting document:', error);
      return false;
    }
  }, [legalDocuments, checkCompliance]);

  const generateReport = useCallback(async (config: ReportConfig): Promise<ComplianceReport | null> => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;

      // Get user's organization
      const { data: orgMember } = await supabase
        .from('organization_members')
        .select('organization_id')
        .eq('user_id', user.id)
        .single();

      if (!orgMember) return null;

      const { data, error } = await supabase.from('compliance_reports').insert({
        organization_id: orgMember.organization_id,
        type: config.type,
        title: config.title,
        period_start: config.periodStart,
        period_end: config.periodEnd,
        filters: config.filters || {},
        status: 'pending',
        generated_by: user.id,
      }).select().single();

      if (error) throw error;

      // Log report generation
      await supabase.rpc('create_audit_log', {
        p_organization_id: orgMember.organization_id,
        p_user_id: user.id,
        p_user_email: user.email,
        p_action: 'EXPORT',
        p_entity_type: 'compliance_report',
        p_entity_id: data.id,
        p_entity_name: config.title,
        p_new_value: JSON.stringify(config),
        p_description: `Generated compliance report: ${config.title}`,
      });

      return data;
    } catch (error) {
      console.error('Error generating report:', error);
      return null;
    }
  }, []);

  useEffect(() => {
    checkCompliance();
  }, [checkCompliance]);

  return (
    <ComplianceContext.Provider
      value={{
        complianceStatus,
        pendingDocuments,
        isLoading,
        checkCompliance,
        acceptDocument,
        generateReport,
        legalDocuments,
        userConsents,
        fetchLegalDocuments,
      }}
    >
      {children}
    </ComplianceContext.Provider>
  );
}

export function useCompliance() {
  const context = useContext(ComplianceContext);
  if (context === undefined) {
    throw new Error('useCompliance must be used within a ComplianceProvider');
  }
  return context;
}
