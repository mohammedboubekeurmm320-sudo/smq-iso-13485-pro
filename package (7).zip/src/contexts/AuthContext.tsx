import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import { UserProfile, Permission, rolePermissions, roleLabels, UserRole } from '@/types/auth';

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  session: Session | null;
  permissions: Permission | null;
  loading: boolean;
  isAdmin: boolean;
  signIn: (email: string, password: string) => Promise<{ error: Error | null }>;
  signUp: (email: string, password: string, fullName: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
  updateProfile: (updates: Partial<UserProfile>) => Promise<{ error: Error | null }>;
  refreshProfile: () => Promise<void>;
  hasPermission: (permission: keyof Permission) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Demo accounts for testing - these work without Supabase
const demoUsers: Record<string, { role: UserRole; name: string }> = {
  'admin@example.com': { role: 'admin', name: 'System Administrator' },
  'quality@example.com': { role: 'quality_manager', name: 'Sarah Chen' },
  'auditor@example.com': { role: 'auditor', name: 'Michael Torres' },
  'documents@example.com': { role: 'document_controller', name: 'Emily Rodriguez' },
  'executive@example.com': { role: 'executive', name: 'James Wilson' },
  'operator@example.com': { role: 'operator', name: 'David Martinez' },
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [permissions, setPermissions] = useState<Permission | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = useCallback(async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) {
        // If profile doesn't exist, create one
        if (error.code === 'PGRST116') {
          const { data: userData } = await supabase.auth.getUser();
          if (userData.user) {
            const newProfile = {
              id: userId,
              email: userData.user.email || '',
              full_name: userData.user.user_metadata?.full_name || userData.user.email?.split('@')[0] || 'User',
              role: 'operator' as UserRole,
            };
            
            const { data: insertedProfile, error: insertError } = await supabase
              .from('profiles')
              .insert(newProfile)
              .select()
              .single();
            
            if (!insertError && insertedProfile) {
              setProfile(insertedProfile as UserProfile);
              setPermissions(rolePermissions[insertedProfile.role as UserRole]);
            }
          }
        }
        return;
      }

      if (data) {
        setProfile(data as UserProfile);
        setPermissions(rolePermissions[data.role as UserRole]);
      }
    } catch (err) {
      console.error('Error fetching profile:', err);
    }
  }, []);

  const refreshProfile = useCallback(async () => {
    if (user) {
      await fetchProfile(user.id);
    }
  }, [user, fetchProfile]);

  useEffect(() => {
    // First, check for demo session in sessionStorage (for demo mode persistence)
    const savedDemoSession = sessionStorage.getItem('demoSession');
    if (savedDemoSession) {
      try {
        const { user: savedUser, profile: savedProfile, permissions: savedPermissions } = JSON.parse(savedDemoSession);
        setUser(savedUser);
        setProfile(savedProfile);
        setPermissions(savedPermissions);
        setSession({} as Session);
        setLoading(false);
        return; // Skip Supabase initialization if demo session exists
      } catch (e) {
        console.error('Error restoring demo session:', e);
        sessionStorage.removeItem('demoSession');
      }
    }

    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchProfile(session.user.id);
      }
      setLoading(false);
    }).catch(() => {
      // If Supabase is not available, set loading to false for demo mode
      setLoading(false);
    });

    // Also set a timeout to ensure loading is false even if Supabase hangs
    const timeout = setTimeout(() => {
      setLoading(false);
    }, 3000);

    return () => clearTimeout(timeout);

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        
        if (session?.user) {
          await fetchProfile(session.user.id);
        } else {
          setProfile(null);
          setPermissions(null);
        }
        
        setLoading(false);
      }
    );

    return () => {
      subscription.unsubscribe();
    };
  }, [fetchProfile]);

  const signIn = async (email: string, password: string) => {
    // Check if this is a demo account
    if (demoUsers[email] && password === 'password123') {
      // Create a mock user for demo purposes
      const mockUser = {
        id: `demo-${email}`,
        email: email,
        app_metadata: {},
        user_metadata: { full_name: demoUsers[email].name },
        aud: 'authenticated',
        created_at: new Date().toISOString(),
      } as unknown as User;

      setUser(mockUser);
      
      // Set demo profile with the appropriate role
      const demoProfile: UserProfile = {
        id: mockUser.id,
        email: email,
        full_name: demoUsers[email].name,
        role: demoUsers[email].role,
        department: 'Quality',
        job_title: roleLabels[demoUsers[email].role],
        phone: null,
        avatar_url: null,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      
      setProfile(demoProfile);
      setPermissions(rolePermissions[demoUsers[email].role]);
      setSession({} as Session);
      setLoading(false); // Ensure loading is set to false after demo login
      
      // Save demo session to sessionStorage for persistence across page reloads
      sessionStorage.setItem('demoSession', JSON.stringify({
        user: mockUser,
        profile: demoProfile,
        permissions: rolePermissions[demoUsers[email].role]
      }));
      
      return { error: null };
    }
    
    // Normal Supabase login
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      return { error: error as Error | null };
    } catch (err) {
      return { error: err as Error };
    }
  };

  const signUp = async (email: string, password: string, fullName: string) => {
    try {
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName,
          },
        },
      });
      return { error: error as Error | null };
    } catch (err) {
      return { error: err as Error };
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setProfile(null);
    setSession(null);
    setPermissions(null);
    // Clear demo session from sessionStorage
    sessionStorage.removeItem('demoSession');
  };

  const updateProfile = async (updates: Partial<UserProfile>) => {
    if (!user) return { error: new Error('No user logged in') };

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', user.id);

      if (!error) {
        await refreshProfile();
      }

      return { error: error as Error | null };
    } catch (err) {
      return { error: err as Error };
    }
  };

  const hasPermission = (permission: keyof Permission): boolean => {
    return permissions?.[permission] ?? false;
  };

  const isAdmin = profile?.role === 'admin';

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        session,
        permissions,
        loading,
        isAdmin,
        signIn,
        signUp,
        signOut,
        updateProfile,
        refreshProfile,
        hasPermission,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
