import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { BrowserRouter } from 'react-router-dom';

// Mock Supabase
vi.mock('@supabase/supabase-js', () => ({
  createClient: () => ({
    from: vi.fn(() => ({
      select: vi.fn().mockResolvedValue({ data: [], error: null }),
      insert: vi.fn().mockResolvedValue({ data: [], error: null }),
      update: vi.fn().mockResolvedValue({ data: [], error: null }),
      delete: vi.fn().mockResolvedValue({ data: [], error: null }),
    })),
    auth: {
      signInWithPassword: vi.fn().mockResolvedValue({ data: { user: {} }, error: null }),
      signOut: vi.fn().mockResolvedValue({ error: null }),
      getSession: vi.fn().mockResolvedValue({ data: { session: null }, error: null }),
    },
  }),
}));

// Test suite for API Service
describe('API Service', () => {
  it('should export documentsApi', async () => {
    const { documentsApi } = await import('../services/api');
    expect(documentsApi).toBeDefined();
    expect(documentsApi.getAll).toBeDefined();
    expect(documentsApi.create).toBeDefined();
    expect(documentsApi.update).toBeDefined();
  });

  it('should export capaApi', async () => {
    const { capaApi } = await import('../services/api');
    expect(capaApi).toBeDefined();
    expect(capaApi.getAll).toBeDefined();
  });

  it('should export auditApi', async () => {
    const { auditApi } = await import('../services/api');
    expect(auditApi).toBeDefined();
    expect(auditApi.logAudit).toBeDefined();
  });
});

// Test suite for Auth Context
describe('AuthContext', () => {
  const mockUser = {
    id: 'test-user-id',
    email: 'test@example.com',
    app_metadata: {},
    user_metadata: { full_name: 'Test User' },
    aud: 'authenticated',
    created_at: new Date().toISOString(),
  };

  it('should provide authentication functions', async () => {
    const { useAuth } = await import('../contexts/AuthContext');
    const { result } = renderHook(() => useAuth());
    
    expect(result.current.signIn).toBeDefined();
    expect(result.current.signOut).toBeDefined();
  });
});

// Test suite for Document Types
describe('Types', () => {
  it('should validate Document type', () => {
    const { Document } = require('../types/qms');
    
    const doc: Document = {
      id: '1',
      documentNumber: 'DOC-001',
      title: 'Test Document',
      type: 'SOP',
      version: '1.0',
      status: 'Draft',
      effectiveDate: '2024-01-01',
      expirationDate: '2025-01-01',
      owner: 'John Doe',
      department: 'Quality',
      lastReviewed: '2024-01-01',
      nextReview: '2024-06-01',
      description: 'Test description',
    };
    
    expect(doc.id).toBeDefined();
    expect(doc.documentNumber).toBe('DOC-001');
  });

  it('should validate CAPA type', () => {
    const { CAPA } = require('../types/qms');
    
    const capa: CAPA = {
      id: '1',
      capaNumber: 'CAPA-001',
      title: 'Test CAPA',
      type: 'Corrective',
      status: 'Open',
      priority: 'High',
      source: 'Internal Audit',
      description: 'Test description',
      rootCause: 'Root cause analysis',
      proposedAction: 'Proposed action',
      assignedTo: 'John Doe',
      dueDate: '2024-12-31',
      createdAt: '2024-01-01',
      updatedAt: '2024-01-01',
    };
    
    expect(capa.id).toBeDefined();
    expect(capa.capaNumber).toBe('CAPA-001');
  });
});

// Test suite for Rate Limiting Utilities
describe('Rate Limiting', () => {
  const { debounce, throttle, RateLimiter } = require('../utils/rateLimit');

  it('should debounce function calls', async () => {
    const mockFn = vi.fn();
    const debouncedFn = debounce(mockFn, 100);

    debouncedFn();
    debouncedFn();
    debouncedFn();

    expect(mockFn).not.toHaveBeenCalled();

    await new Promise(resolve => setTimeout(resolve, 150));

    expect(mockFn).toHaveBeenCalledTimes(1);
  });

  it('should throttle function calls', async () => {
    const mockFn = vi.fn();
    const throttledFn = throttle(mockFn, 100);

    throttledFn();
    throttledFn();
    throttledFn();

    expect(mockFn).toHaveBeenCalledTimes(1);
  });

  it('should rate limit correctly', () => {
    const limiter = new RateLimiter(5, 10); // 5 tokens, refill 10 per second

    expect(limiter.tryConsume(1)).toBe(true);
    expect(limiter.tryConsume(1)).toBe(true);
    expect(limiter.tryConsume(1)).toBe(true);
    expect(limiter.tryConsume(1)).toBe(true);
    expect(limiter.tryConsume(1)).toBe(true);
    expect(limiter.tryConsume(1)).toBe(false); // Should fail - no tokens left
  });
});

// Test suite for Permission System
describe('Permissions', () => {
  it('should have correct role permissions', () => {
    const { rolePermissions } = require('../types/auth');
    
    expect(rolePermissions.admin).toBeDefined();
    expect(rolePermissions.admin.canManageUsers).toBe(true);
    expect(rolePermissions.operator.canCreateDocuments).toBe(false);
  });

  it('should have correct role labels', () => {
    const { roleLabels } = require('../types/auth');
    
    expect(roleLabels.admin).toBe('Administrator');
    expect(roleLabels.quality_manager).toBe('Quality Manager');
  });
});
