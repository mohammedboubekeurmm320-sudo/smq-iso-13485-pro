// End-to-End Tests for ISO 13485 QMS
// Run with: npx playwright test

import { test, expect, type Page } from '@playwright/test';

const BASE_URL = process.env.E2E_BASE_URL || 'http://localhost:5173';

test.describe('ISO 13485 QMS E2E Tests', () => {
  
  test.beforeEach(async ({ page }) => {
    await page.goto(BASE_URL);
  });

  test.describe('Authentication', () => {
    test('should show login page on load', async ({ page }) => {
      await expect(page.locator('text=Demo Accounts')).toBeVisible();
      await expect(page.locator('text=Sign in to your account')).toBeVisible();
    });

    test('should login with demo account', async ({ page }) => {
      // Click on Quality Manager demo account
      await page.click('text=Quality Manager');
      
      // Should redirect to dashboard
      await expect(page.locator('text=Dashboard')).toBeVisible({ timeout: 10000 });
    });

    test('should show error for invalid credentials', async ({ page }) => {
      await page.fill('input[type="email"]', 'invalid@example.com');
      await page.fill('input[type="password"]', 'wrongpassword');
      await page.click('button[type="submit"]');
      
      await expect(page.locator('text=Invalid credentials')).toBeVisible();
    });
  });

  test.describe('Document Control', () => {
    test.beforeEach(async ({ page }) => {
      // Login first
      await page.click('text=Quality Manager');
      await expect(page.locator('text=Dashboard')).toBeVisible({ timeout: 10000 });
    });

    test('should display documents list', async ({ page }) => {
      await page.click('text=Document Control');
      await expect(page.locator('h2:has-text("Document Control")')).toBeVisible();
    });

    test('should open new document modal', async ({ page }) => {
      await page.click('text=Document Control');
      await page.click('text=New Document');
      await expect(page.locator('text=Create New Document')).toBeVisible();
    });

    test('should filter documents by status', async ({ page }) => {
      await page.click('text=Document Control');
      await page.selectOption('select >> nth=1', 'Approved');
      // Should filter the list
      await expect(page.locator('text=Document Control')).toBeVisible();
    });

    test('should open signature modal for approved documents', async ({ page }) => {
      await page.click('text=Document Control');
      // Click on a document in review status if available
      // This test depends on mock data
    });
  });

  test.describe('CAPA Management', () => {
    test.beforeEach(async ({ page }) => {
      await page.click('text=Quality Manager');
      await expect(page.locator('text=Dashboard')).toBeVisible({ timeout: 10000 });
    });

    test('should display CAPA list', async ({ page }) => {
      await page.click('text=CAPA Management');
      await expect(page.locator('h2:has-text("CAPA Management")')).toBeVisible();
    });

    test('should open new CAPA modal', async ({ page }) => {
      await page.click('text=CAPA Management');
      await page.click('text=New CAPA');
      await expect(page.locator('text=Create New CAPA')).toBeVisible();
    });

    test('should filter CAPAs by priority', async ({ page }) => {
      await page.click('text=CAPA Management');
      await page.selectOption('select >> nth=2', 'Critical');
    });
  });

  test.describe('Navigation', () => {
    test.beforeEach(async ({ page }) => {
      await page.click('text=Quality Manager');
      await expect(page.locator('text=Dashboard')).toBeVisible({ timeout: 10000 });
    });

    test('should navigate to all main sections', async ({ sections }) => {
      const navItems = [
        'Dashboard',
        'Document Control',
        'CAPA Management',
        'Audit Management',
        'Non-Conformance',
        'Training Records',
        'Risk Management',
        'Reports',
        'Compliance',
      ];

      for (const item of navItems) {
        await page.click(`text=${item}`);
        await expect(page.locator(`h2:has-text("${item}")`)).toBeVisible({ timeout: 5000 });
      }
    });

    test('should toggle sidebar collapse', async ({ page }) => {
      const toggleButton = page.locator('button:has-text("")').first();
      await toggleButton.click();
      // Sidebar should collapse
    });

    test('should show user profile', async ({ page }) => {
      await page.click('button:has-text("")'); // Profile button in header
      await expect(page.locator('text=My Profile')).toBeVisible();
    });
  });

  test.describe('User Management (Admin only)', () => {
    test('should not show User Management for non-admin', async ({ page }) => {
      await page.click('text=Quality Manager');
      await expect(page.locator('text=Dashboard')).toBeVisible({ timeout: 10000 });
      
      // User Management should not be visible for Quality Manager
      await expect(page.locator('text=User Management')).not.toBeVisible();
    });

    test('should show User Management for admin', async ({ page }) => {
      await page.click('text=System Administrator');
      await expect(page.locator('text=Dashboard')).toBeVisible({ timeout: 10000 });
      
      // User Management should be visible for Admin
      await expect(page.locator('text=User Management')).toBeVisible();
    });
  });

  test.describe('Error Handling', () => {
    test('should show loading state', async ({ page }) => {
      await page.click('text=Quality Manager');
      await page.click('text=Document Control');
      
      // Should show loading spinner
      await expect(page.locator('text=Loading documents')).toBeVisible();
    });

    test('should handle network errors gracefully', async ({ page }) => {
      // This test would require network interception
      // Skipped for basic E2E
    });
  });
});

test.describe('Compliance Features', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(BASE_URL);
    await page.click('text=Quality Manager');
    await expect(page.locator('text=Dashboard')).toBeVisible({ timeout: 10000 });
  });

  test('should display ISO 13485 compliance badge', async ({ page }) => {
    await expect(page.locator('text=ISO 13485:2016')).toBeVisible();
  });

  test('should show compliance module', async ({ page }) => {
    await page.click('text=Compliance');
    await expect(page.locator('h2:has-text("Compliance")')).toBeVisible();
  });
});
