-- ISO 13485 QMS Database Migration
-- Creates all necessary tables for production-ready QMS

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Documents table
CREATE TABLE IF NOT EXISTS documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_number VARCHAR(50) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(50) NOT NULL,
    version VARCHAR(20) DEFAULT '1.0',
    status VARCHAR(50) DEFAULT 'Draft',
    content TEXT,
    owner VARCHAR(255),
    department VARCHAR(100),
    effective_date DATE,
    expiration_date DATE,
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- CAPA table
CREATE TABLE IF NOT EXISTS capas (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    capa_number VARCHAR(50) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(50) NOT NULL,
    status VARCHAR(50) DEFAULT 'Open',
    priority VARCHAR(50) DEFAULT 'Medium',
    source VARCHAR(100),
    root_cause TEXT,
    proposed_action TEXT,
    assigned_to VARCHAR(255),
    due_date DATE,
    closed_date DATE,
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Non-conformances table
CREATE TABLE IF NOT EXISTS non_conformances (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ncr_number VARCHAR(50) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(50),
    severity VARCHAR(50) DEFAULT 'Minor',
    status VARCHAR(50) DEFAULT 'Open',
    department VARCHAR(100),
    identified_by VARCHAR(255),
    assigned_to VARCHAR(255),
    root_cause TEXT,
    corrective_action TEXT,
    preventive_action TEXT,
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Training records table
CREATE TABLE IF NOT EXISTS training_records (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    employee_id VARCHAR(100),
    employee_name VARCHAR(255) NOT NULL,
    department VARCHAR(100),
    training_title VARCHAR(255) NOT NULL,
    training_type VARCHAR(100),
    status VARCHAR(50) DEFAULT 'Scheduled',
    trainer VARCHAR(255),
    completion_date DATE,
    expiry_date DATE,
    certificate_url TEXT,
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Signatures table (for electronic signatures - FDA 21 CFR Part 11)
CREATE TABLE IF NOT EXISTS signatures (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_id UUID REFERENCES documents(id) ON DELETE CASCADE,
    user_id UUID REFERENCES auth.users(id) NOT NULL,
    user_email VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL,
    reason TEXT,
    hash VARCHAR(255) NOT NULL,
    ip_address VARCHAR(50),
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Audit trail table (immutable log)
CREATE TABLE IF NOT EXISTS audit_trail (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    action VARCHAR(50) NOT NULL,
    table_name VARCHAR(100) NOT NULL,
    record_id UUID NOT NULL,
    old_values JSONB,
    new_values JSONB,
    user_id UUID REFERENCES auth.users(id),
    user_email VARCHAR(255),
    ip_address VARCHAR(50),
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Change control table
CREATE TABLE IF NOT EXISTS change_controls (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    change_number VARCHAR(50) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(50),
    status VARCHAR(50) DEFAULT 'Pending',
    priority VARCHAR(50) DEFAULT 'Medium',
    requested_by VARCHAR(255),
    assigned_to VARCHAR(255),
    impact_assessment TEXT,
    implementation_date DATE,
    approval_date DATE,
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Deviations table
CREATE TABLE IF NOT EXISTS deviations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    deviation_number VARCHAR(50) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(50),
    status VARCHAR(50) DEFAULT 'Open',
    severity VARCHAR(50) DEFAULT 'Minor',
    department VARCHAR(100),
    identified_by VARCHAR(255),
    assigned_to VARCHAR(255),
    root_cause TEXT,
    immediate_action TEXT,
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Row Level Security (RLS) Policies
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE capas ENABLE ROW LEVEL SECURITY;
ALTER TABLE non_conformances ENABLE ROW LEVEL SECURITY;
ALTER TABLE training_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE signatures ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_trail ENABLE ROW LEVEL SECURITY;
ALTER TABLE change_controls ENABLE ROW LEVEL SECURITY;
ALTER TABLE deviations ENABLE ROW LEVEL SECURITY;

-- RLS Policies for Documents
CREATE POLICY "Documents are viewable by authenticated users" 
ON documents FOR SELECT TO authenticated 
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Documents can be created by authenticated users" 
ON documents FOR INSERT TO authenticated 
WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Documents can be updated by authenticated users" 
ON documents FOR UPDATE TO authenticated 
USING (auth.uid() IS NOT NULL);

-- RLS Policies for CAPAs
CREATE POLICY "CAPAs are viewable by authenticated users" 
ON capas FOR SELECT TO authenticated 
USING (auth.uid() IS NOT NULL);

CREATE POLICY "CAPAs can be created by authenticated users" 
ON capas FOR INSERT TO authenticated 
WITH CHECK (auth.uid() IS NOT NULL);

-- RLS Policies for Audit Trail (read-only for all, insert-only for authenticated)
CREATE POLICY "Audit trail is viewable by authenticated users" 
ON audit_trail FOR SELECT TO authenticated 
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Audit trail can be inserted by authenticated users" 
ON audit_trail FOR INSERT TO authenticated 
WITH CHECK (auth.uid() IS NOT NULL);

-- RLS Policies for Signatures (no delete allowed)
CREATE POLICY "Signatures are viewable by authenticated users" 
ON signatures FOR SELECT TO authenticated 
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Signatures can be created by authenticated users" 
ON signatures FOR INSERT TO authenticated 
WITH CHECK (auth.uid() IS NOT NULL);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_documents_status ON documents(status);
CREATE INDEX IF NOT EXISTS idx_documents_type ON documents(type);
CREATE INDEX IF NOT EXISTS idx_capas_status ON capas(status);
CREATE INDEX IF NOT EXISTS idx_capas_priority ON capas(priority);
CREATE INDEX IF NOT EXISTS idx_audit_trail_table ON audit_trail(table_name);
CREATE INDEX IF NOT EXISTS idx_audit_trail_user ON audit_trail(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_trail_timestamp ON audit_trail(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_signatures_document ON signatures(document_id);
CREATE INDEX IF NOT EXISTS idx_signatures_user ON signatures(user_id);

-- Enable audit trigger function
CREATE OR REPLACE FUNCTION audit_trigger_func()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO audit_trail (action, table_name, record_id, new_values, user_id, timestamp)
        VALUES (TG_OP, TG_TABLE_NAME, NEW.id, to_jsonb(NEW), NEW.created_by, NOW());
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO audit_trail (action, table_name, record_id, old_values, new_values, user_id, timestamp)
        VALUES (TG_OP, TG_TABLE_NAME, NEW.id, to_jsonb(OLD), to_jsonb(NEW), NEW.updated_by, NOW());
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        INSERT INTO audit_trail (action, table_name, record_id, old_values, user_id, timestamp)
        VALUES (TG_OP, TG_TABLE_NAME, OLD.id, to_jsonb(OLD), OLD.updated_by, NOW());
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Comment on tables for documentation
COMMENT ON TABLE documents IS 'Controlled documents per ISO 13485 Section 4.2.4';
COMMENT ON TABLE capas IS 'Corrective and Preventive Actions';
COMMENT ON TABLE signatures IS 'Electronic signatures for FDA 21 CFR Part 11 compliance';
COMMENT ON TABLE audit_trail IS 'Immutable audit log for regulatory compliance';
