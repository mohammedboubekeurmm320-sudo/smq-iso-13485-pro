-- Change Control and Deviation Modules for ISO 13485 / 21 CFR Part 820
-- Migration: 004_change_control_deviation.sql

-- ============================================
-- CHANGE CONTROL MODULE
-- ============================================

CREATE TABLE IF NOT EXISTS change_controls (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title VARCHAR(255) NOT NULL,
    description TEXT,
    change_type VARCHAR(50) NOT NULL CHECK (change_type IN ('PROCESS', 'DOCUMENT', 'DESIGN', 'SUPPLIER', 'EQUIPMENT', 'SOFTWARE', 'MATERIAL')),
    priority VARCHAR(20) NOT NULL DEFAULT 'MEDIUM' CHECK (priority IN ('LOW', 'MEDIUM', 'HIGH', 'EMERGENCY')),
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT', 'IMPACT_ANALYSIS', 'PENDING_APPROVAL', 'APPROVED', 'REJECTED', 'IMPLEMENTATION', 'VERIFICATION', 'CLOSED')),
    
    -- People
    initiator_id UUID REFERENCES users(id),
    current_assignee_id UUID REFERENCES users(id),
    
    -- Details
    justification TEXT,
    affected_systems TEXT,
    risk_assessment_summary TEXT,
    implementation_plan JSONB DEFAULT '[]',
    
    -- Approval tracking
    impact_analysis_completed BOOLEAN DEFAULT FALSE,
    approval_required_from VARCHAR(255),
    approved_by UUID REFERENCES users(id),
    approved_at TIMESTAMPTZ,
    
    -- Implementation
    implementation_start_date DATE,
    implementation_completion_date DATE,
    effectiveness_verified BOOLEAN DEFAULT FALSE,
    verification_notes TEXT,
    
    -- Metadata
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);

-- Change Control Impact Assessments
CREATE TABLE IF NOT EXISTS change_control_impacts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    change_control_id UUID NOT NULL REFERENCES change_controls(id) ON DELETE CASCADE,
    impact_area VARCHAR(50) NOT NULL CHECK (impact_area IN ('QUALITY', 'REGULATORY', 'SAFETY', 'OPERATIONS', 'SUPPLY_CHAIN', 'DOCUMENTATION', 'TRAINING')),
    impact_description TEXT,
    risk_level VARCHAR(20) CHECK (risk_level IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    mitigation_plan TEXT,
    assessed_by UUID REFERENCES users(id),
    assessed_at TIMESTAMPTZ DEFAULT NOW(),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Change Control Approval Workflow
CREATE TABLE IF NOT EXISTS change_control_approvals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    change_control_id UUID NOT NULL REFERENCES change_controls(id) ON DELETE CASCADE,
    approver_id UUID REFERENCES users(id),
    approval_order INTEGER NOT NULL DEFAULT 1,
    role VARCHAR(100),
    status VARCHAR(20) DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED', 'N/A')),
    comments TEXT,
    signed_at TIMESTAMPTZ,
    signature_hash VARCHAR(255),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- DEVIATION MODULE
-- ============================================

CREATE TABLE IF NOT EXISTS deviations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    reference_number VARCHAR(50) NOT NULL UNIQUE,
    title VARCHAR(255) NOT NULL,
    occurrence_date TIMESTAMPTZ NOT NULL,
    identified_by_id UUID REFERENCES users(id),
    
    -- Description
    description_of_event TEXT NOT NULL,
    immediate_action_taken TEXT,
    root_cause_analysis TEXT,
    five_whys JSONB,
    fishbone_diagram JSONB,
    
    -- Assessment
    impact_assessment TEXT,
    severity VARCHAR(20) NOT NULL CHECK (severity IN ('MINOR', 'MAJOR', 'CRITICAL')),
    detectability VARCHAR(20) CHECK (detectability IN ('HIGH', 'MEDIUM', 'LOW')),
    risk_priority_number INTEGER,
    
    -- Disposition
    disposition VARCHAR(30) CHECK (disposition IN ('USE_AS_IS', 'REWORK', 'REPAIR', 'SCRAP', 'RETURN_TO_VENDOR', 'CONCESSION')),
    disposition_justification TEXT,
    disposition_approved_by UUID REFERENCES users(id),
    disposition_approved_at TIMESTAMPTZ,
    
    -- CAPA Link
    capa_required BOOLEAN DEFAULT FALSE,
    linked_capa_id UUID REFERENCES cap_records(id),
    
    -- Status & Workflow
    status VARCHAR(30) NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'UNDER_INVESTIGATION', 'QA_REVIEW', 'PENDING_DISPOSITION', 'CLOSED', 'REJECTED')),
    investigation_completed BOOLEAN DEFAULT FALSE,
    
    -- Quarantine
    product_quarantined BOOLEAN DEFAULT FALSE,
    quarantine_lot_number VARCHAR(100),
    
    -- Metadata
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    closed_at TIMESTAMPTZ,
    deleted_at TIMESTAMPTZ
);

-- Deviation Categories
CREATE TABLE IF NOT EXISTS deviation_categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Link deviations to categories
CREATE TABLE IF NOT EXISTS deviation_category_links (
    deviation_id UUID NOT NULL REFERENCES deviations(id) ON DELETE CASCADE,
    category_id UUID NOT NULL REFERENCES deviation_categories(id) ON DELETE CASCADE,
    PRIMARY KEY (deviation_id, category_id)
);

-- ============================================
-- ELECTRONIC SIGNATURES (21 CFR Part 11)
-- ============================================

CREATE TABLE IF NOT EXISTS electronic_signatures (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    module_type VARCHAR(30) NOT NULL CHECK (module_type IN ('CHANGE_CONTROL', 'DEVIATION', 'CAPA', 'AUDIT', 'DOCUMENT')),
    record_id UUID NOT NULL,
    user_id UUID NOT NULL REFERENCES users(id),
    role VARCHAR(100) NOT NULL,
    meaning VARCHAR(255) NOT NULL,
    signature_hash VARCHAR(255) NOT NULL,
    signed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ip_address INET,
    user_agent TEXT,
    is_valid BOOLEAN DEFAULT TRUE,
    superseded_by UUID REFERENCES electronic_signatures(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- AUDIT TRAIL (21 CFR Part 11)
-- ============================================

CREATE TABLE IF NOT EXISTS audit_trails (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    module_type VARCHAR(30) NOT NULL,
    record_id UUID NOT NULL,
    field_name VARCHAR(100) NOT NULL,
    old_value TEXT,
    new_value TEXT,
    change_reason TEXT,
    user_id UUID REFERENCES users(id),
    ip_address INET,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================
-- SEQUENCES FOR REFERENCE NUMBERS
-- ============================================

CREATE SEQUENCE IF NOT EXISTS deviation_reference_seq START WITH 1;
CREATE SEQUENCE IF NOT EXISTS change_control_reference_seq START WITH 1;

-- Function to generate deviation reference number
CREATE OR REPLACE FUNCTION generate_deviation_reference()
RETURNS TEXT AS $$
DECLARE
    year_text TEXT;
    seq_num TEXT;
BEGIN
    year_text := TO_CHAR(NOW(), 'YYYY');
    seq_num := LPAD(NEXTVAL('deviation_reference_seq')::TEXT, 4, '0');
    RETURN 'DEV-' || year_text || '-' || seq_num;
END;
$$ LANGUAGE plpgsql;

-- Function to generate change control reference number
CREATE OR REPLACE FUNCTION generate_change_control_reference()
RETURNS TEXT AS $$
DECLARE
    year_text TEXT;
    seq_num TEXT;
BEGIN
    year_text := TO_CHAR(NOW(), 'YYYY');
    seq_num := LPAD(NEXTVAL('change_control_reference_seq')::TEXT, 4, '0');
    RETURN 'CC-' || year_text || '-' || seq_num;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- DEFAULT DEVIATION CATEGORIES
-- ============================================

INSERT INTO deviation_categories (name, description) VALUES
    ('Process Deviation', 'Departure from approved process parameters or procedures'),
    ('Documentation Error', 'Error or omission in controlled documents'),
    ('Equipment Malfunction', 'Failure or deviation of equipment from specifications'),
    ('Material Defect', 'Non-conforming material or component'),
    ('Testing Deviation', 'Departure from approved test methods or acceptance criteria'),
    ('Software Deviation', 'Departure from validated software specifications'),
    ('Labeling Error', 'Error in product labeling or packaging'),
    ('Other', 'Other types of deviations not covered above')
ON CONFLICT (name) DO NOTHING;

-- ============================================
-- RLS POLICIES (if enabled)
-- ============================================

-- ALTER TABLE change_controls ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE deviations ENABLE ROW LEVEL SECURITY;

-- CREATE POLICY "Users can view change controls" ON change_controls FOR SELECT
--     USING (true);

-- CREATE POLICY "Users can view deviations" ON deviations FOR SELECT
--     USING (true);
