-- =====================================================
-- ISO 13485 QMS - Database Schema for Production
-- =====================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =====================================================
-- Organizations Table
-- =====================================================
CREATE TABLE IF NOT EXISTS organizations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    address TEXT,
    phone TEXT,
    email TEXT,
    website TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- Users Table (extends Supabase auth.users)
-- =====================================================
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    full_name TEXT,
    role TEXT NOT NULL DEFAULT 'operator' CHECK (role IN ('admin', 'quality_manager', 'auditor', 'operator', 'reviewer', 'viewer')),
    department TEXT,
    job_title TEXT,
    organization_id UUID REFERENCES organizations(id),
    avatar_url TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- Documents Table (ISO 13485 Section 4.2)
-- =====================================================
CREATE TABLE IF NOT EXISTS documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_number TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    category TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Draft' CHECK (status IN ('Draft', 'In Review', 'Approved', 'Obsolete')),
    version TEXT NOT NULL DEFAULT '1.0',
    content TEXT,
    file_url TEXT,
    file_name TEXT,
    file_size INTEGER,
    mime_type TEXT,
    author_id UUID REFERENCES public.profiles(id),
    reviewer_id UUID REFERENCES public.profiles(id),
    approver_id UUID REFERENCES public.profiles(id),
    approved_at TIMESTAMPTZ,
    review_comments TEXT,
    approval_comments TEXT,
    effective_date DATE,
    expiry_date DATE,
    retention_period INTEGER,
    tags TEXT[],
    organization_id UUID REFERENCES organizations(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- CAPA Table (ISO 13485 Section 8.5.2)
-- =====================================================
CREATE TABLE IF NOT EXISTS capas (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    capa_number TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('Corrective', 'Preventive', 'Improvement')),
    status TEXT NOT NULL DEFAULT 'Open' CHECK (status IN ('Open', 'In Progress', 'Pending Verification', 'Closed', 'Cancelled')),
    severity TEXT NOT NULL CHECK (severity IN ('Critical', 'Major', 'Minor')),
    priority INTEGER DEFAULT 2 CHECK (priority BETWEEN 1 AND 3),
    source TEXT,
    source_description TEXT,
    detected_date DATE NOT NULL,
    assigned_to UUID REFERENCES public.profiles(id),
    root_cause TEXT,
    immediate_action TEXT,
    corrective_action TEXT,
    preventive_action TEXT,
    action_due_date DATE,
    action_completed_date DATE,
    verification_status TEXT,
    verification_result TEXT,
    verified_by UUID REFERENCES public.profiles(id),
    verified_date DATE,
    effectiveness_comments TEXT,
    linked_document_id UUID REFERENCES documents(id),
    linked_risk_id UUID,
    organization_id UUID REFERENCES organizations(id),
    created_by UUID REFERENCES public.profiles(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- Risks Table (ISO 14971)
-- =====================================================
CREATE TABLE IF NOT EXISTS risks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    risk_number TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    severity INTEGER NOT NULL CHECK (severity BETWEEN 1 AND 5),
    probability INTEGER NOT NULL CHECK (probability BETWEEN 1 AND 5),
    detectability INTEGER NOT NULL CHECK (detectability BETWEEN 1 AND 5),
    rpn INTEGER NOT NULL,
    risk_level TEXT CHECK (risk_level IN ('Critical', 'High', 'Medium', 'Low')),
    status TEXT NOT NULL DEFAULT 'Open' CHECK (status IN ('Open', 'Mitigation', 'Closed')),
    category TEXT CHECK (category IN ('Design', 'Manufacturing', 'Use/Misuse', 'Environmental', 'Regulatory', 'Software', 'Biological', 'Supplier')),
    hazard TEXT,
    harmful_situation TEXT,
    harm TEXT,
    harm_severity INTEGER,
    harm_severity_classification TEXT,
    mitigation_measures TEXT,
    risk_control_measures TEXT[],
    risk_control_option TEXT,
    residual_severity INTEGER,
    residual_probability INTEGER,
    residual_detectability INTEGER,
    residual_rpn INTEGER,
    residual_risk_level TEXT,
    owner TEXT,
    review_frequency TEXT,
    due_date DATE,
    device_name TEXT,
    device_class TEXT CHECK (device_class IN ('Class I', 'Class IIa', 'Class IIb', 'Class III')),
    intended_use TEXT,
    failure_mode TEXT,
    failure_effect TEXT,
    failure_cause TEXT,
    detection_method TEXT,
    linked_capa_id UUID REFERENCES capas(id),
    linked_document_id UUID REFERENCES documents(id),
    created_by UUID REFERENCES public.profiles(id),
    organization_id UUID REFERENCES organizations(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- Training Records Table (ISO 13485 Section 7.2, 7.3)
-- =====================================================
CREATE TABLE IF NOT EXISTS training_records (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    employee_id TEXT,
    employee_name TEXT NOT NULL,
    employee_email TEXT,
    department TEXT NOT NULL,
    job_title TEXT,
    training_title TEXT NOT NULL,
    training_type TEXT NOT NULL CHECK (training_type IN ('Initial', 'Refresher', 'Certification', 'On-the-Job', 'External')),
    training_category TEXT,
    training_provider TEXT,
    training_location TEXT,
    status TEXT NOT NULL DEFAULT 'Scheduled' CHECK (status IN ('Scheduled', 'In Progress', 'Completed', 'Cancelled')),
    start_date DATE,
    due_date DATE,
    completion_date DATE,
    expiration_date DATE,
    trainer TEXT,
    training_method TEXT CHECK (training_method IN ('Classroom', 'Online', 'OJT', 'Workshop', 'External Course', 'Self-Paced')),
    training_duration TEXT,
    assessment_method TEXT,
    score INTEGER,
    passing_score INTEGER,
    assessment_date DATE,
    assessor_name TEXT,
    document_ref TEXT,
    certificate_number TEXT,
    certificate_url TEXT,
    training_material_ref TEXT,
    effectiveness_criteria TEXT,
    effectiveness_evaluation TEXT,
    effectiveness_comments TEXT,
    verified_by UUID REFERENCES public.profiles(id),
    verification_date DATE,
    approval_status TEXT,
    approved_by UUID REFERENCES public.profiles(id),
    approval_date DATE,
    linked_capa_id UUID REFERENCES capas(id),
    linked_audit_id UUID,
    created_by UUID REFERENCES public.profiles(id),
    organization_id UUID REFERENCES organizations(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- Non-Conformances Table (ISO 13485 Section 8.3)
-- =====================================================
CREATE TABLE IF NOT EXISTS non_conformances (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ncr_number TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('Product', 'Process', 'Equipment', 'Documentation', 'Other')),
    status TEXT NOT NULL DEFAULT 'Open' CHECK (status IN ('Open', 'In Progress', 'Pending Verification', 'Closed', 'Cancelled')),
    severity TEXT NOT NULL CHECK (severity IN ('Critical', 'Major', 'Minor')),
    source TEXT,
    source_description TEXT,
    detected_date DATE NOT NULL,
    detected_by TEXT,
    lot_number TEXT,
    quantity_affected INTEGER,
    total_quantity INTEGER,
    product_name TEXT,
    part_number TEXT,
    immediate_action TEXT,
    containment_effective BOOLEAN DEFAULT false,
    root_cause_analysis TEXT,
    five_whys TEXT[],
    fishbone_diagram JSONB,
    disposition TEXT CHECK (disposition IN ('Pending', 'Use As Is', 'Rework', 'Repair', 'Scrap', 'Concession')),
    disposition_justification TEXT,
    disposition_approved_by TEXT,
    disposition_date DATE,
    effectiveness_verification TEXT,
    verification_date DATE,
    verified_by TEXT,
    linked_capa UUID REFERENCES capas(id),
    linked_audit_id UUID,
    linked_deviation_id UUID,
    assigned_to TEXT,
    department TEXT,
    created_date DATE NOT NULL,
    closed_date DATE,
    due_date DATE,
    created_by UUID REFERENCES public.profiles(id),
    organization_id UUID REFERENCES organizations(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- Audits Table (ISO 13485 Section 8.2)
-- =====================================================
CREATE TABLE IF NOT EXISTS audits (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    audit_number TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    type TEXT NOT NULL CHECK (type IN ('Internal', 'External', 'Supplier', 'Regulatory', 'Unannounced')),
    status TEXT NOT NULL DEFAULT 'Scheduled' CHECK (status IN ('Scheduled', 'In Progress', 'Completed', 'Cancelled')),
    scheduled_date DATE NOT NULL,
    completed_date DATE,
    lead_auditor TEXT NOT NULL,
    auditees TEXT[],
    department TEXT NOT NULL,
    scope TEXT,
    audit_criteria TEXT,
    audit_program TEXT,
    standard_references TEXT[],
    findings INTEGER DEFAULT 0,
    observations INTEGER DEFAULT 0,
    major_findings INTEGER DEFAULT 0,
    minor_findings INTEGER DEFAULT 0,
    opportunities_for_improvement TEXT,
    conclusion TEXT CHECK (conclusion IN ('Pass', 'Fail', 'Conditional Pass', 'Pending')),
    audit_summary TEXT,
    follow_up_required BOOLEAN DEFAULT false,
    follow_up_date DATE,
    organization_id UUID REFERENCES organizations(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- Legal Documents Table
-- =====================================================
CREATE TABLE IF NOT EXISTS legal_documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    type TEXT NOT NULL CHECK (type IN ('Policy', 'Procedure', 'Work Instruction', 'Regulation', 'Standard', 'Form')),
    version TEXT NOT NULL,
    title TEXT NOT NULL,
    content TEXT,
    is_active BOOLEAN DEFAULT true,
    effective_date DATE,
    review_date DATE,
    next_review_date DATE,
    owner TEXT,
    approver TEXT,
    document_ref TEXT,
    language TEXT DEFAULT 'FR',
    keywords TEXT[],
    organization_id UUID REFERENCES organizations(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- Audit Trail Table (ISO 13485 Section 4.2.4)
-- =====================================================
CREATE TABLE IF NOT EXISTS audit_trail (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    action TEXT NOT NULL CHECK (action IN ('CREATE', 'READ', 'UPDATE', 'DELETE', 'APPROVE', 'REJECT', 'SIGN')),
    table_name TEXT NOT NULL,
    record_id UUID NOT NULL,
    user_id UUID REFERENCES public.profiles(id),
    user_email TEXT,
    old_values JSONB,
    new_values JSONB,
    ip_address TEXT,
    user_agent TEXT,
    organization_id UUID REFERENCES organizations(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- Indexes for Performance
-- =====================================================
CREATE INDEX IF NOT EXISTS idx_documents_status ON documents(status);
CREATE INDEX IF NOT EXISTS idx_documents_category ON documents(category);
CREATE INDEX IF NOT EXISTS idx_capas_status ON capas(status);
CREATE INDEX IF NOT EXISTS idx_capas_severity ON capas(severity);
CREATE INDEX IF NOT EXISTS idx_risks_status ON risks(status);
CREATE INDEX IF NOT EXISTS idx_risks_rpn ON risks(rpn DESC);
CREATE INDEX IF NOT EXISTS idx_training_status ON training_records(status);
CREATE INDEX IF NOT EXISTS idx_ncr_status ON non_conformances(status);
CREATE INDEX IF NOT EXISTS idx_ncr_severity ON non_conformances(severity);
CREATE INDEX IF NOT EXISTS idx_audits_status ON audits(status);
CREATE INDEX IF NOT EXISTS idx_audits_type ON audits(type);
CREATE INDEX IF NOT EXISTS idx_audit_trail_table ON audit_trail(table_name, record_id);
CREATE INDEX IF NOT EXISTS idx_audit_trail_user ON audit_trail(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_trail_created ON audit_trail(created_at DESC);

-- =====================================================
-- Row Level Security (RLS) Policies
-- =====================================================

-- Enable RLS on all tables
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE capas ENABLE ROW LEVEL SECURITY;
ALTER TABLE risks ENABLE ROW LEVEL SECURITY;
ALTER TABLE training_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE non_conformances ENABLE ROW LEVEL SECURITY;
ALTER TABLE audits ENABLE ROW LEVEL SECURITY;
ALTER TABLE legal_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_trail ENABLE ROW LEVEL SECURITY;

-- Organizations: Everyone can read, only admins can modify
CREATE POLICY "orgs_select" ON organizations FOR SELECT USING (true);
CREATE POLICY "orgs_insert" ON organizations FOR INSERT WITH CHECK (auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));
CREATE POLICY "orgs_update" ON organizations FOR UPDATE USING (auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));
CREATE POLICY "orgs_delete" ON organizations FOR DELETE USING (auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));

-- Profiles: Users can read all, update own profile, admins can do everything
CREATE POLICY "profiles_select" ON profiles FOR SELECT USING (true);
CREATE POLICY "profiles_insert" ON profiles FOR INSERT WITH CHECK (auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));
CREATE POLICY "profiles_update" ON profiles FOR UPDATE USING (auth.uid() = id OR auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));
CREATE POLICY "profiles_delete" ON profiles FOR DELETE USING (auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin'));

-- Documents: Based on status and user role
CREATE POLICY "documents_select" ON documents FOR SELECT USING (
    status = 'Approved' OR 
    status = 'Obsolete' OR 
    auth.uid() = author_id OR 
    auth.uid() = reviewer_id OR 
    auth.uid() = approver_id OR 
    auth.uid() IN (SELECT id FROM profiles WHERE role IN ('admin', 'quality_manager', 'auditor'))
);
CREATE POLICY "documents_insert" ON documents FOR INSERT WITH CHECK (
    auth.uid() IN (SELECT id FROM profiles WHERE role IN ('admin', 'quality_manager', 'reviewer'))
);
CREATE POLICY "documents_update" ON documents FOR UPDATE USING (
    auth.uid() = author_id OR 
    auth.uid() IN (SELECT id FROM profiles WHERE role IN ('admin', 'quality_manager'))
);
CREATE POLICY "documents_delete" ON documents FOR DELETE USING (
    auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin')
);

-- CAPA: Similar access control
CREATE POLICY "capas_select" ON capas FOR SELECT USING (
    auth.uid() = created_by OR 
    auth.uid() = assigned_to OR 
    auth.uid() IN (SELECT id FROM profiles WHERE role IN ('admin', 'quality_manager', 'auditor'))
);
CREATE POLICY "capas_insert" ON capas FOR INSERT WITH CHECK (
    auth.uid() IN (SELECT id FROM profiles WHERE role IN ('admin', 'quality_manager', 'operator'))
);
CREATE POLICY "capas_update" ON capas FOR UPDATE USING (
    auth.uid() = created_by OR 
    auth.uid() = assigned_to OR 
    auth.uid() IN (SELECT id FROM profiles WHERE role IN ('admin', 'quality_manager'))
);
CREATE POLICY "capas_delete" ON capas FOR DELETE USING (
    auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin')
);

-- Risks
CREATE POLICY "risks_select" ON risks FOR SELECT USING (true);
CREATE POLICY "risks_insert" ON risks FOR INSERT WITH CHECK (
    auth.uid() IN (SELECT id FROM profiles WHERE role IN ('admin', 'quality_manager', 'reviewer'))
);
CREATE POLICY "risks_update" ON risks FOR UPDATE USING (
    auth.uid() IN (SELECT id FROM profiles WHERE role IN ('admin', 'quality_manager'))
);
CREATE POLICY "risks_delete" ON risks FOR DELETE USING (
    auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin')
);

-- Training Records
CREATE POLICY "training_select" ON training_records FOR SELECT USING (true);
CREATE POLICY "training_insert" ON training_records FOR INSERT WITH CHECK (
    auth.uid() IN (SELECT id FROM profiles WHERE role IN ('admin', 'quality_manager'))
);
CREATE POLICY "training_update" ON training_records FOR UPDATE USING (
    auth.uid() IN (SELECT id FROM profiles WHERE role IN ('admin', 'quality_manager'))
);
CREATE POLICY "training_delete" ON training_records FOR DELETE USING (
    auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin')
);

-- Non-Conformances
CREATE POLICY "ncr_select" ON non_conformances FOR SELECT USING (true);
CREATE POLICY "ncr_insert" ON non_conformances FOR INSERT WITH CHECK (
    auth.uid() IN (SELECT id FROM profiles WHERE role IN ('admin', 'quality_manager', 'operator'))
);
CREATE POLICY "ncr_update" ON non_conformances FOR UPDATE USING (
    auth.uid() IN (SELECT id FROM profiles WHERE role IN ('admin', 'quality_manager'))
);
CREATE POLICY "ncr_delete" ON non_conformances FOR DELETE USING (
    auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin')
);

-- Audits
CREATE POLICY "audits_select" ON audits FOR SELECT USING (true);
CREATE POLICY "audits_insert" ON audits FOR INSERT WITH CHECK (
    auth.uid() IN (SELECT id FROM profiles WHERE role IN ('admin', 'quality_manager', 'auditor'))
);
CREATE POLICY "audits_update" ON audits FOR UPDATE USING (
    auth.uid() IN (SELECT id FROM profiles WHERE role IN ('admin', 'quality_manager', 'auditor'))
);
CREATE POLICY "audits_delete" ON audits FOR DELETE USING (
    auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin')
);

-- Legal Documents
CREATE POLICY "legal_select" ON legal_documents FOR SELECT USING (is_active = true OR auth.uid() IN (SELECT id FROM profiles WHERE role IN ('admin', 'quality_manager')));
CREATE POLICY "legal_insert" ON legal_documents FOR INSERT WITH CHECK (
    auth.uid() IN (SELECT id FROM profiles WHERE role IN ('admin', 'quality_manager'))
);
CREATE POLICY "legal_update" ON legal_documents FOR UPDATE USING (
    auth.uid() IN (SELECT id FROM profiles WHERE role IN ('admin', 'quality_manager'))
);
CREATE POLICY "legal_delete" ON legal_documents FOR DELETE USING (
    auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin')
);

-- Audit Trail: Read all, insert all (for triggers), admin delete
CREATE POLICY "audit_select" ON audit_trail FOR SELECT USING (
    auth.uid() IN (SELECT id FROM profiles WHERE role IN ('admin', 'quality_manager', 'auditor'))
);
CREATE POLICY "audit_insert" ON audit_trail FOR INSERT WITH CHECK (true);
CREATE POLICY "audit_delete" ON audit_trail FOR DELETE USING (
    auth.uid() IN (SELECT id FROM profiles WHERE role = 'admin')
);

-- =====================================================
-- Function to handle new user creation
-- =====================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (id, email, full_name, role, organization_id)
    VALUES (
        NEW.id,
        NEW.email,
        NEW.raw_user_meta_data->>'full_name',
        COALESCE(NEW.raw_user_meta_data->>'role', 'operator'),
        (SELECT id FROM organizations LIMIT 1)
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for new user
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- =====================================================
-- Function to update timestamp
-- =====================================================
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add updated_at triggers
CREATE TRIGGER update_documents_updated_at BEFORE UPDATE ON documents FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_capas_updated_at BEFORE UPDATE ON capas FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_risks_updated_at BEFORE UPDATE ON risks FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_training_records_updated_at BEFORE UPDATE ON training_records FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_non_conformances_updated_at BEFORE UPDATE ON non_conformances FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_audits_updated_at BEFORE UPDATE ON audits FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_legal_documents_updated_at BEFORE UPDATE ON legal_documents FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- =====================================================
-- Insert Sample Organization
-- =====================================================
INSERT INTO organizations (name, address, email)
VALUES ('Medical Device Corp', '123 Healthcare Ave, Paris, France', 'quality@medicaldevice.com')
ON CONFLICT DO NOTHING;
